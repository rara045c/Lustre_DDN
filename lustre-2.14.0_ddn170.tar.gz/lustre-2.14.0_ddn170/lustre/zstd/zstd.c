// SPDX-License-Identifier: GPL-2.0-only
/*
 * Cryptographic API.
 *
 * Copyright (c) 2017-present, Facebook, Inc.
 */
#include <linux/crypto.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/mm.h>
#include <linux/module.h>
#include <linux/net.h>
#include <linux/vmalloc.h>
#include <lustre_crypto.h>
#include "zstd.h"
#include <libcfs/compr_private/scompress.h>


#define ZSTD_DEF_LEVEL	3

/* Level as stored in the Lustre file layout is limited to 4 bits, i.e.
 * between 0 and 15. But for zstd, compression level can be tuned from 1 to 22.
 * So we map the provided level to the zstd compression level by keeping 1-9
 * as-is, and then going by steps of 2 so 11 13 15 17 19 21.
 */
static inline int to_zstd_level(u8 level)
{
	if (!level)
		return ZSTD_DEF_LEVEL;
	else if (level < 10)
		return level;
	else
		return (level - 9) * 2 + 9;
}

/* Level as stored in the Lustre file layout is limited to 4 bits, i.e.
 * between 0 and 15. But for zstdfast, acceleration factor can be tuned from
 * 1 to 10, then 20-100 (in increments of 10), 500 and 1000.
 * Note that 500 and 1000 levels are basically the same as not compressing
 * at all, which means there is no reason to support them.
 * So we map the provided level to the zstd acceleration factor by keeping 1-10
 * as-is, and then going by steps of 20 so 20 40 60 80 100.
 * And we return the negative value, as zstd understands the acceleration factor
 * when it is a negative level.
 */
static inline int to_zstdfast_level(u8 level)
{
	if (!level)
		return -1;
	else if (level < 11)
		return -level;
	else
		return -((level - 10) * 20);
}

struct zstd_ctx {
	zstd_cctx *cctx;
	zstd_dctx *dctx;
	void *cwksp;
	void *dwksp;
};

static zstd_parameters zstd_params(int level, unsigned long long src_size)
{

	return zstd_get_params(level, src_size);
}

static int zstd_comp_init(struct zstd_ctx *ctx)
{
	/* We defer init to when compression is actually done, which makes it
	 * possible to correctly fit the workspace size according to the
	 * compression level and estimated source length.
	 */
	ctx->cwksp = NULL;
	ctx->cctx = NULL;
	return 0;
}

static int zstd_decomp_init(struct zstd_ctx *ctx)
{
	int ret = 0;
	const size_t wksp_size = zstd_dctx_workspace_bound();

	ctx->dwksp = vzalloc(wksp_size);
	if (!ctx->dwksp) {
		ret = -ENOMEM;
		goto out;
	}

	ctx->dctx = zstd_init_dctx(ctx->dwksp, wksp_size);
	if (!ctx->dctx) {
		ret = -EINVAL;
		goto out_free;
	}
out:
	return ret;
out_free:
	vfree(ctx->dwksp);
	goto out;
}

static void zstd_comp_exit(struct zstd_ctx *ctx)
{
	vfree(ctx->cwksp);
	ctx->cwksp = NULL;
	ctx->cctx = NULL;
}

static void zstd_decomp_exit(struct zstd_ctx *ctx)
{
	vfree(ctx->dwksp);
	ctx->dwksp = NULL;
	ctx->dctx = NULL;
}

static int __zstd_init(void *ctx)
{
	int ret;

	ret = zstd_comp_init(ctx);
	if (ret)
		return ret;
	ret = zstd_decomp_init(ctx);
	if (ret)
		zstd_comp_exit(ctx);
	return ret;
}

static void *zstd_alloc_ctx(struct crypto_scomp *tfm)
{
	int ret;
	struct zstd_ctx *ctx;

	ctx = kzalloc(sizeof(*ctx), GFP_KERNEL);
	if (!ctx)
		return ERR_PTR(-ENOMEM);

	ret = __zstd_init(ctx);
	if (ret) {
		kfree(ctx);
		return ERR_PTR(ret);
	}

	return ctx;
}

static int zstd_init(struct crypto_tfm *tfm)
{
	struct zstd_ctx *ctx = crypto_tfm_ctx(tfm);

	return __zstd_init(ctx);
}

static void __zstd_exit(void *ctx)
{
	zstd_comp_exit(ctx);
	zstd_decomp_exit(ctx);
}

static void zstd_free_ctx(struct crypto_scomp *tfm, void *ctx)
{
	__zstd_exit(ctx);
	kfree_sensitive(ctx);
}

static void zstd_exit(struct crypto_tfm *tfm)
{
	struct zstd_ctx *ctx = crypto_tfm_ctx(tfm);

	__zstd_exit(ctx);
}

static int __zstd_compress(const u8 *src, unsigned int slen,
			   u8 *dst, unsigned int *dlen, void *ctx, int level)
{
	size_t out_len;
	struct zstd_ctx *zctx = ctx;
	const zstd_parameters params = zstd_params(level, slen);
	size_t wksp_size = 0;
	int ret = 0;

	/* If init was deferred, do it now. The advantage is we know compression
	 * level and chunk size, which allows to adjust the workspace size more
	 * accurately, hence avoiding wasting too much memory.
	 */
init:
	if (!zctx->cwksp && !zctx->cctx) {
		wksp_size = zstd_cctx_workspace_bound(&params.cParams);
		zctx->cwksp = vzalloc(wksp_size);
		if (!zctx->cwksp) {
			ret = -ENOMEM;
			goto out;
		}

		zctx->cctx = zstd_init_cctx(zctx->cwksp, wksp_size);
		if (!zctx->cctx) {
			ret = -EINVAL;
			goto out_free;
		}
	}

	out_len = zstd_compress_cctx(zctx->cctx, dst, *dlen, src, slen,
				     &params);
	if (zstd_is_error(out_len)) {
		if (!wksp_size && zstd_get_error_code(out_len) ==
		    ZSTD_error_memory_allocation) {
			/* likely because a previous deferred init allocated a
			 * smaller workspace to fit src size and compr level,
			 * so cleanup and reallocate with current params
			 */
			zstd_comp_exit(zctx);
			goto init;
		}
		ret = -EINVAL;
		goto out;
	}
	*dlen = out_len;
out:
	return ret;
out_free:
	vfree(zctx->dwksp);
	goto out;
}

static int zstd_compress(struct crypto_tfm *tfm, const u8 *src,
			 unsigned int slen, u8 *dst, unsigned int *dlen)
{
	struct zstd_ctx *ctx = crypto_tfm_ctx(tfm);
	u32 flags = crypto_tfm_get_flags(tfm);
	u8 level = flags >> COMPR_LEVEL_SHIFT;

	/* Remove compression level from flags */
	crypto_tfm_set_flags(tfm, flags & ~COMPR_LEVEL_MASK);

	return __zstd_compress(src, slen, dst, dlen, ctx,
			       to_zstd_level(level));
}

static int zstdfast_compress(struct crypto_tfm *tfm, const u8 *src,
			     unsigned int slen, u8 *dst, unsigned int *dlen)
{
	struct zstd_ctx *ctx = crypto_tfm_ctx(tfm);
	u32 flags = crypto_tfm_get_flags(tfm);
	u8 level = flags >> COMPR_LEVEL_SHIFT;

	/* Remove compression level from flags */
	crypto_tfm_set_flags(tfm, flags & ~COMPR_LEVEL_MASK);

	return __zstd_compress(src, slen, dst, dlen, ctx,
			       to_zstdfast_level(level));
}

static int zstd_scompress(struct crypto_scomp *tfm, const u8 *src,
			  unsigned int slen, u8 *dst, unsigned int *dlen,
			  void *ctx)
{
	struct crypto_tfm *tfm2 = crypto_scomp_tfm(tfm);
	u32 flags = crypto_tfm_get_flags(tfm2);
	u8 level = flags >> COMPR_LEVEL_SHIFT;

	/* Remove compression level from flags */
	crypto_tfm_set_flags(tfm2, flags & ~COMPR_LEVEL_MASK);

	return __zstd_compress(src, slen, dst, dlen, ctx,
			       to_zstd_level(level));
}

static int zstdfast_scompress(struct crypto_scomp *tfm, const u8 *src,
			      unsigned int slen, u8 *dst, unsigned int *dlen,
			      void *ctx)
{
	struct crypto_tfm *tfm2 = crypto_scomp_tfm(tfm);
	u32 flags = crypto_tfm_get_flags(tfm2);
	u8 level = flags >> COMPR_LEVEL_SHIFT;

	/* Remove compression level from flags */
	crypto_tfm_set_flags(tfm2, flags & ~COMPR_LEVEL_MASK);

	return __zstd_compress(src, slen, dst, dlen, ctx,
			       to_zstdfast_level(level));
}

static int __zstd_decompress(const u8 *src, unsigned int slen,
			     u8 *dst, unsigned int *dlen, void *ctx)
{
	size_t out_len;
	struct zstd_ctx *zctx = ctx;

	out_len = zstd_decompress_dctx(zctx->dctx, dst, *dlen, src, slen);
	if (zstd_is_error(out_len))
		return -EINVAL;
	*dlen = out_len;
	return 0;
}

static int zstd_decompress(struct crypto_tfm *tfm, const u8 *src,
			   unsigned int slen, u8 *dst, unsigned int *dlen)
{
	struct zstd_ctx *ctx = crypto_tfm_ctx(tfm);

	return __zstd_decompress(src, slen, dst, dlen, ctx);
}

static int zstd_sdecompress(struct crypto_scomp *tfm, const u8 *src,
			    unsigned int slen, u8 *dst, unsigned int *dlen,
			    void *ctx)
{
	return __zstd_decompress(src, slen, dst, dlen, ctx);
}

static struct crypto_alg alg = {
	.cra_name		= "zstd",
	.cra_driver_name	= "zstd-lustre-generic",
	.cra_priority		= 110,
	.cra_flags		= CRYPTO_ALG_TYPE_COMPRESS,
	.cra_ctxsize		= sizeof(struct zstd_ctx),
	.cra_module		= THIS_MODULE,
	.cra_init		= zstd_init,
	.cra_exit		= zstd_exit,
	.cra_u			= { .compress = {
	.coa_compress		= zstd_compress,
	.coa_decompress		= zstd_decompress } }
};

static struct crypto_alg algf = {
	.cra_name		= "zstdfast",
	.cra_driver_name	= "zstdfast-lustre-generic",
	.cra_priority		= 110,
	.cra_flags		= CRYPTO_ALG_TYPE_COMPRESS,
	.cra_ctxsize		= sizeof(struct zstd_ctx),
	.cra_module		= THIS_MODULE,
	.cra_init		= zstd_init,
	.cra_exit		= zstd_exit,
	.cra_u			= { .compress = {
	.coa_compress		= zstdfast_compress,
	.coa_decompress		= zstd_decompress } }
};

static struct scomp_alg scomp = {
	.alloc_ctx		= zstd_alloc_ctx,
	.free_ctx		= zstd_free_ctx,
	.compress		= zstd_scompress,
	.decompress		= zstd_sdecompress,
	.base			= {
		.cra_name	= "zstd",
		.cra_driver_name = "zstd-lustre-scomp",
		.cra_priority	 = 110,
		.cra_module	 = THIS_MODULE,
	}
};

static struct scomp_alg scompf = {
	.alloc_ctx		= zstd_alloc_ctx,
	.free_ctx		= zstd_free_ctx,
	.compress		= zstdfast_scompress,
	.decompress		= zstd_sdecompress,
	.base			= {
		.cra_name	= "zstdfast",
		.cra_driver_name = "zstdfast-lustre-scomp",
		.cra_priority	 = 110,
		.cra_module	 = THIS_MODULE,
	}
};

static int __init zstd_mod_init(void)
{
	int ret;

	ret = crypto_register_alg(&alg);
	if (ret)
		goto out;

	ret = crypto_register_alg(&algf);
	if (ret) {
		crypto_unregister_alg(&alg);
		goto out;
	}

	ret = crypto_register_scomp(&scomp);
	if (ret) {
		crypto_unregister_alg(&algf);
		crypto_unregister_alg(&alg);
		goto out;
	}

	ret = crypto_register_scomp(&scompf);
	if (ret) {
		crypto_unregister_scomp(&scomp);
		crypto_unregister_alg(&algf);
		crypto_unregister_alg(&alg);
		goto out;
	}

out:
	return ret;
}

static void __exit zstd_mod_fini(void)
{
	crypto_unregister_alg(&alg);
	crypto_unregister_alg(&algf);
	crypto_unregister_scomp(&scomp);
	crypto_unregister_scomp(&scompf);
}

subsys_initcall(zstd_mod_init);
module_exit(zstd_mod_fini);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Zstd Compression Algorithm");
MODULE_ALIAS_CRYPTO("lzstd");
