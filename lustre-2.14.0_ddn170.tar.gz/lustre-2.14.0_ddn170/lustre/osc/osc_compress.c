/* GPL HEADER START
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 only,
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License version 2 for more details (a copy is included
 * in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU General Public License
 * version 2 along with this program; If not, see
 * http://www.gnu.org/licenses/gpl-2.0.html
 *
 * GPL HEADER END
 */

/*
 * Copyright (c) 2023, DataDirect Networks Inc, all rights reserved.
 * Author: Artem Blagodarenko <ablagodarenko@whamcloud.com>
 */

#define DEBUG_SUBSYSTEM S_OSC

#include <lustre_debug.h>
#include <linux/falloc.h>
#include "osc_internal.h"
#include "osc_compress.h"
#include <lustre_compr.h>

void free_cpga(struct brw_page **cpga, u32 page_count)
{
	int i;

	for (i = 0; i < page_count; i++) {
		if (cpga[i] == NULL)
			continue;

		if (cpga[i]->bp_cmp_chunk)
			sptlrpc_pool_put_pages(&cpga[i]->bp_cmp_chunk,
						   cpga[i]->bp_cmp_chunk_size);

		OBD_FREE(cpga[i], sizeof(**cpga));
	}

	OBD_FREE(cpga, page_count * sizeof(*cpga));
}

static int fill_cpga(struct brw_page **cpga, struct brw_page **pga,
		     char *dst, int src_from, int dst_from, size_t dst_size)
{
	struct brw_page *pg;
	int chunk_offset;
	int dst_page;
	int src_page;

	for (chunk_offset = 0, dst_page = dst_from, src_page = src_from;
	     chunk_offset < dst_size;
	     chunk_offset += PAGE_SIZE, dst_page++, src_page++) {
		/* TDB: shoulb be a slab cache */
		OBD_ALLOC_PTR(cpga[dst_page]);

		if (cpga[dst_page] == NULL)
			RETURN(-ENOMEM);

		pg = cpga[dst_page];
		pg->off = pga[src_from]->off + chunk_offset;
		/* this asserts that every page in a compressed IO starts at
		 * a page aligned offset, which means 'the client only does
		 * compression for aligned IO'
		 */
		LASSERTF((pg->off & ~PAGE_MASK) == 0,
			 "pg->off %llu\n", pg->off);
		/* infiniband requires there be no gaps in memory when
		 * mapping an RDMA, so if we're doing compression, we just set
		 * the reported size to PAGE_SIZE.  Technically this means we
		 * will copy extra data for the last page, but this isn't a big
		 * deal, and the compression header saves us from reading
		 * garbage.
		 *
		 * The interesting case is compression of the last chunk, which
		 * may be a partial chunk.  In this case, we still just send the
		 * whole page, because the actual file size is set on the
		 * server, so any trailing bytes are ignored.
		 *
		 * TODO: After doing compression, we should zero the remaining
		 * part of the incomplete pages.  This is a TODO for another
		 * patch.
		 */
		pg->count = PAGE_SIZE;
		pg->pg = mem_to_page(dst + chunk_offset);
		/* we get flags from the first page in the chunk and
		 * add COMPRESSED
		 */
		pg->flag = pga[src_from]->flag | OBD_BRW_COMPRESSED;

		CDEBUG(D_SEC, "off 0x%llx, flag %x, pg %p, count %u\n",
		       pg->off, pg->flag, pg->pg, pg->count);
	}

	return 0;
}

/**
 * A decaying average is a weighted average using decaying rate to  determing
 * the relative weight of the more recent value versus ealier ones, the
 * higher the decay rate, the more heavily the most recent value is weighted.
 */
static unsigned int decaying_average(unsigned int prev, unsigned int value,
				     unsigned int decay_rate)
{
	if (decay_rate > 100)
		decay_rate = 100;

	return (prev * (100 - decay_rate) + value * decay_rate) / 100;
}

/**
 * \param[in] src_size			data bytes before processing
 * \param[in] dst_size			data bytes after compressing
 * \param[in,out] incompressible	file is regard as incompressible
 *
 * \retval new compress_state
 *
 * if @src_size == @dst_size, then data has not been compressed.
 */
static void
update_compression_info(struct osc_object *obj, struct client_obd *cli,
			struct obdo *oa, unsigned int src_size,
			unsigned int dst_size, bool *incompressible)
{
	char *obd_name = cli->cl_import->imp_obd->obd_name;
	struct lu_fid *fid = &oa->o_oi.oi_fid;

	/* file not compressible, update oo_compress_skip_bytes */
	if (obj->oo_compr_state == CS_INCOMPR) {
		/* don't retry compression if indicated */
		if (cli->cl_compress_skip_multiplier == 0)
			return;

		obj->oo_compress_skip_bytes += src_size;

		CDEBUG(D_SEC, "%s: object "DFID" not compressible, skip %lu bytes\n",
		       obd_name, PFID(fid), obj->oo_compress_skip_bytes);

		if (obj->oo_compress_skip_bytes >=
		    (1UL << obj->oo_compr_skip_shift)) {
			CDEBUG(D_SEC,
			       "%s: object "DFID" skip %lu bytes uncompressed data, start to check compressibility\n",
			       obd_name, PFID(fid),
			       obj->oo_compress_skip_bytes);
			/* hibernation is over */
			obj->oo_compress_orig = 0;
			obj->oo_compress_reduced = 0;
			obj->oo_compress_checked_bytes = 0;
			obj->oo_compr_state = CS_CHECK_INC;
		}
		return;
	}

	/* file is compressible, update compression ratio. */
	obj->oo_compress_checked_bytes += src_size;
	obj->oo_compress_orig = decaying_average(obj->oo_compress_orig,
						   src_size, 90);
	obj->oo_compress_reduced = decaying_average(
					obj->oo_compress_reduced,
					(src_size > dst_size) ?
					(src_size - dst_size) : 0, 90);
	CDEBUG(D_SEC, "%s: object "DFID" compression checked %lu bytes, average compression reduced %lu bytes of %lu raw bytes\n",
	       obd_name, PFID(fid), obj->oo_compress_checked_bytes,
	       obj->oo_compress_reduced, obj->oo_compress_orig);
	/*
	 * we'd process up to compress_check_bytes data then check the
	 * compressibility.
	 */
	if (obj->oo_compress_checked_bytes >=
			(cli->cl_compress_check_multiplier <<
			 COMPR_CHUNK_MIN_BITS)) {
		/* finished a compressibility check cycle, start a new one. */
		obj->oo_compress_checked_bytes = 0;

		if (obj->oo_compress_orig > obj->oo_compress_reduced *
					      cli->cl_compress_reduced_ratio) {
			CDEBUG(D_SEC,
			       "%s: object "DFID" compression reduced %lu bytes ( < %lu/%u bytes), the file is considered as incompressible\n",
			       obd_name, PFID(fid), obj->oo_compress_reduced,
			       obj->oo_compress_orig,
			       cli->cl_compress_reduced_ratio);
			/*
			 * the file is regarded incompressible, start
			 * compressibility checking hibernation cycle.
			 */
			*incompressible = true;
			if (obj->oo_compr_state == CS_COMPR || obj->oo_compr_state == CS_CHECK) {
				/* init compress hibernation */
				obj->oo_compress_skip_bytes = 0;
				obj->oo_compr_skip_shift =
					fls(cli->cl_compress_skip_multiplier) -
					1 + COMPR_CHUNK_MIN_BITS;
			} else if (obj->oo_compr_state == CS_CHECK_INC) {
				if (obj->oo_compr_skip_shift <
				    MAX_COMPR_CHECK_SKIP_SHIFT)
					(obj->oo_compr_skip_shift)++;
			}
			obj->oo_compr_state = CS_INCOMPR;
		} else {
			*incompressible = false;
			obj->oo_compr_state = CS_COMPR;
		}

		return;
	}

	/* checked bytes has not reached checking length */
	if (obj->oo_compr_state == CS_COMPR)
		obj->oo_compr_state = CS_CHECK;

	return;
}

/* returns 0 on success, non-zero on failure to compress */
int compress_request(struct client_obd *cli, struct obdo *oa,
		     struct brw_page **pga, struct brw_page ***cpga,
		     u32 *page_count, __u64 kms)
{
	const char *obd_name = cli->cl_import->imp_obd->obd_name;
	struct lu_env *env;
	__u16 refcheck;
	struct osc_object *obj;
	struct cl_page *clpage;
	struct crypto_comp *cc;
	enum ll_compr_type type;
	unsigned int total_src_size = 0;
	unsigned int total_compr_size = 0;
	unsigned int total_uncompr_size = 0;
	int compr_chunk_count = 0;
	int chunks_no_compr = 0;
	int compr_pages_count = 0;
	int uncompr_pages_count = 0;
	int pages_per_chunk;
	int dest_buf_bits;
	int src_buf_bits;
	void *src = NULL;
	void *dst = NULL;
	int chunk_size;
	int chunk_bits;
	int cpga_i = 0;
	int pga_i = 0;
	int rc = 0;
	int lvl;
	bool incompressible;

	ENTRY;

	env = cl_env_get(&refcheck);
	if (IS_ERR(env))
		RETURN(PTR_ERR(env));

	clpage = oap2cl_page(brw_page2oap(pga[0]));
	lvl = clpage->cp_compr_level;
	type = clpage->cp_compr_type;

	chunk_bits = cl_page_compr_bits(clpage);
	chunk_size = (1 << chunk_bits);
	pages_per_chunk = chunk_size / PAGE_SIZE;

	src_buf_bits = chunk_bits - PAGE_SHIFT;
	dest_buf_bits = chunk_bits - PAGE_SHIFT;

	obj = brw_page2oap(pga[0])->oap_obj;
	incompressible = obj->oo_incompressible;
	if (obj->oo_compr_skip_shift == 0)
		obj->oo_compr_skip_shift =
			fls(cli->cl_compress_skip_multiplier) - 1 +
			COMPR_CHUNK_MIN_BITS;
	if (obj->oo_compr_state == CS_UNKNOWN)
		obj->oo_compr_state = incompressible ? CS_INCOMPR : CS_COMPR;

	rc = alloc_compr(cli, &type, &lvl, &cc);
	/* if we're unable to setup compression, alloc_compr prints a warning
	 * but we do not fail the IO - just write data uncompressed
	 */
	if (rc)
		GOTO(out, rc);

	OBD_ALLOC(*cpga, *page_count * sizeof(**cpga));
	rc = sptlrpc_pool_get_pages(&src, src_buf_bits);

	if (*cpga == NULL || src == NULL || rc)
		GOTO(out, rc = -ENOMEM);

	CDEBUG(D_SEC, "Compression type %i, level %i\n", type, lvl);

	while (pga_i < *page_count) {
		struct brw_page *pg = pga[pga_i];
		struct brw_page *pg_prev = NULL;
		struct brw_page *pg_last;
		bool chunk_unmergeable = false;
		bool compress_this = false;
		bool compressed = false;
		unsigned int src_size = 0;
		unsigned int dst_size = 0;
		__u64 chunk_len_bytes = 0;
		int chunk_len = 1;
		int chunk_start;
		int curr;

		/* if this page isn't aligned to chunk start, skip it */
		if ((pg->off & (chunk_size - 1)))
			goto skip;
		/* this is a potential chunk start! */
		CDEBUG(D_SEC, "chunk aligned page %d at %llu\n",
		       pga_i, pg->off);
		chunk_start = pga_i;
		for (curr = chunk_start; curr < *page_count; curr++) {
			struct brw_page *pg_curr;

			pg_curr = pga[curr];

			/* these pages can't be merged, so can't be in the same
			 * chunk
			 */
			if (pg_prev && !can_merge_pages(pg_prev, pg_curr)) {
				CDEBUG(D_SEC,
				       "can't merge page %d with prev\n",
				       curr);
				if (pg_prev->off + pg_prev->count !=
				    pg_curr->off) {
					CDEBUG(D_SEC,
					       "gap between page %d at %llu and %d at %llu\n",
					       curr - 1, pg_prev->off, curr, pg_curr->off);
				}
				chunk_unmergeable = true;
				break;
			}

			chunk_len = curr - chunk_start + 1;
			/* chunk is full, stop here */
			if (chunk_len == pages_per_chunk) {
				CDEBUG(D_SEC, "chunk full, [%d, %d]\n",
				       pga_i, curr);
				break;
			}
			pg_prev = pg_curr;
		}
		/* last page in this chunk (could be == first, that's OK) */
		pg_last = pga[chunk_start + chunk_len - 1];

		chunk_len_bytes = PAGE_SIZE * chunk_len;

		if (chunk_len == pages_per_chunk) {
			compress_this = true;
		/* if the write end is equal to KMS, this write - which we
		 * already verified starts at a chunk boundary - is the
		 * furthest write to this file and can be compressed
		 * (this write has been incorporated in to KMS already, hence
		 * we check the end for equality.  We could do >=, but == should
		 * always work.)
		 */
		} else if (chunk_len_bytes > LL_COMPR_GAP &&
			   !chunk_unmergeable &&
			   pg_last->off + pg_last->count == kms) {
			compress_this = true;
			CDEBUG(D_SEC,
			       "Chunk starting at %llu (pages [%d, %d]) matches kms %llu, compressing.\n",
			       pga[chunk_start]->off, pga_i, pga_i + chunk_len, kms);
		}
		CDEBUG(D_SEC,
		       "chunk start at %llu, chunk end at %llu, kms %llu\n",
		       pga[chunk_start]->off, pg_last->off + pg_last->count, kms);

		if (compress_this) {
			if (obj->oo_compr_state == CS_INCOMPR) {
				chunks_no_compr++;
				GOTO(skip, false);
			}

			CDEBUG(D_SEC,
			       "compressing chunk from page [%d, %d], off [%llu, %llu]\n",
			       chunk_start, chunk_start + chunk_len - 1,
			       pga[chunk_start]->off, pg_last->off + pg_last->count);

			dst_size = chunk_size;
			rc = sptlrpc_pool_get_pages(&dst, dest_buf_bits);
			if (dst == NULL || rc)
				GOTO(out, rc = -ENOMEM);

			merge_chunk(pga, NULL, chunk_start, chunk_len, src,
				    &src_size);

			compressed = compress_chunk(obd_name, cc, src,
						    src_size, dst,
						    &dst_size, type,
						    lvl, chunk_bits);
			CDEBUG(D_SEC, "%s chunk [%d, %d]\n",
			       compressed ? "compressed" : "couldn't compress",
			       chunk_start, chunk_start + chunk_len - 1);
			/* if we failed to compress, free memory and handle
			 * this page as normal
			 */
			if (!compressed) {
				sptlrpc_pool_put_pages(&dst, dest_buf_bits);
				chunks_no_compr++;
				/* not compressed, update chunk_len_bytes to
				 * the real value when the chunk end reaches
				 * the kms
				 */
				chunk_len_bytes = src_size;
				GOTO(skip, compressed);
			}

			rc = fill_cpga(*cpga, pga, dst, chunk_start, cpga_i,
				       dst_size);
			if (rc)
				GOTO(out, rc);
			CDEBUG(D_SEC, "Compressed %u, raw %u\n",
			       dst_size, src_size);
			/* store a pointer to the memory for this chunk so it
			 * can be freed later
			 */
			(*cpga)[cpga_i]->bp_cmp_chunk = dst;
			(*cpga)[cpga_i]->bp_cmp_chunk_size =
				dest_buf_bits;

			/* move cpga_i along by the number of pages in the
			 * compressed size
			 */
			cpga_i += ((dst_size - 1) >> PAGE_SHIFT) + 1;
			/* and move pga_i along past the end of this chunk */
			pga_i += chunk_len;
			compr_chunk_count++;
			compr_pages_count += ((src_size - 1) >> PAGE_SHIFT) + 1;
			total_compr_size += dst_size;
			total_src_size += src_size;
		} else {
			chunks_no_compr++;
		}
skip:
		/* if we didn't do compression here, so point this page in the
		 * new (compressed) pga at the data from the original pga
		 */
		if (!compressed) {
			struct brw_page *cpg;

			CDEBUG(D_SEC, "did not compress page %d\n", pga_i);
			OBD_ALLOC_PTR((*cpga)[cpga_i]);
			if ((*cpga)[cpga_i] == NULL)
				GOTO(out, rc = -ENOMEM);
			cpg = (*cpga)[cpga_i];
			*cpg = *pg;
			pga_i++;
			cpga_i++;
			uncompr_pages_count++;
			total_uncompr_size += pg->count;
			total_src_size += pg->count;
		}

		/* update compression info when page aligns to chunk start */
		if (!(pg->off & (chunk_size - 1))) {
			if (compressed)
				update_compression_info(obj, cli, oa, src_size,
							dst_size,
							&incompressible);
			else
				update_compression_info(obj, cli, oa,
							chunk_len_bytes,
							chunk_len_bytes,
							&incompressible);
		}
	}

	*page_count = cpga_i;

	spin_lock(&cli->cl_compr_stats_lock);
	cli->cl_w_pages_compr += compr_pages_count;
	cli->cl_w_pages_uncompr += uncompr_pages_count;
	cli->cl_w_bytes_compr += total_compr_size;
	cli->cl_w_bytes_raw += total_src_size;
	cli->cl_w_bytes_incompr += total_uncompr_size;
	cli->cl_w_chunks_compr += compr_chunk_count;
	cli->cl_w_chunks_nocompr += chunks_no_compr;
	spin_unlock(&cli->cl_compr_stats_lock);

	obj->oo_incompressible = incompressible;
	CDEBUG(D_SEC, "Compressed content: %i pages (%i chunks)\n", cpga_i,
	       compr_chunk_count);
out:
	if (cc)
		crypto_free_comp(cc);
	if (src != NULL)
		sptlrpc_pool_put_pages(&src, src_buf_bits);
	if (rc != 0 && *cpga != NULL)
		free_cpga(*cpga, *page_count);

	cl_env_put(env, &refcheck);

	RETURN(rc);
}

int decompress_request(struct osc_brw_async_args *aa, int page_count)
{
	struct brw_page **pga = aa->aa_ppga;
	struct osc_async_page *oap = NULL;
	struct ll_compr_hdr llch;
	struct client_obd *cli = aa->aa_cli;
	char *obd_name = cli->cl_import->imp_obd->obd_name;
	enum ll_compr_type type = LL_COMPR_TYPE_NONE;
	struct crypto_comp *cc = NULL;
	struct cl_page *clpage;
	int next_chunk_min = 0;
	unsigned int src_size;
	unsigned int dst_size;
	unsigned int total_src_size = 0;
	unsigned int total_dst_size = 0;
	unsigned int decompr_chunk_count = 0;
	unsigned int decompr_pages_count = 0;
	int pages_per_chunk;
	char *src = NULL;
	char *dst = NULL;
	int chunk_bits;
	int chunk_size;
	int buf_bits;
	int rc = 0;
	int i = 0;
	int lvl;
	ENTRY;

	clpage = oap2cl_page(brw_page2oap(pga[0]));
	type = clpage->cp_compr_type;
	chunk_bits = cl_page_compr_bits(clpage);

	if (OBD_FAIL_CHECK(OBD_FAIL_OSC_FORCE_DECOMPR)) {
		/* decompress a sample from the lustre/tests/compressed.bin */
		lvl = 9;
		type = LL_COMPR_TYPE_LZ4HC;
		chunk_bits = COMPR_CHUNK_MIN_BITS;
	}

	/* no compression */
	if (type == LL_COMPR_TYPE_NONE)
		RETURN(0);
	chunk_size = 1 << chunk_bits;
	buf_bits = chunk_bits - PAGE_SHIFT;
	pages_per_chunk = chunk_size / PAGE_SIZE;

	while (i < page_count) {
		int decompressed_pages;
		int compressed_pages;
		int compressed_bytes;

		oap = brw_page2oap(pga[i]);
		CDEBUG(D_SEC, "checking page %d, offset %llu\n",
		       i, oap->oap_obj_off);

		/* not aligned to chunk size, so can't be the start of a
		 * compressed chunk - continue
		 */
		if (oap->oap_obj_off & (chunk_size - 1)) {
			total_dst_size += pga[i]->count;
			total_src_size += pga[i]->count;
			i++;
			continue;
		}

		LASSERT(ergo(next_chunk_min, i >= next_chunk_min));

		if (!is_chunk_start(pga[i]->pg, &llch, &rc)) {
			if (rc) {
				CERROR("%s: Magic and csum OK, but sanity failed: "DFID": rc = %d\n",
				       obd_name, PFID(&aa->aa_oa->o_oi.oi_fid),
				       rc);
				GOTO(out, rc);
			}
			total_dst_size += pga[i]->count;
			total_src_size += pga[i]->count;
			i++;
			continue;
		}

		/* all chunks should be compressed with the same algorithm, but
		 * we need to get the type and level from the data provided.
		 * In the future it may be that the type is also changing in
		 * a single component, so handle this properly if that happens.
		 */
		if (unlikely(cc && type != llch.llch_compr_type)) {
			crypto_free_comp(cc);
			cc = NULL;
		}
		if (!cc) {
			type = llch.llch_compr_type;
			lvl = llch.llch_compr_level;
			rc = alloc_decompr(obd_name, &type, &lvl, &cc);
			if (rc)
				GOTO(out, rc);
		}

		if (!src) { /* get chunk size once */
			int rpc_chunk_bits;

			rpc_chunk_bits = llch.llch_chunk_log_bits +
				COMPR_CHUNK_MIN_BITS;
			/* the chunk bits from storage must be the same as from
			 * the layout (but don't assert on it, since it comes
			 * from storage and could potentially be corrupted)
			 */
			if (rpc_chunk_bits != chunk_bits) {
				rc = -EUCLEAN;
				CERROR(
				       "%s: Chunk bits disagree %d != %d disagree: "DFID": rc = %d\n",
				       obd_name,
				       rpc_chunk_bits, chunk_bits,
				       PFID(&aa->aa_oa->o_oi.oi_fid), rc);
				GOTO(out, rc);
			}

			CDEBUG(D_SEC, "chunk_size: %i, pages_per_chunk: %i\n",
				chunk_size, pages_per_chunk);

			sptlrpc_pool_get_pages((void **)&src,
				buf_bits);
			sptlrpc_pool_get_pages((void **)&dst,
				buf_bits);
			if (src == NULL || dst == NULL)
				GOTO(out, rc = -ENOMEM);
		}

		compressed_bytes = llch.llch_compr_size + sizeof(llch);
		compressed_pages = ((compressed_bytes - 1) >> PAGE_SHIFT) + 1;
		CDEBUG(D_SEC, "compressed bytes %d compressed pages %d\n",
		       compressed_bytes, compressed_pages);
		/* must be enough pages left in the RPC to hold the compressed
		 * data, if not, the data from disk is probably corrupt
		 */
		if (compressed_pages > page_count - i) {
			rc = -EUCLEAN;
			CERROR("%s: compressed pages mismatch %d != %d (at %d of %d pages): object "DFID": rc = %d\n",
			       obd_name, compressed_pages, page_count - i, i,
			       page_count, PFID(&aa->aa_oa->o_oi.oi_fid), rc);
			GOTO(out, rc);
		}

		CDEBUG(D_SEC, "Merge chunk [%i, %i], src: %px\n", i,
		       i + compressed_pages - 1, src);

		merge_chunk(pga, NULL, i, compressed_pages, src, &src_size);
		LASSERT(src_size <= chunk_size);
		/* if the bytes in the merged buffer don't match like this, we
		 * probably have an incomplete page, which shouldn't occur in
		 * CSDC currently (but could happen if there's bad data)
		 */
		if (src_size != compressed_pages * PAGE_SIZE) {
			rc = -EUCLEAN;
			CERROR("%s: buffer size from compressed pages (%u bytes) doesn't match number of compressed pages %d: object "DFID": rc = %d\n",
			       obd_name, src_size, compressed_pages,
			       PFID(&aa->aa_oa->o_oi.oi_fid), rc);
			GOTO(out, rc);
		}
		dst_size = chunk_size;
		CDEBUG(D_SEC, "Compressed size %lu, type %i\n",
		       llch.llch_compr_size + sizeof(llch), type);

		rc = decompress_chunk(obd_name, cc,
				      src + llch.llch_header_size,
				      llch.llch_compr_size, dst, &dst_size,
				      type, lvl);
		if (rc)
			GOTO(out, rc);

		LASSERT(dst_size <= chunk_size);
		decompressed_pages = ((dst_size - 1) >> PAGE_SHIFT) + 1;
		CDEBUG(D_SEC, "Decompressed size %u, pages %d\n", dst_size,
		       decompressed_pages);

		total_dst_size += dst_size;
		total_src_size += compressed_bytes;
		CDEBUG(D_SEC, "total_dst_size: %u, total_src_size: %u\n",
		       total_dst_size, total_src_size);
		/* must be enough pages left in the RPC to hold the decompressed
		 * data, if not, the data from disk is probably corrupt
		 */
		if (decompressed_pages > page_count - i) {
			rc = -EUCLEAN;
			CERROR("%s: decompressed pages from disk %d don't match pages in rpc %d (at %d of %d pages): object "DFID": rc = %d\n",
			       obd_name, decompressed_pages, page_count - i, i,
			       page_count, PFID(&aa->aa_oa->o_oi.oi_fid), rc);
			GOTO(out, rc);
		}
		unmerge_chunk(pga, NULL, i, decompressed_pages, dst, dst_size,
			      0);

		/* start of the next chunk is at least compressed pages away*/
		next_chunk_min = i + compressed_pages - 1;
		i += decompressed_pages;
		CDEBUG(D_SEC, "next chunk min %d\n", next_chunk_min);
		decompr_pages_count += decompressed_pages;
		decompr_chunk_count++;
	}
	CDEBUG(D_SEC, "RPC is %d pages, decompressed %d chunks\n", page_count,
	       decompr_chunk_count);

	spin_lock(&cli->cl_compr_stats_lock);
	cli->cl_r_chunks_compr += decompr_chunk_count;
	cli->cl_r_pages_compr += decompr_pages_count;
	cli->cl_r_bytes_compr += total_src_size;
	cli->cl_r_bytes_raw += total_dst_size;
	spin_unlock(&cli->cl_compr_stats_lock);
	CDEBUG(D_SEC, "cli->cl_r_bytes_raw: %llu\n", cli->cl_r_bytes_raw);
	CDEBUG(D_SEC, "cli->cl_r_bytes_compr: %llu\n", cli->cl_r_bytes_compr);

out:
	if (cc)
		crypto_free_comp(cc);
	if (src != NULL)
		sptlrpc_pool_put_pages(&src, buf_bits);

	if (dst != NULL)
		sptlrpc_pool_put_pages(&dst, buf_bits);

	RETURN(rc);
}
