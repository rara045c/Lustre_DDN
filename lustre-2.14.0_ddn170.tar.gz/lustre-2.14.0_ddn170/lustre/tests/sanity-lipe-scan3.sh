#!/bin/bash
#
# Tests for lipe_scan3.
#
# lipe_scan3 is a Lustre device scanner which provides
# the scanning core to the user facing lipe_find3 utility
# and to the Unified Policy Engine.

ONLY=${ONLY:-"$*"}

LUSTRE=${LUSTRE:-$(dirname $0)/..}
. $LUSTRE/tests/test-framework.sh
init_test_env $@
. ${CONFIG:=$LUSTRE/tests/cfg/$NAME.sh}
init_logging

# bug number for skipped test:
ALWAYS_EXCEPT="$SANITY_LIPE_SCAN3_EXCEPT"
# UPDATE THE COMMENT ABOVE WITH BUG NUMBERS WHEN CHANGING ALWAYS_EXCEPT!

check_versions || skip_env "no need to test lipe_scan3 under interop mode"

(( OSTCOUNT >= 2 )) || skip_env "need at least 2 OSTs"

[[ $(facet_fstype mds1) = ldiskfs ]] || skip_env "need ldiskfs on MDS"

! remote_mds_nodsh || skip_env "remote MDS with nodsh"
! remote_ost_nodsh || skip_env "remote OSS with nodsh"

# check if lipe_scan3 is installed on MDS(s)
do_nodes $(comma_list $(all_mdts_nodes)) "which lipe_scan3" &>/dev/null ||
	skip_env "lipe_scan3 is not installed on MDS"

which jq || skip_env "jq is not installed"
which yq || skip_env "yq is not installed"
jq --version
yq --version

SAVED_FAIL_ON_ERROR=$FAIL_ON_ERROR
FAIL_ON_ERROR=false

(( $LINUX_VERSION_CODE > $(version_code 3.11.0) )) ||
	always_except EX-8450 306

declare -r ROOT_FID="[0x200000007:0x1:0x0]"

build_test_filter
check_and_setup_lustre
run_lfsck 2

if [ -d $MOUNT/.lustre/lost+found ] && [ "$(ls -A $MOUNT/.lustre/lost+found)" ]
then
	echo "Reformat file system"
	REFORMAT="yes" cleanup_and_setup_lustre
fi

# choose a random MDS and return its facet
lipe_get_random_mds() {
	(( MDSCOUNT != 1 )) || { echo -n mds1; return; }
	echo -n $(get_random_entry $(get_facets MDS))
}

# if the test suite was run on an MDS, then return the MDS facet
lipe_get_local_mds() {
	local facet
	local facets

	facets=$(get_facets MDS)
	for facet in ${facets//,/ }; do
		if local_node $(facet_active_host $facet); then
			echo -n $facet
			return
		fi
	done
}

function mount_client_on_facet() {
	local facet="$1"
	local nodes=$(facets_nodes "$facet")
	local node

	for node in $nodes; do
		if local_node $node; then
			continue
		fi

		zconf_mount_clients $node $MOUNT ||
			error "cannot mount client on '$node' for '$facet'"

		stack_trap "zconf_umount_clients $node $MOUNT"
	done
}

function lipe_scan3_body() {
	local facet="$1"
	local device="$(facet_device "$facet")"
	local body="$2"
	shift 2

	VERBOSE=false do_facet $facet "sync; \
		printf '(lipe-scan \\\"%q\\\" (lipe-getopt-client-mount-path) \
		(lambda () %s) (lipe-getopt-required-attrs) \
		(lipe-getopt-thread-count) (lipe-getopt-stats-depth) \
		(lipe-getopt-top-rating) (lipe-getopt-spath))' $device '$body' |
		lipe_scan3 --script=/dev/stdin $@"
}

function lipe_scan3_format() {
	local facet="$1"
	local device="$(facet_device "$facet")"
	local expr="$2"
	shift 2

	VERBOSE=false do_facet $facet "sync; \
		printf '(lipe-scan \\\"%q\\\" (lipe-getopt-client-mount-path) \
		(lambda () (format #t \\\"~a\n\\\" %s)) \
		(lipe-getopt-required-attrs) (lipe-getopt-thread-count) \
		(lipe-getopt-stats-depth) (lipe-getopt-top-rating) \
		(lipe-getopt-spath))' \
		$device '$expr' | lipe_scan3 --script=/dev/stdin $@"
}

function init_lipe_scan3_env() {
	# Check "$MOUNT" is a Lustre client mount point.
	local fid=$($LFS path2fid "$MOUNT")
	local file
	local index

	[[ "$fid" == "$ROOT_FID" ]] ||
		error "'$MOUNT' is not a lustre client mount"

	find "$MOUNT" -mindepth 1 -delete || error "cannot clean '$MOUNT'"
	find "$MOUNT" -mindepth 1 | grep . &&
		error "find -delete did not delete all files from '$MOUNT'"

	mount_client_on_facet mds1
	for file in "$@"; do
		mcreate $file || error "cannot create $file"
		index=$($LFS getstripe --mdt-index $file)
		((index == 0)) || error "file '$file' is not on MDT0000"
	done

	sync
	sync
}

function lipe_scan3_on() {
	local facet="$1"
	shift 1

	sync
	do_facet_vp "$facet" sync
	do_facet_vp "$facet" lipe_scan3 "$@"
}

function lipe_scan3_facet() {
	local facet="$1"
	local device="$(facet_device "$facet")"
	shift 1

	lipe_scan3_on "$facet" "$device" "$@"
}

function expect_stdout() {
	"$@" | grep --quiet . || error "command '$*' should write to stdout"
}

function expect_no_stdout() {
	"$@" | grep . && error "command '$*' should not write to stdout"
	true
}

function expect_stderr() {
	"$@" 2>&1 > /dev/null | grep --quiet . ||
		error "command '$*' should write to stderr"
}

function expect_no_stderr() {
	"$@" 2>&1 > /dev/null | grep . &&
		error "command '$*' should not write to stderr"
	true
}

function expect_success() {
	"$@" > /dev/null || error "command '$*' failed"
}

function expect_failure() {
	"$@" 2> /dev/null && error "command '$*' should fail"
	true
}

function expect_print() {
	expect_success "$@"
	expect_stdout "$@"
	expect_no_stderr "$@"
}

function expect_empty() {
	expect_success "$@"
	expect_no_stdout "$@"
	expect_no_stderr "$@"
}

function expect_error() {
	expect_failure "$@"
	expect_no_stdout "$@"
	expect_stderr "$@"
}

function expect_expr() {
	local facet="$1"
	local expr="$2"
	local a0="$3"
	local a1
	shift 3

	a1=$(lipe_scan3_format "$facet" "$expr" "$@")
	[[ "$a0" == "$a1" ]] || error "$expr expect '$a0', got '$a1'"
}

function expect_attr() {
	local facet="$1"
	local proc="$2"
	local a0="$3"
	local a1
	shift 3

	a1=$(lipe_scan3_format "$facet" "($proc)" "$@")
	[[ "$a0" == "$a1" ]] || error "$proc expect '$a0', got '$a1'"
}

LIPE_MDS_FACET=""
(( MDSCOUNT == 1 )) && LIPE_MDS_FACET=mds1 ||
	LIPE_MDS_FACET=$(lipe_get_local_mds)
[[ -n $LIPE_MDS_FACET ]] ||
	echo "No local MDS. Each test will be run on a random MDS."

test_0() {
	expect_success true
	expect_failure false
	expect_no_stdout true
	expect_no_stderr true
	expect_stdout echo something
	expect_stderr grep --barf
	expect_print echo output
	expect_empty true
	expect_error grep --barf
}
run_test 0 "expect functions meet our expectations"

test_10() {
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}

	expect_print lipe_scan3_on $facet -h
	expect_print lipe_scan3_on $facet --help

	expect_print lipe_scan3_on $facet -v
	expect_print lipe_scan3_on $facet --version

	expect_error lipe_scan3_on $facet
	expect_error lipe_scan3_on $facet --barf

	# expect_print lipe_scan3_on $facet "--interactive < /dev/null"
	# expect_print lipe_scan3_on $facet -i < /dev/null

	expect_print lipe_scan3_on $facet --list-attrs
	expect_print lipe_scan3_on $facet --list-json-attrs

	expect_error lipe_scan3_on $facet -s /dev/null --thread-count=zzz
	expect_error lipe_scan3_on $facet -s /dev/null --thread-count=42q
	expect_error lipe_scan3_on $facet -s /dev/null --thread-count=''
}
run_test 10 "lipe_scan3 option handling"

test_11() {
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}

	expect_error lipe_scan3_on $facet --print-self-fid /dev/null
	expect_error lipe_scan3_on $facet --print-self-fid /dev/zero
	expect_error lipe_scan3_on $facet --print-self-fid /dev/
	expect_error lipe_scan3_on $facet --print-self-fid ''
	expect_error lipe_scan3_on $facet --print-self-fid
	expect_error lipe_scan3_on $facet --print-self-fid \
		/dev/zapper/mds1_flakey
}
run_test 11 "lipe_scan3 bad device handling"

test_12() {
	local facet=mds1
	local device="$(facet_device "$facet")"
	local file=$MOUNT/$tfile
	local tmp=$(mktemp -d)
	local fid
	local cmd
	local expect_error_cmd="expect_error lipe_scan3_facet $facet"
	local expect_stderr_cmd="expect_stderr lipe_scan3_facet $facet"

	init_lipe_scan3_env "$file"
	fid=$($LFS path2fid "$file")
	touch $tmp/$tfile

	$expect_error_cmd --print-absolute-path --client-mount=''
	$expect_error_cmd --print-absolute-path --client-mount=/dev/null
	$expect_error_cmd --print-absolute-path --client-mount=$tmp
	$expect_error_cmd --print-absolute-path --client-mount=$tmp/noent
	$expect_error_cmd --print-absolute-path --client-mount=$tmp/$tfile

	# We print a warning for non canonicalized client mounts.
	$expect_stderr_cmd --print-absolute-path --client-mount=$MOUNT/
	$expect_stderr_cmd --print-absolute-path --client-mount=$MOUNT//
	$expect_stderr_cmd --print-absolute-path --client-mount=$MOUNT/.
	$expect_stderr_cmd --print-absolute-path --client-mount=$MOUNT/./.

	cmd="lipe_scan3 $device --print-absolute-path --client-mount=."
	do_facet_vp "$facet" "cd $MOUNT; $cmd" 2>&1 > /dev/null |
		grep --quiet . || error "command '$cmd' should write to stderr"

	expect_attr "$facet" self-fid "$fid" --client-mount=$MOUNT/
	expect_attr "$facet" self-fid "$fid" --no-client-mount
	expect_attr "$facet" absolute-paths "($file)" --client-mount=$MOUNT/

	# FIXME
	# $expect_error_cmd --print-absolute-path --no-client-mount
	# $expect_error_cmd --print-relative-path --no-client-mount

	umount_client $MOUNT
	stack_trap "mount_client $MOUNT"
	expect_attr "$facet" self-fid "$fid"
}
run_test 12 "--client-mount is handled correctly"

test_13() {
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local expect_success_cmd="expect_success lipe_scan3_facet $facet"
	local expect_error_cmd="expect_error lipe_scan3_facet $facet"

	$expect_success_cmd -s /dev/null --required-attrs=#x0
	$expect_success_cmd -s /dev/null --required-attrs=all
	$expect_success_cmd -s /dev/null --required-attrs=ino
	$expect_success_cmd -s /dev/null --required-attrs=mode

	do_facet $facet "lipe_scan3 --list-attrs" | while read attr; do
		$expect_success_cmd -s /dev/null --required-attrs=$attr
		$expect_success_cmd -s /dev/null --required-attrs=ino,$attr
	done

	$expect_error_cmd -s /dev/null --required-attrs=barf
	$expect_error_cmd -s /dev/null --required-attrs=ino,barf
	$expect_error_cmd -s /dev/null --required-attrs=barf,ino
}
run_test 13 "--required-attrs is handled correctly"

# TODO missing script
# TODO invalid script

test_90() {
	local facet=mds1
	local expect_empty_cmd="expect_empty lipe_scan3_facet $facet"

	init_lipe_scan3_env

	# Create some files to be deleted.
	touch $MOUNT/f0
	mkdir $MOUNT/d0
	mkfifo $MOUNT/p0
	# lfs mkdir -c ... $MOUNT/d1 ....
	ln -s $MOUNT/f0 $MOUNT/l0
	mknod $MOUNT/c0 c 1 3
	# ...

	# Now delete those files.
	init_lipe_scan3_env

	$expect_empty_cmd --print-file-fid
	$expect_empty_cmd --print-self-fid
	$expect_empty_cmd --print-json
	$expect_empty_cmd --print-absolute-path
	$expect_empty_cmd --print-relative-path
	expect_empty lipe_scan3_format $facet '(ino)'
}
run_test 90 "lipe_scan3 on an empty FS"

test_100() {
	local facet=mds1
	local file=$MOUNT/$tfile
	local proc

	init_lipe_scan3_env "$file"

	lipe_scan3_facet $facet --print-self-fid
	lipe_scan3_format $facet '(self-fid)'
	lipe_scan3_format $facet '(ino)'

	for proc in ino atime blocks crtime ctime self-fid file-fid flags gid \
		mode mtime nlink projid size uid; do
		expect_print lipe_scan3_format $facet "($proc)"
	done

	for proc in absolute-paths relative-paths links lov-mirror-count \
		lov-ost-indexes lov-pool lov-pools lov-stripe-count xattrs; do
		expect_print lipe_scan3_format $facet "($proc)"
	done
}
run_test 100 "lipe_scan3 attrs and scan functions do something"

declare -r S_IFREG=0100000
declare -a MODES=(0 1 0111 0222 0444 0555 0666 0777)

test_101() {
	local facet=mds1
	local file=$MOUNT/$tfile
	local mode

	init_lipe_scan3_env "$file"

	mode=0$(stat --format=%a $file) # octal access rights
	# $((...)) converts to decimal
	expect_attr "$facet" mode $((S_IFREG | mode))

	for mode in "${MODES[@]}"; do
		chmod "$mode" $file || error "cannot set mode to '$mode'"
		expect_attr $facet mode $((S_IFREG | mode))
	done

	# dir ...
}
run_test 101 "lipe_scan3 mode does the right thing"

declare -a IDS=(
	0
	42
	500
	65534
	65535
	65536
	2147483646 # (INT_MAX - 1)
	2147483647 # (INT_MAX)
	2147483648 # (INT_MAX + 1)
	2177452800
	4294967293 # (UINT_MAX - 2)
)

test_102() {
	local facet=mds1
	local file=$MOUNT/$tfile
	local id

	init_lipe_scan3_env "$file"

	id=$(stat --format=%u $file) # uid
	expect_attr "$facet" uid "$id"

	for id in "${IDS[@]}"; do
		chown $id $file || error "cannot set UID to '$id'"
		expect_attr "$facet" uid "$id"
	done

	id=$(stat --format=%g $file) # gid
	expect_attr "$facet" gid "$id"

	for id in "${IDS[@]}"; do
		chown :$id $file || error "cannot set GID to '$id'"
		expect_attr "$facet" gid "$id"
	done
}
run_test 102 "lipe_scan3 uid/gid do the right thing"

# XXX There are some pitfalls in debugfs/ext4 timestamp extra field encoding.
# Search for "[BUG] ext4 timestamps corruption"

declare -a TIMES=(
	         0 # 1970
	    481516 # 1970
	  48151623 # 1971
	 631152000 # 1990
	 946684800 # 2000
	1640995200 # 2022
	2145916800 # 2038
	2147483646 # 2038 (INT_MAX - 1)
	2147483647 # 2038 (INT_MAX)
	2147483648 # 2038 (INT_MAX + 1)
	2177452800 # 2039
	4294967294 # 2106 (UINT_MAX - 1)
	4294967295 # 2106 (UINT_MAX)
	4294967296 # 2106 (UINT_MAX + 1)
	4815162342 # 2122
)

test_103() {
	local facet=mds1
	local file=$MOUNT/$tfile
	local time

	init_lipe_scan3_env "$file"

	expect_expr "$facet" '(positive? (crtime))' '#t'

	time=$(stat --format=%X $file) # atime
	expect_attr "$facet" atime "$time"

	for time in "${TIMES[@]}"; do
		touch --date=@$time -a $file ||
			error "cannot set atime to '$time'"
		expect_attr "$facet" atime "$time"
	done

	time=$(stat --format=%Y $file) # mtime
	expect_attr "$facet" mtime "$time"

	for time in "${TIMES[@]}"; do
		touch --date=@$time -m $file ||
			error "cannot set mtime to '$time'"
		expect_attr "$facet" mtime "$time"
	done

	time=$(stat --format=%Z $file) # ctime
	expect_attr "$facet" ctime "$time"

	# We could use LL_IOC_FUTIMES_3 here.
}
run_test 103 "lipe_scan3 a/m/c-time do the right thing"

declare -a SIZES=(
	         0
	        42
	2147483646 # (INT_MAX - 1)
	2147483647 # (INT_MAX)
	2147483648 # (INT_MAX + 1)
	2177452800
	4294967294 # (UINT_MAX - 1)
	4294967295 # (UINT_MAX)
	4294967296 # (UINT_MAX + 1)
	4815162342
	8589934591 # 0x1ffffffff
	48151623420
	481516234200
	35184372080640000 # 2000 stripes * (16 TiB - 4096 objects)
)

test_104() {
	local facet=mds1
	local file=$MOUNT/$tfile
	local size
	local som_size
	local som_blocks
	local som_flags
	local stat_size
	local stat_blocks

	init_lipe_scan3_env "$file"

	expect_attr "$facet" size 0

	# For a file without striping, the MDT inode has the size.
	for size in "${SIZES[@]}"; do
		$TRUNCATE $file "$size"
		expect_attr "$facet" size "$size"
	done

	expect_attr "$facet" blocks 0

	params=$($LCTL get_param 'llite.*.xattr_cache')
	$LCTL set_param 'llite.*.xattr_cache=0'
	stack_trap "$LCTL set_param $params"

	dd if=/dev/urandom of="$file" bs=512 count=10
	sync

	$LFS getsom "$file"

	# For a regular file, lipe_scan3 size and blocks are as good
	# as the SoM implementation.
	som_size=$($LFS getsom -s "$file")
	som_blocks=$($LFS getsom -b "$file")
	som_flags=$($LFS getsom -f "$file")
	((som_flags == 4)) || error "expected som flags 4, got '$som_flags'"
	expect_attr "$facet" size "$som_size"
	expect_attr "$facet" blocks "$som_blocks"
	rm "$file"

	$LFS mkdir -i0 -c1 "$file"
	stat_size=$(stat --format=%s "$file")
	stat_blocks=$(stat --format=%b "$file")
	expect_attr "$facet" size "$stat_size"
	expect_attr "$facet" blocks "$stat_blocks"
	rmdir "$file"

	ln -s /dev/null "$file"
	stat_size=$(stat --format=%s "$file")
	stat_blocks=$(stat --format=%b "$file")
	expect_attr "$facet" size "$stat_size"
	expect_attr "$facet" blocks "$stat_blocks"
	rm "$file"

	mkfifo "$file"
	stat_size=$(stat --format=%s "$file")
	stat_blocks=$(stat --format=%b "$file")
	expect_attr "$facet" size "$stat_size"
	expect_attr "$facet" blocks "$stat_blocks"
	rm "$file"
}
run_test 104 "lipe_scan3 size/blocks do the right thing"

test_105() {
	local facet=mds1
	local file=$MOUNT/$tfile

	init_lipe_scan3_env "$file"

	expect_attr "$facet" nlink 1
	ln $file $file-2
	ln $file $file-3
	expect_attr "$facet" nlink 3

	# If we hold $file open and remove all three links then
	# lipe_scan3 will still return a link count of 1 because of
	# the PENDING/$fid link.
}
run_test 105 "lipe_scan3 nlink does the right thing"

test_106() {
	local facet=mds1
	local file=$MOUNT/$tfile
	local id

	init_lipe_scan3_env "$file"

	id=$($LFS project "$file" | awk '{ print $1 }')
	expect_attr "$facet" projid "$id"

	for id in "${IDS[@]}"; do
		$LFS project -p "$id" "$file" ||
			error "cannot set projid to '$id'"
		expect_attr "$facet" projid "$id"
	done
}
run_test 106 "lipe_scan3 projid does the right thing"

test_107() {
	local facet=mds1
	local file=$MOUNT/$tfile
	local fid

	init_lipe_scan3_env "$file"
	fid=$($LFS path2fid $file)
	expect_attr "$facet" file-fid "$fid"
	expect_attr "$facet" self-fid "$fid"
}
run_test 107 "lipe_scan3 file-fid and self-fid do the right thing"

test_108() {
	local facet=mds1
	local file=$MOUNT/$tfile
	local fd
	local link_count=200
	local i

	init_lipe_scan3_env "$file"

	# (links) returns a list of parent-fid, name pairs
	# (([0x200000007:0x1:0x0] . "f0") ...)

	expect_expr "$facet" '(caar (links))' "$ROOT_FID"
	expect_expr "$facet" '(cdar (links))' "$tfile"

	ln $file $file-2
	expect_expr "$facet" '(length (links))' 2

	ln $file $file-3
	expect_expr "$facet" '(length (links))' 3

	for ((i = 4; i < link_count; i++)); do
		ln $file $file-$i
	done

	expect_expr "$facet" '(caar (links))' "$ROOT_FID"
	expect_expr "$facet" '(cdar (links))' "$tfile"

	# FIXME link xattr is not updated when removing last link.
	# exec {fd}>$file
	# rm -- "$file" "$file-2" "$file-3"
	# expect_expr "$facet" '(length (links))' 0
	# exec {fd}>&-
}
run_test 108 "lipe_scan3 links does the right thing"

test_109() {
	local facet=mds1
	local file=$MOUNT/$tfile

	init_lipe_scan3_env "$file"
	expect_expr "$facet" '(absolute-paths)' "($file)"
	expect_expr "$facet" '(relative-paths)' "($tfile)"

	ln $file $file-2
	expect_expr "$facet" '(absolute-paths)' "($file $file-2)"
	expect_expr "$facet" '(relative-paths)' "($tfile $tfile-2)"

	ln $file $file-3
	expect_expr "$facet" '(absolute-paths)' "($file $file-2 $file-3)"
	expect_expr "$facet" '(relative-paths)' "($tfile $tfile-2 $tfile-3)"
}
run_test 109 "lipe_scan3 paths thunks do the right thing"

test_110() {
	local facet=mds1
	local file=$MOUNT/$tfile
	local params
	local fd
	local a1
	local a2

	params=$($LCTL get_param 'llite.*.xattr_cache')
	$LCTL set_param 'llite.*.xattr_cache=0'
	stack_trap "$LCTL set_param $params"

	init_lipe_scan3_env
	echo XXX > "$file"
	sync

	# Try to get the SoM synced.
	exec {fd}<"$file"
	$LFS data_version -r "$file"
	stat "$file"
	exec {fd}<&-

	sync
	$LFS getsom "$file"
	lipe_scan3_facet "$facet" --print-json=som

	# file: /mnt/lustre/f110.sanity-lipe-scan3 size: 4 blocks: 8 flags: 4
	a1=$($LFS getsom "$file" | awk '{ print $4 }')
	a2=$(lipe_scan3_facet "$facet" --print-json=som | jq .som.size)
	((a1 == a2)) || error "som.size expected '$a1', got '$a2'"

	a1=$($LFS getsom "$file" | awk '{ print $6 }')
	a2=$(lipe_scan3_facet "$facet" --print-json=som | jq .som.blocks)
	((a1 == a2)) || error "som.blocks expected '$a1', got '$a2'"

	a1=$($LFS getsom "$file" | awk '{ print $8 }')
	a2=$(lipe_scan3_facet "$facet" --print-json=som | jq .som._flags)
	((a1 == a2)) || error "som.flags expected '$a1', got '$a2'"

	# .som.flags should be ["lazy"] here
}
run_test 110 "lipe_scan3 som attr works"

test_111() {
	local facet=mds1
	local file=$MOUNT/$tfile
	local fid
	local fid2

	init_lipe_scan3_env "$file"
	fid=$($LFS path2fid "$file")

	# {
	#  "lma": {
	#    "self_fid": "[0x200000bd9:0x8c:0x0]",
	#    "compat": [],
	#    "_compat": 0,
	#    "incompat": [],
	#    "_incompat": 0
	#  }
	# }

	fid2=$(lipe_scan3_facet "$facet" --print-json=lma |
	       jq --raw-output .lma.self_fid)
	[[ "$fid" == "$fid2" ]] ||
		error "lma.self_fid expected '$fid', got '$fid2'"
}
run_test 111 "lipe_scan3 lma attr does the right thing"

test_112() {
	local facet=mds1
	local file=$MOUNT/$tfile
	local hsm

	init_lipe_scan3_env "$file"

	# FIXME Make a better test.

	hsm=$(lipe_scan3_facet "$facet" --print-json='[hsm]')
	[[ "$hsm" == "{}" ]] || error "hsm expected '{}', got '$hsm'"
}
run_test 112 "lipe_scan3 hsm attr does the right thing"

test_113() {
	local facet=mds1
	local file=$MOUNT/$tfile
	local a2

	init_lipe_scan3_env "$file"

	# FIXME Make a better test. We scan the mds1 for
	# filter_fid. This just checks that ls3 understands the
	# filter_fid attr.

	a2=$(lipe_scan3_facet "$facet" --print-json='[filter_fid]')
	[[ "$a2" == "{}" ]] || error "filter_fid expected '', got '$a2'"
}
run_test 113 "lipe_scan3 filter_fid does the right thing"

test_120() {
	local facet=mds1
	local file=$MOUNT/$tfile

	init_lipe_scan3_env "$file"
	echo XXX > "$file"

	expect_expr $facet '(car (assoc \"trusted.lov\" (xattrs)))' trusted.lov
	expect_print lipe_scan3_format "$facet" '(xattr-ref \"trusted.lov\")'

	setfattr -n user.NAME -v VALUE "$file"
	expect_expr $facet '(car (assoc \"user.NAME\" (xattrs)))' user.NAME
	expect_print lipe_scan3_format "$facet" '(xattr-ref \"user.NAME\")'

	# expect_expr "$facet" '(xattr-ref-string "user.NAME")' VALUE
}
run_test 120 "lipe_scan3 xattrs does the right thing"

test_130() {
	local facet=mds1
	local file=$MOUNT/$tfile
	local -a ost_indexes

	init_lipe_scan3_env "$file"
	$LFS setstripe -c -1 "$file"
	ost_indexes=($($LFS getstripe --yaml "$file" | yq '.lmm_objects[] |
			.l_ost_idx'))

	expect_expr "$facet" '(lov-pool)' '()'
	expect_expr "$facet" '(lov-pools)' '()'
	expect_expr "$facet" '(lov-ost-indexes)' "(${ost_indexes[*]})"
}
run_test 130 "lipe_scan3 lov-pools and lov-ost-indexes do the right thing"

test_131() {
	local facet=mds1
	local file=$MOUNT/$tfile

	init_lipe_scan3_env "$file"
	expect_expr "$facet" '(lov-mirror-count)' 0
	expect_expr "$facet" '(lov-stripe-count)' 0

	$LFS setstripe -c 2 "$file"
	sync

	expect_expr "$facet" '(lov-mirror-count)' 1
	expect_expr "$facet" '(lov-stripe-count)' 2

	echo XXX > "$file"
	$LFS mirror extend -N -c $OSTCOUNT "$file"
	sync

	expect_expr "$facet" '(lov-mirror-count)' 2
	expect_expr "$facet" '(lov-stripe-count)' $OSTCOUNT
}
run_test 131 "lipe_scan3 lov-mirror-count and lov-stripe-count do the right thing"

test_200() {
	local facet=mds1
	local device="$(facet_device $facet)"
	local file=$MOUNT/$tfile
	local proc

	init_lipe_scan3_env "$file"

	lipe_scan3_format "$facet" '(lipe-scan-device-name)'
	expect_attr "$facet" lipe-scan-fsname "$FSNAME"
	expect_attr "$facet" lipe-scan-client-mount-path "$MOUNT"
	expect_attr "$facet" lipe-scan-device-name "$FSNAME-MDT0000"
	expect_attr "$facet" lipe-scan-device-path "$device"
	expect_attr "$facet" lipe-scan-thread-count 1 --thread-count=1
	expect_attr "$facet" lipe-scan-thread-count 2 --thread-count=2
	expect_attr "$facet" lipe-scan-thread-index 0 --thread-count=1

	for proc in \
		lipe-debug-enable \
		lipe-gettid \
		lipe-scan-client-mount-fd \
		lipe-scan-current-attrs \
		lipe-scan-thread-index; do
		expect_print lipe_scan3_format "$facet" "($proc)"
	done
}
run_test 200 "lipe-scan-* procedures do the right thing"

test_201() {
	local facet=mds1
	local file=$MOUNT/$tfile
	local rc

	init_lipe_scan3_env "$file"

	lipe_scan3_body "$facet" '(lipe-scan-break 7)'
	rc=$?
	((rc == 7)) || error "(lipe-scan-break 7) should return 7"
}
run_test 201 "lipe-scan-break works"

# lipe-scan-continue

test_300() {
	local facet=mds1
	local file=$MOUNT/$tfile
	local fid
	local out

	init_lipe_scan3_env "$file"
	fid=$($LFS path2fid "$file")

	lipe_scan3_facet "$facet" --print-file-fid

	out=$(lipe_scan3_facet "$facet" --print-file-fid)
	[[ "$out" == "$fid" ]] || error "--print-file-fid should print '$fid'"

	out=$(lipe_scan3_facet "$facet" --print-self-fid)
	[[ "$out" == "$fid" ]] || error "--print-self-fid should print '$fid'"
}
run_test 300 "--print-*-fid options work"

test_301() {
	local facet=mds1
	local file=$MOUNT/$tfile
	local fid
	local fd

	init_lipe_scan3_env
	echo XXX > "$file"
	sync

	# Try to get the SoM synced.
	exec {fd}<"$file"
	$LFS data_version -r "$file"
	stat "$file"
	exec {fd}<&-

	fid=$($LFS path2fid "$file")

	lipe_scan3_facet "$facet" --print-json | jq . ||
		error "--print-json should print JSON"
	lipe_scan3_facet "$facet" --print-json=#x0 | jq . ||
		error "--print-json should print JSON"
	lipe_scan3_facet "$facet" --print-json=#xffffffff | jq . ||
		error "--print-json should print JSON"
	lipe_scan3_facet "$facet" --print-json=all | jq . ||
		error "--print-json should print JSON"
	lipe_scan3_facet "$facet" --print-json=ino | jq . ||
		error "--print-json should print JSON"
}
run_test 301 "--print-json options work"

test_302() {
	local facet=mds1
	local file=$MOUNT/$tfile
	local out

	init_lipe_scan3_env "$file"

	out=$(lipe_scan3_facet "$facet" --print-absolute-path)
	[[ "$out" == "$file" ]] ||
		error "--print-absolute-path should print absolute path"

	out=$(lipe_scan3_facet "$facet" --print-relative-path)
	[[ "$out" == "$tfile" ]] ||
		error "--print-relative-path should print relative path"

	# TODO --null
	# TODO --delim
}
run_test 302 "--print-*-path options work"

test_303() {
	local facet=mds1
	local tmp1=$(mktemp)
	local tmp2=$(mktemp)

	init_lipe_scan3_env

	$LFS mkdir -c $MDSCOUNT $MOUNT/$tdir
	$LFS mkdir -c $MDSCOUNT $MOUNT/$tdir/d{0..3}
	$LFS mkdir -c 1 -i 0 $MOUNT/$tdir/d{0..3}/d{0..3}
	touch $MOUNT/$tdir/d{0..3}/d{0..3}/f{0..3}
	sync

	# XXX lipe_scan3 does not return the ROOT
	(echo "$MOUNT"; lipe_scan3_facet "$facet" --print-absolute-path) |
		sort > $tmp1
	lfs find "$MOUNT" --mdt-index 0 | sort > $tmp2
	diff $tmp1 $tmp2 ||
		error "--print-absolute-path should print the right paths"
}
run_test 303 "--print-absolute-paths prints the right paths"

test_304() {
	local facet=mds1
	local file=$MOUNT/$tfile
	local out
	local expect

	init_lipe_scan3_env "$file"

	ln "$file" "$file-1"
	ln "$file" "$file-2"
	sync

	out=$(lipe_scan3_facet "$facet" --print-absolute-path)
	[[ "$out" == "$file" ]] ||
		error "print-absolute-path got '$out', expected '$file"

	out=$(lipe_scan3_facet "$facet" --print-absolute-path --all-paths |
	      sort)
	expect=$(ls "$file"*)

	[[ "$out" == "$expect" ]] ||
		error "print-absolute-path got '$out', expected '$expect'"

	out=$(lipe_scan3_facet "$facet" --print-relative-path)
	[[ "$out" == "$tfile" ]] ||
		error "print-absolute-path got '$out', expected '$tfile"

	out=$(lipe_scan3_facet "$facet" --print-relative-path --all-paths |
	      sort)
	expect=$(ls "$MOUNT")
	[[ "$out" == "$expect" ]] ||
		error "print-relative-path got '$out', expected '$expect'"
}
run_test 304 "print-*-paths with multiple links"

test_305() {
	local facet=mds1
	local file
	local fid
	local mdt_index
	local out

	init_lipe_scan3_env

	$LFS mkdir -c $MDSCOUNT $MOUNT/$tdir
	$LFS mkdir -c $MDSCOUNT $MOUNT/$tdir/d0
	$LFS mkdir -c 1 -i 0 $MOUNT/$tdir/d0/d0
	file=$MOUNT/$tdir/d0/d0/f0
	touch $file
	fid=$($LFS path2fid $file)
	mdt_index=$($LFS getstripe --mdt-index $file)
	((mdt_index == 0)) || error "expected MDT index 0, got '$mdt_index'"
	sync

	out=$(lipe_scan3_facet "$facet" --print-json=file_fid,paths |
	      jq --raw-output --arg FID "$fid" 'select(.file_fid == $FID) |
	      .paths[]')
	[[ "$out" == "$tdir/d0/d0/f0" ]] ||
		error "JSON got '$out', expected '$tdir/d0/d0/f0'"

	ln "$file" "$file"-1
	ln "$file" "$file"-2
	sync

	out=$(lipe_scan3_facet "$facet" --print-json=file_fid,paths |
	      jq --raw-output --arg FID "$fid" 'select(.file_fid == $FID) |
	      .paths[0]')
	[[ "$out" == "$tdir/d0/d0/f0" ]] ||
		error "JSON got '$out', expected '$tdir/d0/d0/f0'"

	out=$(lipe_scan3_facet "$facet" --print-json=file_fid,paths |
	      jq --raw-output --arg FID "$fid" 'select(.file_fid == $FID) |
	      .paths[1]')
	[[ "$out" == "$tdir/d0/d0/f0-1" ]] ||
		error "JSON got '$out', expected '$tdir/d0/d0/f0-1'"

	out=$(lipe_scan3_facet "$facet" --print-json=file_fid,paths |
	      jq --raw-output --arg FID "$fid" 'select(.file_fid == $FID) |
	      .paths[2]')
	[[ "$out" == "$tdir/d0/d0/f0-2" ]] ||
		error "JSON got '$out', expected '$tdir/d0/d0/f0-2'"
}
run_test 305 "print-json prints the right paths"

create_files() {
	local num_files=$1
	local file=$2

	# 123Mb
	fallocate -l 125952K "$file"
	[[ $? -ne 0 ]] && error "fallocate N0 ended with an error"
	sync

	# Create many small files of different sizes
	for ((i = 0; i < $num_files; i++)); do
		fallocate -l $((RANDOM % 125 + 1))K $file"_"$i
	done
	sync
}

# Test for --collect-fsize-stats policy
test_306() {
	local facet=mds1
	local report_path="$MOUNT/$tfile.json"
	local file=$MOUNT/$tfile
	local tmp_id=1000000123
	local count_files_ls
	local total_size_ls
	local id_from_report
	local count_files
	local total_size

	init_lipe_scan3_env "$file"
	create_files 3000 "$file"
	chown "$tmp_id:$tmp_id" $file
	[[ $? -ne 0 ]] && error "chown ended with an error"

	sync
	count_files_ls=$(ls -1 "$MOUNT" | grep -vE '^total' | wc -l)
	total_size_ls=$(ls -l "$MOUNT" | grep '^total' | awk '{print $2}')

	(( count_files_ls > 2 )) || error "fallocate N1 ended with an error"

	out=$(lipe_scan3_facet "$facet" --collect-fsize-stats="$report_path")

	[[ $? -ne 0 ]] && error "lipe_scan3 collect-fsize-stats failed"

	[[ -f "$report_path" ]] || error "File with report not found."

	count_files=$(cat "$report_path" |
		      jq -r '.Reports[] | select(.GeneralInfo.Title ==
		      "Capacity used (Regular files space used on disk)") |
		      .GeneralInfo | .Count' | grep -oE '[0-9]+')

	total_size=$(cat "$report_path" |
		     jq '.Reports[] | select(.GeneralInfo.Title ==
		     "Capacity used (Regular files space used on disk)") |
		     .GeneralInfo.TotalValue | floor')

	id_from_report=$(cat "$report_path" |
			 jq '.UserTimeReports[] |
			 select(.UserName == "NULL") |
			 .UserUID' | grep -oE '[0-9]+')

	(( count_files == count_files_ls )) ||
		error "expected no_of_files value '$count_files_ls', got '$count_files'"

	(( total_size == total_size_ls )) ||
		error "expected total_size value '$total_size_ls', got '$total_size'"

	(( tmp_id == id_from_report )) ||
		error "expected UID value '$tmp_id', got '$id_from_report'"

	echo "--collect-fsize-stats works"
}
run_test 306 "lipe_scan3 --collect-fsize-stats works correctly"

test_307() {
	local facet=mds1
	local main_dir=$DIR/$tdir
	local report_path="$MOUNT/$tfile.json"
	local file=$MOUNT/$tfile
	local dir_name_report
	local rating_length
	local dir_size
	local one_mb=1048576
	local thirty_mb=$(($one_mb * 30))

	init_lipe_scan3_env "$file"

	lfs mkdir -i 0 "$main_dir"
	cd "$main_dir" && fallocate -l 30M "$tfile"_X
	lfs somsync "$tfile"_X
	sync_all_data

	out=$(lipe_scan3_facet "$facet" --collect-fsize-stats="$report_path")
	(( $? == 0 )) || error "lipe_scan3 collect-fsize-stats failed"

	# Display a report for checking and debugging
	cat "$report_path"

	dir_name_report=$(cat "$report_path" |
		jq -r '.DirectoriesStats.MainTree.ChildDirectories[0].DirectoryName')

	[[ "$dir_name_report" == "$tdir" ]] ||
		error "expected dir_name value '$tdir', got '$dir_name_report'"

	dir_size=$(cat "$report_path" |
		jq -r '.DirectoriesStats.MainTree.ChildDirectories[0].SizeBytes')

	(( $dir_size >= $thirty_mb )) ||
		error "expected dir_size value $thirty_mb, got '$dir_size'"

	rating_length=$(cat "$report_path" |
			jq -r '.DirectoriesStats.Rating | length')

	(( rating_length > 0 )) || error "rating table is empty"

	rm -rf "$main_dir"
}
run_test 307 "lipe_scan3 checking the availability of directories statistics"

# Test for --collect-fsize-stats
# This test does not require any checks, and serves only to show the
# contents of the report with statistics on file sizes/directories
# obtained through the option --collect-fsize-stats
test_308() {
	local facet=mds1
	local main_dir=$DIR/$tdir
	local report_path="$MOUNT/$tfile.out"
	local file=$MOUNT/$tfile
	init_lipe_scan3_env "$file"

	mkdir -p $main_dir
	cd $main_dir

	for i in {1..10}; do
		local dir_name="$main_dir"/tmp_dir"$i"
		local num_files=$((RANDOM % 21 + 20))

		mkdir -p "$dir_name"
		cd "$dir_name"
		for ((j = 1; j <= num_files; j++)); do
			local f_name="$tfile".file"$j"
			local file_size=$((RANDOM % 10 + 1))

			fallocate -l "$file_size"M "$f_name"
			lfs somsync "$f_name"
		done
		cd ..
	done

	fallocate -l 200G "$file"
	lfs somsync "$file"
	sync

	out=$(lipe_scan3_facet "$facet" --collect-fsize-stats="$report_path")
	[[ $? -ne 0 ]] && error "lipe_scan3 collect-fsize-stats failed"

	cat "$report_path"
	rm -rf $main_dir

	wait_delete_completed_mds
}
run_test 308 "lipe_scan3 --collect-fsize-stats report.out"

# Test for --merge-reports
test_309() {
	local facet=mds1
	local report_dir=$DIR/$tdir
	local main_dir="$DIR/$tdir.x"
	local report_path_g="$DIR/$tfile.json"
	local report_path_cp1="$report_dir""/1.json"
	local report_path_cp2="$report_dir""/2.json"
	local s_cnt_files
	local s_total_size_f
	local s_total_size_d
	local s_min_size
	local s_max_size
	local s_tree_length
	local m_cnt_files
	local m_total_size
	local m_total_size_d
	local m_min_size
	local m_max_size
	local file=$DIR/$tfile
	local files_count=100
	local r_path

	init_lipe_scan3_env "$file"
	create_files $files_count "$file"
	stack_trap "rm -f $file*"

	mkdir -p $main_dir
	stack_trap "rm -rf $main_dir"
	cd $main_dir

	for i in {1..10}; do
		local dir_name="$main_dir"/tmp_dir"$i"
		local num_files=$((RANDOM % 21 + 20))

		mkdir -p "$dir_name"
		cd "$dir_name"
		for ((j = 1; j <= num_files; j++)); do
			local f_name="$tfile".file"$j"
			local file_size=$((RANDOM % 10 + 1))

			fallocate -l "$file_size"M "$f_name"
			lfs somsync "$f_name"
		done
		cd ..
	done
	sync

	out=$(lipe_scan3_facet "$facet" --collect-fsize-stats="$report_path_g")
	[[ $? -ne 0 ]] && error "lipe_scan3 collect-fsize-stats failed"


	s_cnt_files=$(cat "$report_path_g" |
		      jq -r '.Reports[] | select(.GeneralInfo.Title ==
		      "Capacity used (Regular files space used on disk)") |
		      .GeneralInfo | .Count' | grep -oE '[0-9]+')

	s_total_size_f=$(cat "$report_path_g" |
		       jq '.Reports[] | select(.GeneralInfo.Title ==
		       "Capacity used (Regular files space used on disk)") |
		       .GeneralInfo.TotalValue | floor')
	s_min_size=$(cat "$report_path_g" |
		     jq '.Reports[] | select(.GeneralInfo.Title ==
		     "Capacity used (Regular files space used on disk)") |
		     .GeneralInfo.Min | floor')
	s_max_size=$(cat "$report_path_g" |
		     jq '.Reports[] | select(.GeneralInfo.Title ==
		     "Capacity used (Regular files space used on disk)") |
		     .GeneralInfo.Max | floor')

	s_total_size_d=$(cat "$report_path_g" |
			 jq '.DirectoriesStats.TotalSizeBytes')

	s_tree_length=$(cat "$report_path_g" |
			jq -r '.DirectoriesStats.MainTree.ChildDirectories |
			length')

	s_cnt_files=$(($s_cnt_files * 2))
	s_total_size_f=$(($s_total_size_f * 2))
	s_total_size_d=$(($s_total_size_d * 2))
	cat $report_path_g	# for debug

	# Merge reports
	mkdir -p $report_dir || error "can't create $report_dir"
	stack_trap "rm -rf $report_dir"
	cp -a $report_path_g $report_path_cp1 ||
		error "couldn't make a copy $report_path_cp1"
	cp -a $report_path_g $report_path_cp2 ||
		error "couldn't make a copy $report_path_cp2"
	out=$(lipe_scan3_facet "$facet" --merge-reports="$report_dir")
	[[ $? -ne 0 ]] && error "lipe_scan3 merge-reports failed"
	ls -loh $report_dir

	m_cnt_files=$(cat "$report_dir"/merged_report.json |
		      jq -r '.Reports[] | select(.GeneralInfo.Title ==
		      "Capacity used (Regular files space used on disk)") |
		      .GeneralInfo | .Count' | grep -oE '[0-9]+')

	m_total_size=$(cat "$report_dir"/merged_report.json |
		       jq '.Reports[] | select(.GeneralInfo.Title ==
		       "Capacity used (Regular files space used on disk)") |
		       .GeneralInfo.TotalValue | floor')

	m_min_size=$(cat "$report_dir"/merged_report.json |
		     jq '.Reports[] | select(.GeneralInfo.Title ==
		     "Capacity used (Regular files space used on disk)") |
		     .GeneralInfo.Min | floor')

	m_max_size=$(cat "$report_dir"/merged_report.json |
		     jq '.Reports[] | select(.GeneralInfo.Title ==
		     "Capacity used (Regular files space used on disk)") |
		     .GeneralInfo.Max | floor')

	m_total_size_d=$(cat "$report_dir"/merged_report.json |
			 jq '.DirectoriesStats.TotalSizeBytes')


	m_tree_length=$(cat "$report_dir"/merged_report.json |
			jq -r '.DirectoriesStats.MainTree.ChildDirectories |
			length')

	# Checks
	cat "$report_dir"/merged_report.json	# for debug

	(( m_cnt_files == s_cnt_files )) ||
		error "expected cnt_files value '$s_cnt_files', got '$m_cnt_files'"

	(( m_total_size == s_total_size_f )) ||
		error "expected total_size value '$s_total_size_f', got '$m_total_size'"

	(( s_min_size == m_min_size )) ||
		error "expected min value '$s_min_size', got '$m_min_size'"

	(( s_max_size == m_max_size )) ||
		error "expected max value '$s_max_size', got '$m_max_size'"

	(( s_total_size_d == m_total_size_d )) ||
		error "expected dirs total size '$s_total_size_d', got '$m_total_size_d'"

	# since simulate here the merging of striped directories,
	# the number of positions in the tree should not have changed
	(( s_tree_length == m_tree_length )) ||
		error "number of directories does not match"

	wait_delete_completed_mds
}
run_test 309 "lipe_scan3 --merge-reports=/DirWithReports/"
# loading and scripts

test_400() {
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}

	expect_empty lipe_scan3_on $facet --script=/dev/null
	expect_empty lipe_scan3_on $facet -s /dev/null
	expect_empty lipe_scan3_on $facet --load=/dev/null --script=/dev/null
	expect_empty lipe_scan3_on $facet -l /dev/null -s /dev/null
}
run_test 400 "empty scripts and loaded files"

test_401() {
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local rc

	do_facet $facet "echo '#t' | lipe_scan3 --script=/dev/stdin"
	rc=$?
	((rc == 0)) || error "rc expect 0, got '$rc'"

	do_facet $facet "echo '#f' | lipe_scan3 --script=/dev/stdin"
	rc=$?
	((rc == 1)) || error "rc expect 1, got '$rc'"

	do_facet $facet "echo '0' | lipe_scan3 --script=/dev/stdin"
	rc=$?
	((rc == 0)) || error "rc expect 0, got '$rc'"

	do_facet $facet "echo '7' | lipe_scan3 --script=/dev/stdin"
	rc=$?
	((rc == 7)) || error "rc expect 7, got '$rc'"

	do_facet $facet "echo 'cons' | lipe_scan3 --script=/dev/stdin"
	rc=$?
	((rc == 0)) || error "rc expect 0, got '$rc'"

	do_facet $facet "echo \\\"'()\\\" | lipe_scan3 --script=/dev/stdin"
	rc=$?
	((rc == 0)) || error "rc expect 0, got '$rc'"
}
run_test 401 "lipe_scan3 script exit statuses work"

# TODO Run on OST.
# --print-file-fid works on OST
# --print-self-fid works on OST
# --print-absolute-paths works on OST
# --print-json on OST
# Automagic required attrs work on OST

FAIL_ON_ERROR=$SAVED_FAIL_ON_ERROR

complete_test $SECONDS
check_and_cleanup_lustre
exit_status
