#!/bin/bash
#
# Tests for Hot Pools feature.
# Hot Pools feature is implemented as two user space tools: lamigo and lpurge.
set -e

ONLY=${ONLY:-"$*"}

LUSTRE=${LUSTRE:-$(dirname $0)/..}
. $LUSTRE/tests/test-framework.sh
init_test_env $@
. ${CONFIG:=$LUSTRE/tests/cfg/$NAME.sh}
init_logging

ALWAYS_EXCEPT="$HOT_POOLS_EXCEPT "
always_except EX-3442  15

(( CLIENT_VERSION == MDS1_VERSION )) || skip_env "skipped for interop testing"

(( OSTCOUNT >= 2 )) || skip_env "need at least 2 OSTs"

remote_mds_nodsh && skip_env "remote MDS with nodsh"
remote_ost_nodsh && skip_env "remote OSS with nodsh"

# check if lamigo is installed on MDS(s) and lpurge is installed on OSS(s)
if ! local_mode; then
	do_nodes $(comma_list $(all_mgt_mdts_nodes)) "which lamigo" &>/dev/null ||
		skip_env "lamigo is not installed on MDS"
	do_nodes $(comma_list $(all_osts_nodes)) "which lpurge" &>/dev/null ||
		skip_env "lpurge is not installed on OSS"
else
	which lamigo &>/dev/null || skip_env "lamigo is not installed"
	which lpurge &>/dev/null || skip_env "lpurge is not installed"

fi

# check passwordless ssh setup among server nodes
for mds_node in $(all_mgt_mdts_nodes); do
	for oss_node in $(all_osts_nodes); do
		do_node $mds_node "ssh -o BatchMode=yes $oss_node hostname" \
			&>/dev/null ||
			skip_env "$mds_node to $oss_node needs passwordless ssh setup"

		do_node $oss_node "ssh -o BatchMode=yes $mds_node hostname" \
			&>/dev/null ||
			skip_env "$oss_node to $mds_node needs passwordless ssh setup"
	done
done

# lamigo configuration options
LAMIGO_MOUNT=${LAMIGO_MOUNT:-"$MOUNT"}
LAMIGO_SRC=${LAMIGO_SRC:-"fast"}
LAMIGO_TGT=${LAMIGO_TGT:-"slow"}
LAMIGO_AGE=${LAMIGO_AGE:-"15"}
LAMIGO_AGT_JOBS=${LAMIGO_AGT_JOBS:-"8"}
LAMIGO_THREAD_NUM=${LAMIGO_THREAD_NUM:-""}
LAMIGO_PROG_INTV=${LAMIGO_PROG_INTV:-""}
LAMIGO_CACHE=${LAMIGO_CACHE:-""}
LAMIGO_MIRROR_CMD=${LAMIGO_MIRROR_CMD:-""}
LAMIGO_RESYNC_CMD=${LAMIGO_RESYNC_CMD:-""}
LAMIGO_DEBUG=${LAMIGO_DEBUG:-true}
LAMIGO_RESCAN=${LAMIGO_RESCAN:-false}
LAMIGO_TIMESTAMPS=${LAMIGO_TIMESTAMPS:-true}
LAMIGO_VERBOSE=${LAMIGO_VERBOSE:-false}
LAMIGO_DUMP=${LAMIGO_DUMP:-""}
LAMIGO_EXTRA=${LAMIGO_EXTRA:-""}
LAMIGO_CLIENTS=${CLIENTS:-"$HOSTNAME"}
LAMIGO_CLIENTS=${LAMIGO_CLIENTS//,/ }
# pool compression "--slow-pool=name:lz4:level
LAMIGO_COMPRESSION=${LAMIGO_COMPRESSION:-""}
LAMIGO_STATS_MISSING=${LAMIGO_STATS_MISSING:-""}
LAMIGO_BG_SCAN=${LAMIGO_BG_SCAN:-false}
LAMIGO_BG_SCAN_RATE=${LAMIGO_BG_SCAN_RATE:-""}
LAMIGO_BG_SCAN_INTERVAL=${LAMIGO_BG_SCAN_INTERVAL:-""}

declare -a LAMIGO_MDT
declare -a LAMIGO_MDT_FACET
declare -a LAMIGO_USR
declare -a LAMIGO_CFG
declare -a LAMIGO_SRVFILE
declare -a LAMIGO_USERFILE
declare -a LAMIGO_DUMPFILE
declare -a LAMIGO_PIDFILE
declare -a LAMIGO_START_TIME

# lpurge configuration options
LPURGE_MOUNT=${LPURGE_MOUNT:-"$MOUNT"}
LPURGE_POOL=${LPURGE_POOL:-"$LAMIGO_SRC"}
LPURGE_FREEHI=${LPURGE_FREEHI:-""}
LPURGE_FREELO=${LPURGE_FREELO:-""}
LPURGE_MAX_JOBS=${LPURGE_MAX_JOBS:-""}
LPURGE_SCAN_RATE=${LPURGE_SCAN_RATE:-""}
LPURGE_SCAN_THREADS=${LPURGE_SCAN_THREADS:-""}
LPURGE_INTV=${LPURGE_INTV:-"30"}
LPURGE_SLOT_SIZE=${LPURGE_SLOT_SIZE:-""}
LPURGE_DEBUG=${LPURGE_DEBUG:-true}
LPURGE_TIMESTAMPS=${LPURGE_TIMESTAMPS:-true}
LPURGE_DUMP=${LPURGE_DUMP:-""}
LPURGE_DUMP_FIDS=${LPURGE_DUMP_FIDS:-""}
LPURGE_EXTRA=${LPURGE_EXTRA:-""}

declare -a LPURGE_DEV
declare -a LPURGE_DEV_FACET
declare -a LPURGE_MDS
declare -a LPURGE_CFG
declare -a LPURGE_SRVFILE
declare -a LPURGE_DUMPFILE
declare -a LPURGE_FIDS_DUMPFILE
declare -a LPURGE_PIDFILE
declare -a LPURGE_START_TIME

# create OST pools
create_ost_pools() {
	pool_add $LAMIGO_SRC || error "failed to create OST pool '$LAMIGO_SRC'"
	pool_add_targets $LAMIGO_SRC 0 $((OSTCOUNT / 2 - 1)) ||
		error "failed to add targets to OST pool '$LAMIGO_SRC'"
	pool_add $LAMIGO_TGT || error "failed to create OST pool '$LAMIGO_TGT'"
	pool_add_targets $LAMIGO_TGT $((OSTCOUNT / 2)) $((OSTCOUNT - 1)) ||
		error "failed to add targets to OST pool '$LAMIGO_TGT'"

	LAMIGO_AGT_NODES="${LAMIGO_AGT_NODES:-$(osts_nodes_in_pool $LAMIGO_SRC)}"
}

# initialize lamigo variables
init_lamigo_vars() {
	local i
	local facet
	local mdt

	for i in $(seq $MDSCOUNT); do
		facet=mds$i
		mdt=$(facet_svc $facet)

		LAMIGO_MDT+=("$mdt")
		LAMIGO_MDT_FACET+=("$facet")
		LAMIGO_USR+=("${CL_USERS[$facet]%% *}")

		LAMIGO_CFG+=("/etc/lamigo/lamigo-$mdt.conf")
		LAMIGO_SRVFILE+=("/etc/systemd/system/lamigo-$mdt.service")
		LAMIGO_USERFILE+=("/var/lib/lamigo-$mdt.chlg")
		LAMIGO_DUMPFILE+=("/var/run/lamigo-$mdt.stats")
		LAMIGO_PIDFILE+=("/var/run/lamigo-$mdt.pid")
		LAMIGO_START_TIME+=(0)
	done
}

# initialize lpurge variables
init_lpurge_vars() {
	local fast_osts="$(list_pool $FSNAME.$LAMIGO_SRC | sed -e 's/_UUID$//')"
	local ost
	local i
	local facet

	[[ -n "$fast_osts" ]] || fast_osts="$FSNAME-OST0000"

	for ost in $fast_osts; do
		LPURGE_DEV+=("$ost")
		LPURGE_DEV_FACET+=("$(ostfacet_from_ost $ost)")
		LPURGE_CFG+=("/etc/lpurge/lpurge-$ost.conf")
		LPURGE_SRVFILE+=("/etc/systemd/system/lpurge-$ost.service")
		LPURGE_DUMPFILE+=("/var/run/lpurge-$ost.stats")
		LPURGE_FIDS_DUMPFILE+=("/var/run/lpurge-$ost.fids")
		LPURGE_PIDFILE+=("/var/run/lpurge-$ost.pid")
		LPURGE_START_TIME+=(0)
	done

	for i in $(seq $MDSCOUNT); do
		ost=$(facet_svc mds$i)
		LPURGE_DEV+=("$ost")
		LPURGE_DEV_FACET+=("mds$i")
		LPURGE_CFG+=("/etc/lpurge/lpurge-$ost.conf")
		LPURGE_SRVFILE+=("/etc/systemd/system/lpurge-$ost.service")
		LPURGE_DUMPFILE+=("/var/run/lpurge-$ost.stats")
		LPURGE_FIDS_DUMPFILE+=("/var/run/lpurge-$ost.fids")
		LPURGE_PIDFILE+=("/var/run/lpurge-$ost.pid")
		LPURGE_START_TIME+=(0)
	done

	for i in $(seq $MDSCOUNT); do
		facet=mds$i
		LPURGE_MDS+=("$((i - 1)):$(facet_active_host $facet):$LPURGE_MOUNT")
	done
}

init_hot_pools_env() {
	local umount_nodes=$(exclude_items_from_list $(comma_list $(all_server_nodes)) \
			     $HOSTNAME)

	# mount Lustre clients on server nodes
	zconf_mount_clients $(comma_list $(all_server_nodes)) $MOUNT ||
		error "failed to mount Lustre clients on server nodes"
	if [[ -n "$umount_nodes" ]]; then
		stack_trap "zconf_umount_clients $umount_nodes $MOUNT"
	fi

	# enable changelog on MDT(s)
	if ${INIT_HOT_POOLS_CHANGELOG:-true}; then
		changelog_register
	fi

	# create OST pools
	create_ost_pools

	init_lamigo_vars
	init_lpurge_vars

	# disable filesystem-wide default LMV to mkdir on MDT0 by default
	local tmp=$(mktemp $TMP/setfattr.XXXXXXXXXX)
	getfattr -d -m trusted.dmv -e hex --absolute-names $MOUNT > $tmp
	if (( $? == 0 )); then
		! $LFS setdirstripe -D -i 0 --max-inherit 1 $MOUNT ||
			stack_trap "setfattr --restore $tmp; rm -f $tmp"
	fi
}

hot_pools_logfile() {
	local facet="$1"
	local tool="${2:-hot_pools}"
	local host="$(facet_active_host $facet)"
	local service="$(facet_svc $facet)"

	local prefix=$TESTLOG_PREFIX
	[[ -z "$TESTNAME" ]] || prefix+=".$TESTNAME"

	printf "${prefix}.${tool}-${service}_log.${host}.log"
}

lamigo_logfile() {
	local facet="$1"
	hot_pools_logfile $facet lamigo
}

lpurge_logfile() {
	local facet="$1"
	hot_pools_logfile $facet lpurge
}

build_test_filter
check_and_setup_lustre

# lamigo operations
check_one_lamigo_is_started() {
	local i=${1:-0}
	local facet=${LAMIGO_MDT_FACET[i]}
	local pid_file=${LAMIGO_PIDFILE[i]}
	local pid

	sleep 2
	pid=$(do_facet $facet "cat $pid_file")
	do_facet $facet "pkill --pidfile=${pid_file} --signal=0 lamigo" ||
		{ echo "failed to start lamigo with PID '$pid'"; return 1; }

	echo "lamigo $pid started"
}

check_lamigo_is_started() {
	local i
	for i in ${!LAMIGO_MDT[@]}; do
		check_one_lamigo_is_started $i || return ${PIPESTATUS[0]}
	done
}

start_one_lamigo_cmd() {
	local i=${1:-0}
	local cmd="lamigo"
	local mdt=${LAMIGO_MDT[i]}
	local facet=${LAMIGO_MDT_FACET[i]}
	local usr=${LAMIGO_USR[i]}
	local node

	cmd+=${mdt:+" -m $mdt"}
	cmd+=${LAMIGO_MOUNT:+" -M $LAMIGO_MOUNT"}

	for node in $LAMIGO_CLIENTS $LAMIGO_AGT_NODES; do
		cmd+=" -g $node:$LAMIGO_MOUNT:$LAMIGO_AGT_JOBS"
	done

	cmd+=${usr:+" -u $usr"}
	cmd+=${LAMIGO_SRC:+" --fast-pool=$LAMIGO_SRC"}
	cmd+=${LAMIGO_TGT:+" --slow-pool=$LAMIGO_TGT"}
	cmd+=${LAMIGO_COMPRESSION:+":$LAMIGO_COMPRESSION"}
	cmd+=${LAMIGO_AGE:+" --min-age=$LAMIGO_AGE"}
	cmd+=${LAMIGO_THREAD_NUM:+" --thread-number=$LAMIGO_THREAD_NUM"}
	cmd+=${LAMIGO_CACHE:+" --max-cache=$LAMIGO_CACHE"}
	cmd+=${LAMIGO_PROG_INTV:+" --progress-interval=$LAMIGO_PROG_INTV"}
	cmd+=${LAMIGO_MIRROR_CMD:+" --mirror-cmd=\"$LAMIGO_MIRROR_CMD\""}
	cmd+=${LAMIGO_RESYNC_CMD:+" --resync-cmd=\"$LAMIGO_RESYNC_CMD\""}
	cmd+=${LAMIGO_STATS_MISSING:+" --stats-missed=\"$LAMIGO_STATS_MISSING\""}
	cmd+=${LAMIGO_BG_SCAN_RATE:+" --bg-scan-rate=\"$LAMIGO_BG_SCAN_RATE\""}
	cmd+=${LAMIGO_BG_SCAN_INTERVAL:+" --bg-scan-interval=\"$LAMIGO_BG_SCAN_INTERVAL\""}

	cmd+=${LAMIGO_DUMP:+" -w ${LAMIGO_DUMP}.$mdt"}

	! $LAMIGO_DEBUG || cmd+=" --debug"
	! $LAMIGO_RESCAN || cmd+=" --rescan"
	! $LAMIGO_BG_SCAN || cmd+=" --bg-scan"
	! $LAMIGO_TIMESTAMPS || cmd+=" --timestamps"
	! $LAMIGO_VERBOSE || cmd+=" --verbose"

	cmd+=" $LAMIGO_EXTRA_OPT"

	echo "Start lamigo on MDS $(facet_active_host $facet): $cmd"
	do_facet $facet "$cmd &> $(lamigo_logfile $facet)" &
	sleep 2
}

start_lamigo_cmd() {
	local i
	for i in ${!LAMIGO_MDT[@]}; do
		start_one_lamigo_cmd $i
	done
}

stop_one_lamigo_cmd() {
	local i=${1:-0}
	local facet=${LAMIGO_MDT_FACET[i]}
	local pid_file=${LAMIGO_PIDFILE[i]}
	local pid=$(do_facet $facet "cat $pid_file")

	[[ -n "$pid" ]] || { echo "cannot find lamigo PID"; return 0; }

	do_facet $facet "pkill --pidfile=${pid_file} lamigo" ||
		error "failed to stop lamigo '$pid'"

	echo "lamigo $pid stopped"
}

stop_lamigo_cmd() {
	local i
	for i in ${!LAMIGO_MDT[@]}; do
		stop_one_lamigo_cmd $i
	done
}

create_one_lamigo_cfg() {
	local i=${1:-0}
	local mdt=${LAMIGO_MDT[i]}
	local facet=${LAMIGO_MDT_FACET[i]}
	local usr=${LAMIGO_USR[i]}
	local cfg_file=${LAMIGO_CFG[i]}

	[[ -n $cfg_file ]] || error "lamigo configuration file is not defined"

	local cfg_dir=$(dirname $cfg_file)
	do_facet $facet "mkdir -p $cfg_dir;
			 [[ ! -e $cfg_file ]] || mv $cfg_file{,.saved}"
	stack_trap "do_facet $facet \"[[ -e ${cfg_file}.saved ]] &&
			mv $cfg_file{.saved,} || rm -f $cfg_file\""

	do_facet $facet "\
		[[ -z \\\"$mdt\\\" ]] ||
			echo mdt=\\\"$mdt\\\" > $cfg_file;
		[[ -z \\\"$LAMIGO_MOUNT\\\" ]] ||
			echo mount=\\\"$LAMIGO_MOUNT\\\" >> $cfg_file;
		for node in $LAMIGO_CLIENTS $LAMIGO_AGT_NODES; do
			echo agent=\\\$node:$LAMIGO_MOUNT:$LAMIGO_AGT_JOBS >> \
				$cfg_file;
		done;
		[[ -z \\\"$usr\\\" ]] ||
			echo user=\\\"$usr\\\" >> $cfg_file;
		[[ -z \\\"$LAMIGO_SRC\\\" ]] ||
			echo src=\\\"$LAMIGO_SRC\\\" >> $cfg_file;
		if [[ -z \\\"$LAMIGO_COMPRESSION\\\" ]]; then
			[[ -z \\\"$LAMIGO_TGT\\\" ]] ||
				echo slow-pool=\\\"$LAMIGO_TGT\\\" >> $cfg_file;
		else
			[[ -z \\\"$LAMIGO_TGT\\\" ]] ||
				echo slow-pool=\\\"$LAMIGO_TGT:$LAMIGO_COMPRESSION\\\" \
					>> $cfg_file;
		fi
		[[ -z \\\"$LAMIGO_AGE\\\" ]] ||
			echo min-age=\\\"$LAMIGO_AGE\\\" >> $cfg_file;
		[[ -z \\\"$LAMIGO_CACHE\\\" ]] ||
			echo max-cache=\\\"$LAMIGO_CACHE\\\" >> $cfg_file;
		[[ -z \\\"$LAMIGO_THREAD_NUM\\\" ]] ||
			echo thread-number=\\\"$LAMIGO_THREAD_NUM\\\" >> \
				$cfg_file;
		[[ -z \\\"$LAMIGO_PROG_INTV\\\" ]] ||
			echo progress-interval=\\\"$LAMIGO_PROG_INTV\\\" >> \
				$cfg_file;
		[[ -z \\\"$LAMIGO_EXTRA\\\" ]] ||
			echo \\\"$LAMIGO_EXTRA\\\" >> $cfg_file;
		[[ -z \\\"$LAMIGO_MIRROR_CMD\\\" ]] ||
			echo mirror-cmd=\\\"$LAMIGO_MIRROR_CMD\\\" >> $cfg_file;
		[[ -z \\\"$LAMIGO_RESYNC_CMD\\\" ]] ||
			echo resync-cmd=\\\"$LAMIGO_RESYNC_CMD\\\" >> $cfg_file;
		[[ -z \\\"$LAMIGO_DUMP\\\" ]] ||
			echo dump=\\\"${LAMIGO_DUMP}.$mdt\\\" >> $cfg_file;
		[[ -z \\\"$LAMIGO_STATS_MISSING\\\" ]] ||
			echo stats-missed=\\\"$LAMIGO_STATS_MISSING\\\" >> $cfg_file;
		[[ -z \\\"$LAMIGO_BG_SCAN_RATE\\\" ]] ||
			echo bg-scan-rate=\\\"$LAMIGO_BG_SCAN_RATE\\\" >> $cfg_file;
		[[ -z \\\"$LAMIGO_BG_SCAN_INTERVAL\\\" ]] ||
			echo bg-scan-interval=\\\"$LAMIGO_BG_SCAN_INTERVAL\\\" >> $cfg_file;
		! $LAMIGO_DEBUG || echo debug >> $cfg_file;
		! $LAMIGO_BG_SCAN || echo bg-scan >> $cfg_file;
		! $LAMIGO_RESCAN || echo rescan >> $cfg_file;
		! $LAMIGO_TIMESTAMPS || echo timestamps >> $cfg_file;
		! $LAMIGO_VERBOSE || echo verbose >> $cfg_file;"

	echo "lamigo configuration file $cfg_file:"
	do_facet $facet "cat $cfg_file"
}

create_lamigo_cfg() {
	local i
	for i in ${!LAMIGO_MDT[@]}; do
		create_one_lamigo_cfg $i
	done
}

start_one_lamigo_cfg() {
	local i=${1:-0}
	local facet=${LAMIGO_MDT_FACET[i]}
	local cfg_file=${LAMIGO_CFG[i]}
	local cmd="lamigo"

	create_one_lamigo_cfg $i

	cmd+=" -f $cfg_file"

	echo "Start lamigo on MDS $(facet_active_host $facet): $cmd"
	do_facet $facet "$cmd &> $(lamigo_logfile $facet)" &
	sleep 2
}

start_lamigo_cfg() {
	local i
	for i in ${!LAMIGO_MDT[@]}; do
		start_one_lamigo_cfg $i
	done
}

stop_one_lamigo_cfg() {
	local i=${1:-0}
	local facet=${LAMIGO_MDT_FACET[i]}
	local cfg_file=${LAMIGO_CFG[i]}

	stop_one_lamigo_cmd $i
	do_facet $facet "[[ -e ${cfg_file}.saved ]] &&
			 mv $cfg_file{.saved,} || rm -f $cfg_file"
}

stop_lamigo_cfg() {
	local i
	for i in ${!LAMIGO_MDT[@]}; do
		stop_one_lamigo_cfg $i
	done
}

create_one_lamigo_service() {
	local i=${1:-0}
	local facet=${LAMIGO_MDT_FACET[i]}
	local cfg_file=${LAMIGO_CFG[i]}
	local srv_file=${LAMIGO_SRVFILE[i]}

	[[ -n $srv_file ]] || error "lamigo service file is not defined"

	local cfg_dir=$(dirname $cfg_file)
	local srv_dir=$(dirname $srv_file)
	do_facet $facet "mkdir -p $srv_dir;
			 [[ ! -e $srv_file ]] || mv $srv_file{,.saved}"
	stack_trap "do_facet $facet \"[[ -e ${srv_file}.saved ]] &&
			mv $srv_file{.saved,} || rm -f $srv_file\""

	do_facet $facet "lamigo=\\\$(which lamigo);
cat > $srv_file <<EOF
[Unit]
Description=lamigo, userspace daemon to monitor MDT via client and replicate files out of pool

Requires=network-online.target
ConditionPathExists=$cfg_dir

[Service]
Restart=always
RestartSec=1
ExecStart=\\\$lamigo -f $cfg_file

[Install]
WantedBy=multi-user.target
EOF"
	echo "lamigo service file $srv_file:"
	do_facet $facet "cat $srv_file"
}

create_lamigo_service() {
	local i
	for i in ${!LAMIGO_MDT[@]}; do
		create_one_lamigo_service $i
	done
}

start_one_lamigo_service() {
	local i=${1:-0}
	local mdt=${LAMIGO_MDT[i]}
	local facet=${LAMIGO_MDT_FACET[i]}

	local start_cmd="systemctl daemon-reload; systemctl start lamigo-$mdt"
	local status_cmd="systemctl status lamigo-$mdt"

	create_one_lamigo_cfg $i
	create_one_lamigo_service $i

	echo "Start lamigo on MDS $(facet_active_host $facet): $start_cmd"
	LAMIGO_START_TIME[i]=$SECONDS
	do_facet $facet "$start_cmd" || error "failed to start lamigo service"
	sleep 2
	do_facet $facet "$status_cmd"
}

start_lamigo_service() {
	local i
	for i in ${!LAMIGO_MDT[@]}; do
		start_one_lamigo_service $i
	done
}

stop_one_lamigo_service() {
	local i=${1:-0}
	local mdt=${LAMIGO_MDT[i]}
	local facet=${LAMIGO_MDT_FACET[i]}
	local srv_file=${LAMIGO_SRVFILE[i]}
	local pid_file=${LAMIGO_PIDFILE[i]}
	local pid=$(do_facet $facet "cat $pid_file")
	local duration=$((SECONDS - LAMIGO_START_TIME[i] + 10))

	local jctl_cmd="journalctl --since \\\"$duration seconds ago\\\""
	jctl_cmd+=" -u lamigo-$mdt &> $(lamigo_logfile $facet)"
	local stop_cmd="systemctl stop lamigo-$mdt"

	[[ -n "$pid" ]] || { echo "cannot find lamigo PID"; return 0; }

	do_facet $facet "$jctl_cmd"
	do_facet $facet "$stop_cmd" || error "failed to stop lamigo"

	echo "lamigo $pid stopped"

	do_facet $facet "[[ -e ${srv_file}.saved ]] &&
			 mv $srv_file{.saved,} || rm -f $srv_file"
}

stop_lamigo_service() {
	local i
	for i in ${!LAMIGO_MDT[@]}; do
		stop_one_lamigo_service $i
	done
}

dump_one_lamigo_stats() {
	local i=${1:-0}
	local mdt=${LAMIGO_MDT[i]}
	local facet=${LAMIGO_MDT_FACET[i]}
	local dump_file=${LAMIGO_DUMPFILE[i]}
	local pid_file=${LAMIGO_PIDFILE[i]}
	local pid=$(do_facet $facet "cat $pid_file")

	[[ -n "$pid" ]] || { echo "cannot find lamigo PID"; return 0; }

	do_facet $facet "kill -USR1 $pid"
	sleep 1
	if [[ -n $LAMIGO_DUMP ]]; then
		do_facet $facet "cat ${LAMIGO_DUMP}.$mdt"
	else
		do_facet $facet "cat $dump_file"
	fi
}

dump_lamigo_stats() {
	local i
	for i in ${!LAMIGO_MDT[@]}; do
		dump_one_lamigo_stats $i
	done
}

verify_one_lamigo_param() {
	local i=${1:-0}
	local param="$2"
	local expected="$3"
	local value
	local max=30
	local j

	for ((j = 0; j < $max; j++)); do
		# FIXME Use yq to extract param value.
		value=$(dump_one_lamigo_stats $i |
			awk -v param="$param" '$1 == param ":" { print $2 }')

		[[ -n "$expected" ]] || {
			echo "Default value '$value' is used for '$param'."
			return 0
		}

		[[ "$value" != "$expected" ]] || break
		sleep 1
	done

	(( j < max )) || {
		dump_one_lamigo_stats $i
		error "failed to verify '$param': '$value' != '$expected'"
	}
}

bool2num() {
	[ "$1" == true ] && echo "1" || echo "0"
}

verify_one_lamigo_params() {
	local i=${1:-0}
	local mdt=${LAMIGO_MDT[i]}
	local usr=${LAMIGO_USR[i]}
	local compression=${LAMIGO_COMPRESSION:-"none"}

	verify_one_lamigo_param $i chlg_user "$usr"
	verify_one_lamigo_param $i mdtname "$mdt"
	verify_one_lamigo_param $i mountpoint "$LAMIGO_MOUNT"
	verify_one_lamigo_param $i fast_pool "$LAMIGO_SRC"
	verify_one_lamigo_param $i slow_pool "$LAMIGO_TGT"
	verify_one_lamigo_param $i min_age "$LAMIGO_AGE"
	verify_one_lamigo_param $i max_cache "$LAMIGO_CACHE"
	verify_one_lamigo_param $i thread_count "$LAMIGO_THREAD_NUM"
	verify_one_lamigo_param $i progress_interval "$LAMIGO_PROG_INTV"
	verify_one_lamigo_param $i bg_scan $(bool2num "$LAMIGO_BG_SCAN")

	$LAMIGO_RESCAN && verify_one_lamigo_param $i rescan 1 ||
		verify_one_lamigo_param $i rescan 0
}

verify_lamigo_params() {
	local i
	for i in ${!LAMIGO_MDT[@]}; do
		verify_one_lamigo_params $i
	done
}

get_lamigo_chlg() {
	local i=${1:-0}
	local facet=${LAMIGO_MDT_FACET[i]}
	local user_file=${LAMIGO_USERFILE[i]}
	local chlg_user

	[[ -z $user_file ]] ||
		chlg_user=$(do_facet $facet "cat $user_file")

	echo -n "$chlg_user"
}

# lpurge operations
check_one_lpurge_is_started() {
	local i=${1:-0}
	local facet=${LPURGE_DEV_FACET[i]}
	local pid_file=${LPURGE_PIDFILE[i]}
	local pid

	sleep 2
	pid=$(do_facet $facet "cat $pid_file")
	do_facet $facet "pkill --pidfile=${pid_file} --signal=0 lpurge" ||
		{ echo "failed to start lpurge with PID '$pid'"; return 1; }

	echo "lpurge $pid started"
}

check_lpurge_is_started() {
	local i
	for i in ${!LPURGE_DEV[@]}; do
		check_one_lpurge_is_started $i || return ${PIPESTATUS[0]}
	done
}

start_one_lpurge_cmd() {
	local i=${1:-0}
	local cmd="lpurge"
	local dev=${LPURGE_DEV[i]}
	local facet=${LPURGE_DEV_FACET[i]}
	local j
	local mds

	cmd+=${dev:+" -D $dev"}
	cmd+=${LPURGE_MOUNT:+" -M $LPURGE_MOUNT"}

	for j in ${!LPURGE_MDS[@]}; do
		mds=${LPURGE_MDS[j]}
		cmd+=${mds:+" -m $mds"}
	done

	cmd+=${LPURGE_POOL:+" -p $LPURGE_POOL"}
	cmd+=${LPURGE_FREEHI:+" -h $LPURGE_FREEHI"}
	cmd+=${LPURGE_FREELO:+" -l $LPURGE_FREELO"}
	cmd+=${LPURGE_INTV:+" -i $LPURGE_INTV"}
	cmd+=${LPURGE_MAX_JOBS:+" -j $LPURGE_MAX_JOBS"}
	cmd+=${LPURGE_SCAN_THREADS:+" -t $LPURGE_SCAN_THREADS"}
	cmd+=${LPURGE_SCAN_RATE:+" -R $LPURGE_SCAN_RATE"}
	cmd+=${LPURGE_SLOT_SIZE:+" -S $LPURGE_SLOT_SIZE"}

	cmd+=${LPURGE_DUMP:+" -w ${LPURGE_DUMP}.$dev"}

	! $LPURGE_DEBUG || cmd+=" -b"
	! $LPURGE_TIMESTAMPS || cmd+=" --timestamps"

	echo "Start lpurge on OSS $(facet_active_host $facet): $cmd"
	do_facet $facet "$cmd &> $(lpurge_logfile $facet)" &
	sleep 2
}

start_lpurge_cmd() {
	local i
	for i in ${!LPURGE_DEV[@]}; do
		start_one_lpurge_cmd $i
	done
}

stop_one_lpurge_cmd() {
	local i=${1:-0}
	local facet=${LPURGE_DEV_FACET[i]}
	local pid_file=${LPURGE_PIDFILE[i]}
	local pid=$(do_facet $facet "cat $pid_file")

	[[ -n "$pid" ]] || { echo "cannot find lpurge PID"; return 0; }

	do_facet $facet "pkill --pidfile=${pid_file} lpurge" ||
		error "failed to stop lpurge '$pid'"

	echo "lpurge $pid stopped"
}

stop_lpurge_cmd() {
	local i
	for i in ${!LPURGE_DEV[@]}; do
		stop_one_lpurge_cmd $i
	done
}

create_one_lpurge_cfg() {
	local i=${1:-0}
	local dev=${LPURGE_DEV[i]}
	local facet=${LPURGE_DEV_FACET[i]}
	local cfg_file=${LPURGE_CFG[i]}
	local j
	local mds

	[[ -n $cfg_file ]] || error "lpurge configuration file is not defined"

	local cfg_dir=$(dirname $cfg_file)
	do_facet $facet "mkdir -p $cfg_dir;
			 [[ ! -e $cfg_file ]] || mv $cfg_file{,.saved}"
	stack_trap "do_facet $facet \"[[ -e ${cfg_file}.saved ]] &&
			mv $cfg_file{.saved,} || rm -f $cfg_file\""

	do_facet $facet "\
		[[ -z \\\"$dev\\\" ]] ||
			echo device=\\\"$dev\\\" > $cfg_file;
		[[ -z \\\"$LPURGE_MOUNT\\\" ]] ||
			echo mount=\\\"$LPURGE_MOUNT\\\" >> $cfg_file;
		[[ -z \\\"$LPURGE_POOL\\\" ]] ||
			echo pool=\\\"$LPURGE_POOL\\\" >> $cfg_file;
		[[ -z \\\"$LPURGE_FREEHI\\\" ]] ||
			echo freehi=\\\"$LPURGE_FREEHI\\\" >> $cfg_file;
		[[ -z \\\"$LPURGE_FREELO\\\" ]] ||
			echo freelo=\\\"$LPURGE_FREELO\\\" >> $cfg_file;
		[[ -z \\\"$LPURGE_INTV\\\" ]] ||
			echo interval=\\\"$LPURGE_INTV\\\" >> $cfg_file;
		[[ -z \\\"$LPURGE_MAX_JOBS\\\" ]] ||
			echo max_jobs=\\\"$LPURGE_MAX_JOBS\\\" >> $cfg_file;
		[[ -z \\\"$LPURGE_SCAN_THREADS\\\" ]] ||
			echo scan_threads=\\\"$LPURGE_SCAN_THREADS\\\" >> \
				$cfg_file;
		[[ -z \\\"$LPURGE_SCAN_RATE\\\" ]] ||
			echo scan_rate=\\\"$LPURGE_SCAN_RATE\\\" >> $cfg_file;
		[[ -z \\\"$LPURGE_SLOT_SIZE\\\" ]] ||
			echo slot_size=\\\"$LPURGE_SLOT_SIZE\\\" >> $cfg_file;
		[[ -z \\\"$LPURGE_EXTRA\\\" ]] ||
			echo \\\"$LPURGE_EXTRA\\\" >> $cfg_file;
		[[ -z \\\"$LPURGE_DUMP\\\" ]] ||
			echo dump=\\\"${LPURGE_DUMP}.$dev\\\" >> $cfg_file;
		! $LPURGE_DEBUG || echo debug >> $cfg_file;
		! $LPURGE_TIMESTAMPS || echo timestamps >> $cfg_file;"

	for j in ${!LPURGE_MDS[@]}; do
		mds=${LPURGE_MDS[j]}
		do_facet $facet "[[ -z \\\"$mds\\\" ]] ||
				 echo mds=\\\"$mds\\\" >> $cfg_file;"
	done

	echo "lpurge configuration file $cfg_file:"
	do_facet $facet "cat $cfg_file"
}

create_lpurge_cfg() {
	local i
	for i in ${!LPURGE_DEV[@]}; do
		create_one_lpurge_cfg $i
	done
}

start_one_lpurge_cfg() {
	local i=${1:-0}
	local facet=${LPURGE_DEV_FACET[i]}
	local cfg_file=${LPURGE_CFG[i]}
	local cmd="lpurge"

	create_one_lpurge_cfg $i

	cmd+=" -f $cfg_file"

	echo "Start lpurge on OSS $(facet_active_host $facet): $cmd"
	do_facet $facet "$cmd &> $(lpurge_logfile $facet)" &
	sleep 2
}

start_lpurge_cfg() {
	local i
	for i in ${!LPURGE_DEV[@]}; do
		start_one_lpurge_cfg $i
	done
}

stop_one_lpurge_cfg() {
	local i=${1:-0}
	local facet=${LPURGE_DEV_FACET[i]}
	local cfg_file=${LPURGE_CFG[i]}

	stop_one_lpurge_cmd $i
	do_facet $facet "[[ -e ${cfg_file}.saved ]] &&
			 mv $cfg_file{.saved,} || rm -f $cfg_file"
}

stop_lpurge_cfg() {
	local i
	for i in ${!LPURGE_DEV[@]}; do
		stop_one_lpurge_cfg $i
	done
}

create_one_lpurge_service() {
	local i=${1:-0}
	local facet=${LPURGE_DEV_FACET[i]}
	local cfg_file=${LPURGE_CFG[i]}
	local srv_file=${LPURGE_SRVFILE[i]}

	[[ -n $srv_file ]] || error "lpurge service file is not defined"

	local cfg_dir=$(dirname $cfg_file)
	local srv_dir=$(dirname $srv_file)
	do_facet $facet "mkdir -p $srv_dir;
			 [[ ! -e $srv_file ]] || mv $srv_file{,.saved}"
	stack_trap "do_facet $facet \"[[ -e ${srv_file}.saved ]] &&
			mv $srv_file{.saved,} || rm -f $srv_file\""

	do_facet $facet "lpurge=\\\$(which lpurge);
cat > $srv_file <<EOF
[Unit]
Description=lpurge, userspace daemon to monitor free space of OST/pool and release space by removing replicas --config $cfg_file

Requires=network-online.target
ConditionPathExists=$cfg_dir

[Service]
Restart=always
RestartSec=1
Type=simple
Environment=\\\"LPURGE_CONFIG=$cfg_file\\\"
ExecStart=\\\$lpurge -f $cfg_file

[Install]
WantedBy=multi-user.target
EOF"

	echo "lpurge service file $srv_file:"
	do_facet $facet "cat $srv_file"
}

create_lpurge_service() {
	local i
	for i in ${!LPURGE_DEV[@]}; do
		create_one_lpurge_service $i
	done
}

start_one_lpurge_service() {
	local i=${1:-0}
	local dev=${LPURGE_DEV[i]}
	local facet=${LPURGE_DEV_FACET[i]}

	local start_cmd="systemctl daemon-reload; systemctl start lpurge-$dev"
	local status_cmd="systemctl status lpurge-$dev"

	create_one_lpurge_cfg $i
	create_one_lpurge_service $i

	echo "Start lpurge on OSS $(facet_active_host $facet): $start_cmd"
	LPURGE_START_TIME[i]=$SECONDS
	do_facet $facet "$start_cmd" || error "failed to start lpurge service"
	sleep 2
	do_facet $facet "$status_cmd"
}

start_lpurge_service() {
	local i
	for i in ${!LPURGE_DEV[@]}; do
		start_one_lpurge_service $i
	done
}

stop_one_lpurge_service() {
	local i=${1:-0}
	local dev=${LPURGE_DEV[i]}
	local facet=${LPURGE_DEV_FACET[i]}
	local srv_file=${LPURGE_SRVFILE[i]}
	local pid_file=${LPURGE_PIDFILE[i]}
	local pid=$(do_facet $facet "cat $pid_file")
	local duration=$((SECONDS - LPURGE_START_TIME[i] + 10))

	local jctl_cmd="journalctl --since \\\"$duration seconds ago\\\""
	jctl_cmd+=" -u lpurge-$dev &> $(lpurge_logfile $facet)"
	local stop_cmd="systemctl stop lpurge-$dev"

	[[ -n "$pid" ]] || { echo "cannot find lpurge PID"; return 0; }

	do_facet $facet "$jctl_cmd"
	do_facet $facet "$stop_cmd" || error "failed to stop lpurge"

	echo "lpurge $pid stopped"

	do_facet $facet "[[ -e ${srv_file}.saved ]] &&
			 mv $srv_file{.saved,} || rm -f $srv_file"
}

stop_lpurge_service() {
	local i
	for i in ${!LPURGE_DEV[@]}; do
		stop_one_lpurge_service $i
	done
}

dump_one_lpurge_stats() {
	local i=${1:-0}
	local dev=${LPURGE_DEV[i]}
	local facet=${LPURGE_DEV_FACET[i]}
	local dump_file=${LPURGE_DUMPFILE[i]}
	local pid_file=${LPURGE_PIDFILE[i]}
	local pid=$(do_facet $facet "cat $pid_file")

	[[ -n "$pid" ]] || { echo "cannot find lpurge PID"; return 0; }

	do_facet $facet "kill -USR1 $pid"
	sleep 1
	if [[ -n $LPURGE_DUMP ]]; then
		do_facet $facet "cat ${LPURGE_DUMP}.$dev"
	else
		do_facet $facet "cat $dump_file"
	fi
}

dump_lpurge_stats() {
	local i
	for i in ${!LPURGE_DEV[@]}; do
		dump_one_lpurge_stats $i
	done
}

verify_one_lpurge_param() {
	local i=${1:-0}
	local param="$2"
	local expected="$3"
	local value
	local max=30
	local j

	for ((j = 0; j < $max; j++)); do
		value=$(dump_one_lpurge_stats $i |
			awk -v param="$param" '$1 == param ":" { print $2 }')

		[[ -n "$expected" ]] || {
			echo "Default value '$value' is used for '$param'."
			return 0
		}

		[[ "$value" != "$expected" ]] || break
		sleep 1
	done

	(( j < max )) || {
		dump_one_lpurge_stats $i
		error "failed to verify '$param': '$value' != '$expected'"
	}
}

verify_one_lpurge_params() {
	local i=${1:-0}
	local dev=${LPURGE_DEV[i]}

	verify_one_lpurge_param $i ostname "$dev"
	verify_one_lpurge_param $i mountpoint "$LPURGE_MOUNT"
	# verify_one_lpurge_param $i mds "$(comma_list ${LPURGE_MDS[@]})" EX-2718
	verify_one_lpurge_param $i pool "$LPURGE_POOL"
	verify_one_lpurge_param $i free_high "$LPURGE_FREEHI"
	verify_one_lpurge_param $i free_low "$LPURGE_FREELO"
	verify_one_lpurge_param $i check_interval "$LPURGE_INTV"
	verify_one_lpurge_param $i max_jobs "$LPURGE_MAX_JOBS"
	verify_one_lpurge_param $i scan_threads "$LPURGE_SCAN_THREADS"
	verify_one_lpurge_param $i scan_rate "$LPURGE_SCAN_RATE"
	verify_one_lpurge_param $i slot_size "$LPURGE_SLOT_SIZE"
}

verify_lpurge_params() {
	local i
	for i in ${!LPURGE_DEV[@]}; do
		verify_one_lpurge_params $i
	done
}

wait_file_resync() {
	local file="$1"
	local max=${2:-900}
	local i

	for ((i = 0; i < $max; i++)); do
		grep -q 'lcme_flags:.*stale' <<< $($LFS getstripe $file) ||
			break
		sleep 1
	done

	(( i < max )) || {
		$LFS getstripe $file
		error "$file still has stale component after $i seconds"
	}
}

wait_file_mirror() {
	local file="$1"
	local count="$2"
	local max=${3:-$((LAMIGO_AGE * 2))}
	local i

	for ((i = 0; i < $max; i++)); do
		[[ "$($LFS getstripe -N $file)" != "$count" ]] || break
		sleep 1
	done
}

verify_file_mirror() {
	local file="$1"
	local count="$2"
	local ids
	local id

	verify_mirror_count $file $count

	ids=($($LFS getstripe $file | awk '/lcme_id/{print $2}' | tr '\n' ' '))
	for id in "${ids[@]}"; do
		# last mirror should be on target pool, but not marked prefer
		if [[ "$id" = "${ids[${#ids[*]}-1]}" ]]; then
			verify_comp_attr pool $file $id $LAMIGO_TGT
			verify_comp_attr lcme_flags $file $id init,^prefer
		else
			verify_comp_attr pool $file $id $LAMIGO_SRC
			verify_comp_attr lcme_flags $file $id init
		fi
	done
}

verify_file_compress() {
	local file="$1"
	local compr="$2"
	local lvl="$3"
	local ids
	local id

	verify_mirror_count $file 2

	ids=($($LFS getstripe $file | awk '/lcme_id/{print $2}' | tr '\n' ' '))
	for id in "${ids[@]}"; do
		# last mirror should be on target pool, but not marked prefer
		if [[ "$id" = "${ids[${#ids[*]}-1]}" ]]; then
			verify_comp_attr pool $file $id $LAMIGO_TGT
			verify_comp_attr lcme_flags $file $id init,compress
			verify_comp_attr compr-type $file $id "$compr"
			verify_comp_attr compr-level $file $id "$lvl"
		else
			verify_comp_attr pool $file $id $LAMIGO_SRC
			verify_comp_attr lcme_flags $file $id init
		fi
	done
}

verify_file_size() {
	local file="$1"
	local expected="$2"
	local size

	size=$(stat -c %s $file)

	[[ "$size" = "$expected" ]] ||
		error "failed to verify size of '$file': '$size' != '$expected'"
}

# lamigo test cases
test_1() {
	init_hot_pools_env
	start_lamigo_cmd
	check_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_lamigo_cmd
	verify_lamigo_params
	dump_lamigo_stats
}
run_test 1 "lamigo: start with command line options"

test_2() {
	init_hot_pools_env
	start_lamigo_cfg
	check_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_lamigo_cfg
	verify_lamigo_params
	dump_lamigo_stats
}
run_test 2 "lamigo: start with configuration file"

test_3() {
	init_hot_pools_env
	start_lamigo_service
	check_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_lamigo_service
	verify_lamigo_params
	dump_lamigo_stats
}
run_test 3 "lamigo: start with system service"

test_4() {
	init_hot_pools_env

	local unknown_param="foo"
	local facet=${LAMIGO_MDT_FACET[0]}
	local log_file=$(lamigo_logfile $facet)

	LAMIGO_BG_SCAN=true \
	LAMIGO_THREAD_NUM=1 LAMIGO_PROG_INTV=300 \
	LAMIGO_CACHE="$((512 * 1048576)) #cache size"\
	LAMIGO_EXTRA="$unknown_param" \
	LAMIGO_MIRROR_CMD="lfs mirror extend -N -c -1" \
	LAMIGO_DEBUG=true \
	LAMIGO_DUMP=$TMP/lamigo.dump \
	start_one_lamigo_cfg

	check_one_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_one_lamigo_cfg

	do_facet $facet "cat $log_file" | grep -q "unknown tunable: '$unknown_param'" ||
		error "failed to recognize unknown parameter '$unknown_param'"

	LAMIGO_BG_SCAN=true \
	LAMIGO_THREAD_NUM=1 LAMIGO_PROG_INTV=300 \
	LAMIGO_CACHE=$((512 * 1048576)) \
	LAMIGO_DUMP=$TMP/lamigo.dump \
	verify_one_lamigo_params

	LAMIGO_DUMP=$TMP/lamigo.dump dump_one_lamigo_stats
}
run_test 4 "lamigo: start with all parameters"

test_5() {
	init_hot_pools_env

	LAMIGO_MDT= LAMIGO_MOUNT= LAMIGO_SRC= LAMIGO_TGT= LAMIGO_AGE= \
	LAMIGO_USR= LAMIGO_CLIENTS= LAMIGO_AGT_NODES= start_one_lamigo_cmd
	! check_one_lamigo_is_started || {
		stop_one_lamigo_cmd
		error "start lamigo with no parameters should fail"
	}

	LAMIGO_MDT= LAMIGO_SRC= LAMIGO_TGT= LAMIGO_AGE= \
	LAMIGO_USR= LAMIGO_CLIENTS= LAMIGO_AGT_NODES= start_one_lamigo_cmd
	! check_one_lamigo_is_started || {
		stop_one_lamigo_cmd
		error "start lamigo with only '-M' option should fail"
	}

	LAMIGO_SRC= LAMIGO_TGT= LAMIGO_AGE= \
	LAMIGO_USR= LAMIGO_CLIENTS= LAMIGO_AGT_NODES= start_one_lamigo_cmd
	! check_one_lamigo_is_started || {
		stop_one_lamigo_cmd
		error "start lamigo with only '-M' and '-m' options should fail"
	}

	LAMIGO_MOUNT=foo start_one_lamigo_cmd
	! check_one_lamigo_is_started || {
		stop_one_lamigo_cmd
		error "start lamigo with bad '-M' option should fail"
	}

	LAMIGO_MDT=foo start_one_lamigo_cmd
	! check_one_lamigo_is_started || {
		stop_one_lamigo_cmd
		error "start lamigo with bad '-m' option should fail"
	}

	# EX-1986 lamigo: let lamigo start w/o alive agents
	LAMIGO_CLIENTS= LAMIGO_AGT_NODES=foo start_one_lamigo_cmd
	check_one_lamigo_is_started ||
		error "start lamigo with bad '-g' option should not fail"
	stop_one_lamigo_cmd

	LAMIGO_AGE="-1" start_one_lamigo_cmd
	! check_one_lamigo_is_started || {
		stop_one_lamigo_cmd
		error "start lamigo with bad '-a' option should fail"
	}

	LAMIGO_PROG_INTV="-1" start_one_lamigo_cmd
	! check_one_lamigo_is_started || {
		stop_one_lamigo_cmd
		error "start lamigo with bad '--progress-interval' option should fail"
	}

	LAMIGO_CACHE="-1" start_one_lamigo_cmd
	! check_one_lamigo_is_started || {
		stop_one_lamigo_cmd
		error "start lamigo with bad '-c' option should fail"
	}

	LAMIGO_THREAD_NUM="-1" start_one_lamigo_cmd
	! check_one_lamigo_is_started || {
		stop_one_lamigo_cmd
		error "start lamigo with bad '-n' option should fail"
	}

	LAMIGO_TGT=$LAMIGO_SRC start_one_lamigo_cmd
	! check_one_lamigo_is_started || {
		stop_one_lamigo_cmd
		error "start lamigo with same OST pools should fail"
	}

	zconf_umount_clients $(comma_list $(all_mgt_mdts_nodes)) $MOUNT
	start_lamigo_cmd
	! check_lamigo_is_started || {
		stop_lamigo_cmd
		error "start lamigo with no client mounted on MDS should fail"
	}
	zconf_mount_clients $(comma_list $(all_mgt_mdts_nodes)) $MOUNT ||
		error "failed to mount Lustre clients on MDS nodes"
}
run_test 5 "lamigo: start with bad command line options"

test_6a() {
	local bad_user="foo"
	local real_user

	init_hot_pools_env

	LAMIGO_USR=$bad_user start_one_lamigo_cmd
	check_one_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_one_lamigo_cmd

	real_user=$(get_lamigo_chlg)
	echo "New Changelog user is '$real_user'"
	stack_trap "__changelog_deregister mds1 $real_user"
	stack_trap "rm -f ${LAMIGO_USERFILE[0]}"
	sleep 5
	dump_one_lamigo_stats
	verify_one_lamigo_param 0 chlg_user "$real_user"
}
run_test 6a "lamigo: start with bad changelog user"

test_6b() {
	local bad_user="foo"
	local real_user

	INIT_HOT_POOLS_CHANGELOG=false init_hot_pools_env

	LAMIGO_USR= start_one_lamigo_cmd
	check_one_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_one_lamigo_cmd

	real_user=$(get_lamigo_chlg)
	echo "New Changelog user is '$real_user'"
	stack_trap "__changelog_deregister mds1 $real_user"
	stack_trap "rm -f ${LAMIGO_USERFILE[0]}"
	sleep 5
	dump_one_lamigo_stats
	verify_one_lamigo_param 0 chlg_user "$real_user"

	[[ "$real_user" =~ cl[0-9]+-lamigo ]] ||
		error "non named changelog user '$real_user'"
}
run_test 6b "lamigo: start with no changelog user"

test_6c() {
	local real_user
	local scan_begin

	INIT_HOT_POOLS_CHANGELOG=false init_hot_pools_env

	LAMIGO_USR= start_one_lamigo_cmd
	check_one_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_one_lamigo_cmd

	real_user=$(get_lamigo_chlg)
	echo "New Changelog user is '$real_user'"
	stack_trap "__changelog_deregister mds1 $real_user"
	stack_trap "rm -f ${LAMIGO_USERFILE[0]}"

	sleep 5
	scan_begin=$(dump_one_lamigo_stats | awk '/scan_begin:/{print $2}')
	echo "scan_begin = '$scan_begin'"
	((scan_begin != 0)) ||
		error "lamigo did not rescan"
}
run_test 6c "lamigo should rescan after registering a new changelog user"

test_7() {
	init_hot_pools_env

	local src_pool="ddn_ssd"
	local tgt_pool="ddn_hdd"
	local facet=${LAMIGO_MDT_FACET[0]}
	local log_file=$(lamigo_logfile $facet)

	LAMIGO_CLIENTS= LAMIGO_AGT_NODES="$(facet_active_host ost1)" \
	LAMIGO_SRC= LAMIGO_TGT= start_one_lamigo_cmd
	check_one_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_one_lamigo_cmd

	sleep $LAMIGO_AGE
	do_facet $facet "cat $log_file" |
		grep --ignore-case -q "slow pool '$tgt_pool' is empty" ||
		error "failed to use default pool '$tgt_pool'"
}
run_test 7 "lamigo: start with no OST pools"

test_8() {
	init_hot_pools_env

	local td=$DIR/$tdir
	local tf=$td/$tfile
	local facet=${LAMIGO_MDT_FACET[0]}
	local log_file=$(lamigo_logfile $facet)

	mkdir $td || error "mkdir $td failed"
	$LFS setstripe -p $LAMIGO_SRC $td || error "$LFS setstripe $td failed"

	LAMIGO_DEBUG=true start_one_lamigo_cmd
	check_one_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_one_lamigo_cmd

	yes "10M file"| dd bs=1M count=10 iflag=fullblock of=$tf ||
		error "failed to create $tf"
	cancel_lru_locks osc

	wait_file_mirror $tf 2

	sleep $LAMIGO_AGE
	do_facet $facet "cat $log_file" |
		grep -q 'spawning new extend job for' ||
		error "no debug messages with -b option"
}
run_test 8 "lamigo: start with debug (-b) command line option"

test_9() {
	local td=$DIR/$tdir
	local tf=$td/$tfile
	local i

	init_hot_pools_env

	start_lamigo_service
	check_lamigo_is_started || error "failed to start lamigo"
	stack_trap "$LFS getstripe $td; stop_lamigo_service; rm -fr $td"

	# create parent directory
	mkdir $td || error "mkdir $td failed"
	$LFS setstripe -p $LAMIGO_SRC $td || error "$LFS setstripe $td failed"

	# create files in source pool
	for i in $(seq 3); do
		yes "10M file"| dd bs=1M count=10 iflag=fullblock of=$tf-$i ||
			error "failed to create $tf-$i"
	done
	cancel_lru_locks osc
	sleep $((LAMIGO_AGE * 2))

	# verify files replicated in target pool
	verify_one_lamigo_param 0 replicated 3
	for i in $(seq 3); do
		verify_file_mirror $tf-$i 2
		verify_file_size $tf-$i 10485760
	done
	dump_lamigo_stats
}
run_test 9 "lamigo: replicate from source to target pool"

test_10() {
	init_hot_pools_env

	local td=$DIR/$tdir
	local tf=$td/$tfile
	local facet=${LAMIGO_MDT_FACET[0]}
	local log_file=$(lamigo_logfile $facet)
	local cksum_orig
	local cksum_new
	local i

	LAMIGO_DEBUG=true start_one_lamigo_cmd
	check_one_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_one_lamigo_cmd

	# create parent directory
	mkdir $td || error "mkdir $td failed"
	stack_trap "rm -r $td"
	$LFS setstripe -p $LAMIGO_SRC $td || error "$LFS setstripe $td failed"

	# create a file in source pool
	yes "100M file"| dd bs=1M count=100 iflag=fullblock of=$tf ||
		error "failed to create $tf"
	cancel_lru_locks osc
	cksum_orig=$(md5sum $tf)

	for ((i = 0; i < $((LAMIGO_AGE * 2)); i++)); do
		do_facet $facet "cat $log_file" |
			grep -q 'new job extend' && break
		sleep 1
	done

	# read from the file
	cksum_new=$(md5sum $tf)
	dump_one_lamigo_stats

	[[ "$cksum_orig" = "$cksum_new" ]] ||
		error "checksum mismatch: '$cksum_orig' != '$cksum_new'"

	wait_file_mirror $tf 2

	# verify the file replicated in target pool
	verify_one_lamigo_param 0 replicated 1
	verify_file_mirror $tf 2
	verify_file_size $tf 104857600
}
run_test 10 "lamigo: read from a file that is being replicated"

test_11() {
	local td=$DIR/$tdir
	local tf=$td/$tfile
	local cksum_orig
	local cksum_new
	local cksum_mirror
	local ids
	local i

	init_hot_pools_env

	start_lamigo_service
	check_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_lamigo_service

	# create parent directory
	mkdir $td || error "mkdir $td failed"
	stack_trap "rm -r $td"
	$LFS setstripe -p $LAMIGO_SRC $td || error "$LFS setstripe $td failed"

	# create a file in source pool
	yes "10M old"| dd bs=1M count=10 iflag=fullblock of=$tf ||
		error "failed to create $tf"
	cancel_lru_locks osc
	cksum_orig=$(cat $tf | md5sum)
	sleep $((LAMIGO_AGE * 2))

	# checksum of the replicated file should be equal to the original file's
	cksum_new=$(cat $tf | md5sum)
	[[ "$cksum_new" = "$cksum_orig" ]] ||
		error "checksum mismatch: '$cksum_new' != '$cksum_orig'"

	$LFS getstripe $tf
	verify_mirror_count $tf 2
	ids=($($LFS getstripe $tf | awk '/lcme_mirror_id/{print $2}' | tr '\n' ' '))

	# checksums of the mirrors should be equal to the original file's
	for i in ${ids[@]}; do
		$LCTL set_param ldlm.namespaces.*.lru_size=clear > /dev/null
		cksum_mirror=$($LFS mirror read -N $i $tf | md5sum)
		[[ "$cksum_mirror" = "$cksum_orig" ]] ||
			error "mirror $i checksum mismatch: '$cksum_mirror' != '$cksum_orig'"
	done

	# write to the file
	yes "10M new"| dd bs=1M count=10 iflag=fullblock of=$tf ||
		error "failed to write to $tf"
	cancel_lru_locks osc
	$LFS getstripe $tf

	# verify the mirror status
	ids=($($LFS getstripe $tf | awk '/lcme_id/{print $2}' | tr '\n' ' '))
	verify_comp_attr lcme_flags $tf ${ids[0]} init
	verify_comp_attr lcme_flags $tf ${ids[1]} init,stale

	# wait for the stale mirror to be resynced
	sleep $((LAMIGO_AGE * 2))

	# verify the file replicated in target pool
	verify_one_lamigo_param 0 replicated 2
	verify_file_mirror $tf 2
	verify_file_size $tf 10485760
}
run_test 11 "lamigo: write to a replicated file"

test_12() {
	local td=$DIR/$tdir
	local tf=$td/$tfile
	local i

	init_hot_pools_env

	start_lamigo_cmd
	check_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_lamigo_cmd

	# create parent directory
	mkdir $td || error "mkdir $td failed"
	stack_trap "rm -r $td"
	$LFS setstripe -p $LAMIGO_SRC $td || error "$LFS setstripe $td failed"

	# create a file in source pool
	yes "1M old"| dd bs=1M count=1 iflag=fullblock of=$tf ||
		error "failed to create $tf"
	cancel_lru_locks osc

	for ((i = 0; i < $((LAMIGO_AGE * 2)); i++)); do
		# write to the file
		yes "1M new"| dd bs=1M count=1 iflag=fullblock of=$tf ||
			error "failed to write to $tf"
		sleep 2
		verify_mirror_count $tf 0
	done
	dump_lamigo_stats
}
run_test 12 "lamigo: skip replication of constantly modified file"

test_13() {
	local td=$DIR/$tdir
	local tf=$td/$tfile
	local removed_orig
	local replicated_orig

	[[ -n "$DIR" ]] && rm -rf $DIR/[Rdfs][0-9]* ||
		error "remove sub-test dirs failed"

	init_hot_pools_env

	LAMIGO_AGE=30 \
		start_one_lamigo_cmd
	check_one_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_one_lamigo_cmd

	# create parent directory
	mkdir $td || error "mkdir $td failed"
	stack_trap "rm -r $td"
	$LFS setstripe -p $LAMIGO_SRC $td || error "$LFS setstripe $td failed"

	# create a file in source pool
	yes "1M old"| dd bs=1M count=1 iflag=fullblock of=$tf ||
		error "failed to create $tf"

	$LFS path2fid $tf
	cancel_lru_locks osc
	dump_one_lamigo_stats

	removed_orig=$(dump_one_lamigo_stats | awk '/removed:/ { print $2 }')
	replicated_orig=$(dump_one_lamigo_stats | awk '/replicated:/ { print $2 }')

	# remove the file
	rm $tf
	echo "file $tf removed at: $(date +%s)"
	sleep $((LAMIGO_AGE + 10))

	verify_one_lamigo_param 0 removed $((removed_orig + 1))
	verify_one_lamigo_param 0 replicated $replicated_orig
}
run_test 13 "lamigo: skip just removed file"

test_14() {
	local td=$DIR/$tdir

	init_hot_pools_env

	start_lamigo_cmd
	check_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_lamigo_cmd

	# create a directory
	mkdir $td || error "mkdir $td failed"
	stack_trap "rm -r $td"
	# open-close dir
	ls $td
	cancel_lru_locks mdc
	$LFS path2fid $td
	sleep $((LAMIGO_AGE * 2))

	verify_one_lamigo_param 0 replicated 0
	verify_mirror_count $td 0
}
run_test 14 "lamigo: don't try to replicate dirs"

test_15() {
	local tf=$DIR/$tfile
	local ids
	local i

	init_hot_pools_env

	start_lamigo_service
	check_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_lamigo_service

	# create PFL files
	for i in $(seq 3); do
		$LFS setstripe -E 128M -c 1 -p $LAMIGO_SRC --comp-flags=prefer \
			-E eof -c -1 -p $LAMIGO_TGT $tf-$i ||
			error "failed to create $tf-$i"
	done
	stack_trap "rm $tf*"

	# fill in data in the first component of the PFL file
	yes "128M file"| dd bs=1M count=128 iflag=fullblock of=$tf-2 ||
		error "failed to write to $tf-2"

	# fill in data in both components of the PFL file
	yes "129M file"| dd bs=1M count=129 iflag=fullblock of=$tf-3 ||
		error "failed to write to $tf-3"

	# create a FLR file and fill in data
	$LFS mirror create -N -E 128M -c 1 -o 0 -p $LAMIGO_SRC \
		-E eof -c -1 -p $LAMIGO_TGT -N -S 8M -p $LAMIGO_SRC $tf-4 ||
			error "failed to create $tf-4"

	yes "128M file"| dd bs=1M count=128 iflag=fullblock of=$tf-4 ||
		error "failed to write to $tf-4"

	cancel_lru_locks
	sync; sleep 5; sync
	wait_file_resync $tf-4 || error "failed to resync $tf-4"

	# verify file size
	verify_file_size $tf-1 0
	verify_file_size $tf-2 134217728
	verify_file_size $tf-3 135266304
	verify_file_size $tf-4 134217728

	cancel_lru_locks osc
	sleep $((LAMIGO_AGE * 2))

	verify_one_lamigo_param 0 replicated 4

	# verify the PFL files replicated in target pool
	for i in $(seq 3); do
		verify_mirror_count $tf-$i 2
		ids=($($LFS getstripe $tf-$i | awk '/lcme_id/{print $2}' |
		     tr '\n' ' '))
		verify_comp_attr lcme_flags $tf-$i ${ids[0]} init,prefer
		verify_comp_attr lcme_flags $tf-$i ${ids[2]} init

		verify_comp_attr pool $tf-$i ${ids[0]} $LAMIGO_SRC
		verify_comp_attr pool $tf-$i ${ids[1]} $LAMIGO_TGT
		verify_comp_attr pool $tf-$i ${ids[2]} $LAMIGO_TGT
	done

	# verify the FLR file replicated in target pool
	verify_mirror_count $tf-4 3
	ids=($($LFS getstripe $tf-4 | awk '/lcme_id/{print $2}' | tr '\n' ' '))
	for i in 0 2 3; do
		verify_comp_attr lcme_flags $tf-4 ${ids[$i]} init
	done

	verify_comp_attr pool $tf-4 ${ids[0]} $LAMIGO_SRC
	verify_comp_attr pool $tf-4 ${ids[1]} $LAMIGO_TGT
	verify_comp_attr pool $tf-4 ${ids[2]} $LAMIGO_SRC
	verify_comp_attr pool $tf-4 ${ids[3]} $LAMIGO_TGT
}
run_test 15 "lamigo: replicate PFL and FLR files"

test_16() {
	local facet
	local pid_file
	local start_pid
	local status

	init_hot_pools_env
	facet=${LAMIGO_MDT_FACET[0]}
	pid_file=${LAMIGO_PIDFILE[0]}

	do_facet $facet lctl set_param "mdc.*.allow_intr=1" "osc.*.allow_intr=1"

	start_one_lamigo_cmd
	start_pid=$!
	echo "start_pid = '${start_pid}'" >&2

	check_one_lamigo_is_started || error "failed to start lamigo"

	stop $facet

	# XXX Double kill needed to interrupt close RPCs from do_exit().
	# XXX This doesn't work when -TERM is used in both pkills.
	do_facet $facet "pkill -TERM --pidfile=${pid_file} lamigo"
	sleep 10
	do_facet $facet "pkill -KILL --pidfile=${pid_file} lamigo"

	wait ${start_pid}
	status=$?
	echo "status = '${status}'" >&2

	start $facet
}
run_test 16 "lamigo can terminate with unmounted MDT"

# lpurge test cases
test_51() {
	init_hot_pools_env
	start_lpurge_cmd
	check_lpurge_is_started || error "failed to start lpurge"
	stack_trap stop_lpurge_cmd
	verify_lpurge_params
	dump_lpurge_stats
}
run_test 51 "lpurge: start with command line options"

test_52() {
	init_hot_pools_env
	start_lpurge_cfg
	check_lpurge_is_started || error "failed to start lpurge"
	stack_trap stop_lpurge_cfg
	verify_lpurge_params
	dump_lpurge_stats
}
run_test 52 "lpurge: start with configuration file"

test_53() {
	init_hot_pools_env
	start_lpurge_service
	check_lpurge_is_started || error "failed to start lpurge"
	stack_trap stop_lpurge_service
	verify_lpurge_params
	dump_lpurge_stats
}
run_test 53 "lpurge: start with system service"

test_54() {
	local unknown_param="foo"

	init_hot_pools_env

	LPURGE_FREEHI=80 LPURGE_FREELO=50 LPURGE_INTV=60 LPURGE_MAX_JOBS=4 \
	LPURGE_SCAN_THREADS=2 LPURGE_SCAN_RATE="20000 #objs/sec" \
	LPURGE_EXTRA="$unknown_param" LPURGE_SLOT_SIZE="$((2 * 1048576))" \
	LPURGE_DUMP=$TMP/lpurge.dump \
	start_one_lpurge_service
	check_one_lpurge_is_started || error "failed to start lpurge"
	stack_trap stop_one_lpurge_service

	LPURGE_FREEHI=80 LPURGE_FREELO=50 LPURGE_INTV=60 LPURGE_MAX_JOBS=4 \
	LPURGE_SCAN_THREADS=2 LPURGE_SCAN_RATE=20000 \
	LPURGE_SLOT_SIZE="$((2 * 1048576))" \
	LPURGE_DUMP=$TMP/lpurge.dump \
	verify_one_lpurge_params

	LPURGE_DUMP=$TMP/lpurge.dump dump_one_lpurge_stats
}
run_test 54 "lpurge: start with all parameters"

test_55() {
	init_hot_pools_env

	do_nodes $(comma_list $(all_server_nodes)) "lsof -t $MOUNT"

	LPURGE_DEV= LPURGE_MOUNT= LPURGE_MDS= LPURGE_POOL= LPURGE_INTV= \
	start_one_lpurge_cmd
	! check_one_lpurge_is_started || {
		stop_one_lpurge_cmd
		error "start lpurge with no parameters should fail"
	}
	do_nodes $(comma_list $(all_server_nodes)) "lsof -t $MOUNT"

	LPURGE_DEV= LPURGE_MDS= LPURGE_POOL= LPURGE_INTV= start_one_lpurge_cmd
	! check_one_lpurge_is_started || {
		stop_one_lpurge_cmd
		error "start lpurge with only '-M' option should fail"
	}
	do_nodes $(comma_list $(all_server_nodes)) "lsof -t $MOUNT"

	LPURGE_MOUNT= LPURGE_MDS= LPURGE_POOL= LPURGE_INTV= start_one_lpurge_cmd
	! check_one_lpurge_is_started || {
		stop_one_lpurge_cmd
		error "start lpurge with only '-D' option should fail"
	}
	do_nodes $(comma_list $(all_server_nodes)) "lsof -t $MOUNT"

	LPURGE_MOUNT=foo start_one_lpurge_cmd
	! check_one_lpurge_is_started || {
		stop_one_lpurge_cmd
		error "start lpurge with bad '-M' option should fail"
	}
	do_nodes $(comma_list $(all_server_nodes)) "lsof -t $MOUNT"

	LPURGE_DEV=foo start_one_lpurge_cmd
	! check_one_lpurge_is_started || {
		stop_one_lpurge_cmd
		error "start lpurge with bad '-D' option should fail"
	}
	do_nodes $(comma_list $(all_server_nodes)) "lsof -t $MOUNT"

	LPURGE_INTV="-1" start_one_lpurge_cmd
	! check_one_lpurge_is_started || {
		stop_one_lpurge_cmd
		error "start lpurge with bad '-i' option should fail"
	}
	do_nodes $(comma_list $(all_server_nodes)) "lsof -t $MOUNT"

	LPURGE_SCAN_RATE="-1" start_one_lpurge_cmd
	! check_one_lpurge_is_started || {
		stop_one_lpurge_cmd
		error "start lpurge with bad '-R' option should fail"
	}
	do_nodes $(comma_list $(all_server_nodes)) "lsof -t $MOUNT"

	LPURGE_SLOT_SIZE="-1" start_one_lpurge_cmd
	! check_one_lpurge_is_started || {
		stop_one_lpurge_cmd
		error "start lpurge with bad '-S' option should fail"
	}
	do_nodes $(comma_list $(all_server_nodes)) "lsof -t $MOUNT"

	LPURGE_MAX_JOBS="-1" start_one_lpurge_cmd
	! check_one_lpurge_is_started || {
		stop_one_lpurge_cmd
		error "start lpurge with bad '-j' option should fail"
	}
	do_nodes $(comma_list $(all_server_nodes)) "lsof -t $MOUNT"

	LPURGE_SCAN_THREADS="-1" start_one_lpurge_cmd
	! check_one_lpurge_is_started || {
		stop_one_lpurge_cmd
		error "start lpurge with bad '-t' option should fail"
	}
	do_nodes $(comma_list $(all_server_nodes)) "lsof -t $MOUNT"

	LPURGE_FREEHI="-1" start_one_lpurge_cmd
	! check_one_lpurge_is_started || {
		stop_one_lpurge_cmd
		error "start lpurge with bad '-h' option should fail"
	}
	do_nodes $(comma_list $(all_server_nodes)) "lsof -t $MOUNT"

	LPURGE_FREELO="-1" start_one_lpurge_cmd
	! check_one_lpurge_is_started || {
		stop_one_lpurge_cmd
		error "start lpurge with bad '-l' option should fail"
	}
	do_nodes $(comma_list $(all_server_nodes)) "lsof -t $MOUNT"

	zconf_umount_clients $(comma_list $(all_server_nodes)) $MOUNT
	start_lpurge_cmd
	! check_lpurge_is_started || {
		stop_lpurge_cmd
		error "start lpurge with no client mounted on OSS should fail"
	}
	zconf_mount_clients $(comma_list $(all_server_nodes)) $MOUNT ||
		error "failed to mount Lustre clients on OSS nodes"
}
run_test 55 "lpurge: start with bad command line options"

test_56() {
	local tf=$DIR/$tfile
	local free_MB
	local size_MB
	local freehi=99
	local freelo=96
	local cksum_orig
	local cksum_new
	local ids
	local cmd
	local i

	init_hot_pools_env

	# start lamigo
	start_lamigo_service
	check_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_lamigo_service

	# start lpurge
	LPURGE_FREELO=$freelo LPURGE_FREEHI=$freehi start_lpurge_service
	check_lpurge_is_started || error "failed to start lpurge"
	stack_trap stop_lpurge_service

	$LFS df
	free_MB=$(($(df -P $DIR | tail -n 1 | awk '{ print $4 }') / 1024))
	size_MB=$((free_MB * (100 - freelo + 1) / 100 / 2))

	# create a regular file in source pool
	cmd="$LFS setstripe -c -1 -p $LAMIGO_SRC $tf-1"
	echo $cmd
	$cmd || error "$LFS setstripe $tf-1 failed"
	stack_trap "rm $tf*"

	# create a PFL file
	cmd="$LFS setstripe -E 1M -c -1 -p $LAMIGO_SRC --comp-flags=prefer"
	cmd+=" -E eof -p $LAMIGO_TGT $tf-2"
	echo $cmd
	$cmd || error "$LFS setstripe $tf-2 failed"

	# create a FLR file
	cmd="$LFS mirror create -N -E 1M -c -1 -p $LAMIGO_SRC"
	cmd+=" -E eof -p $LAMIGO_TGT -N -p $LAMIGO_SRC $tf-3"
	echo $cmd
	$cmd || error "$LFS setstripe $tf-3 failed"

	# fill in data
	yes "1M file"| dd bs=1M count=1 iflag=fullblock of=$tf-3 || {
		$LFS getstripe $tf-3
		error "failed to write to $tf-3"
	}
	cancel_lru_locks
	sync; sleep 5; sync
	$LFS mirror resync $tf-3 || error "failed to resync $tf-3"

	for i in {1..2}; do
		yes "${size_MB}M file"|
			dd bs=1M count=$size_MB iflag=fullblock of=$tf-$i || {
				$LFS getstripe $tf-$i
				error "failed to write to $tf-$i"
			}
	done

	cancel_lru_locks osc
	echo "Before replicating and purging:"
	$LFS df

	# compute checksums if file size is equal to or smaller than 2GB
	echo "Compute checksums ..."
	for i in {1..3}; do
		! (( i < 3 && size_MB > 2048 )) || continue
		cksum_orig[${#cksum_orig[@]}]=$(md5sum $tf-$i)
	done

	sleep $((LAMIGO_AGE * 2 + LPURGE_INTV * 2))

	for i in {1..3}; do
		wait_file_resync $tf-$i
	done

	echo "After replicating and purging:"
	$LFS df

	# check checksums if file size is equal to or smaller than 2GB
	echo "Check checksums ..."
	for i in {1..3}; do
		! (( i < 3 && size_MB > 2048 )) || continue
		cksum_new[${#cksum_new[@]}]=$(md5sum $tf-$i)

		[[ "${cksum_orig[i-1]}" = "${cksum_new[i-1]}" ]] ||
			error "$tf-$i checksum mismatch: '${cksum_orig[i-1]}' != '${cksum_new[i-1]}'"
	done

	# verify files replicated in target pool and purged from source pool
	wait_file_mirror $tf-1 1 900
	verify_mirror_count $tf-1 1
	for i in $(seq 3); do
		ids=($($LFS getstripe $tf-$i | awk '/lcme_id/{print $2}' | tr '\n' ' '))
		verify_comp_attr pool $tf-$i ${ids[${#ids[@]}-1]} $LAMIGO_TGT
	done
}
run_test 56 "lamigo and lpurge: replicate and purge"

test_57() {
	local saved_max_kb
	local files=10
	local avail

	init_hot_pools_env

	stack_trap "rm -rf $DIR/$tdir $DIR/$tfile"

	$LFS mkdir -c 1 -i 0 $DIR/$tdir || error "can't mkdir"

	# allow large DoM component
	saved_max_kb=$(do_facet $SINGLEMDS $LCTL \
		get_param -n lod.*.dom_stripesize_max_kb | tail -1)

	echo "saved_max_kb=" $saved_max_kb

	do_nodes $(comma_list $(all_mdts_nodes)) \
		$LCTL set_param lod.*.dom_stripesize_max_kb=$((1024*100))
	stack_trap "do_nodes $(comma_list $(all_mdts_nodes)) \
		$LCTL set_param lod.*.dom_stripesize_max_kb=$saved_max_kb"

	avail=$($LFS df | grep MDT0000 | awk '{print $4}')
	echo "MDT avail= $avail"
	echo "OST avail"
	$LFS df | grep OST | awk '{print}'
	(( avail=avail/2 ))	# going to fill a half of MDT
	(( towrite = avail / files ))
	(( towrite < 5*1024 )) && skip "not enough space on $SINGLEMDS"
	echo "!!! gonna write $towrite"

	# create file with DoM component and replicate it
	$LFS setstripe -E $(((towrite/1024)*1024))k -L mdt -E -1 -c1 $DIR/$tdir ||
		error "can't setstripe"
	for ((i=0; i < $files; i++)); do
		# XXX: replace with fallocate
		echo "of=" $DIR/$tdir/f$i

		avail=$($LFS df | grep MDT0000 | awk '{print $4}')
		echo "i=$i avail MDT= $avail"
		echo "OST avail"
		$LFS df | grep OST | awk '{print}'

		dd if=/dev/zero of=$DIR/$tdir/f$i bs=1k \
			count=$(((towrite/1024+1)*1024)) || error "can't dd"
		$LFS mirror extend -N -p $LAMIGO_TGT $DIR/$tdir/f$i ||
			error "can't create mirror"
		$LFS getstripe $DIR/$tdir/f$i | grep pattern.*mdt ||
			error "no DoM component on $DIR/$tdir/f$i"
		sleep 1
	done
	cancel_lru_locks osc
	cancel_lru_locks mdc

	$LFS df
	local before=$($LFS getstripe $DIR/$tdir/f*|egrep "mirror_count:.*2" | wc -l)
	[[ $before == $files ]] || error "unexpected $before"

	LPURGE_FREELO=5 LPURGE_FREEHI=90 start_lpurge_service
	check_lpurge_is_started || error "failed to start lpurge"
	stack_trap stop_lpurge_service

	for ((i=0; i < 10; i++)); do
		local after=$($LFS getstripe $DIR/$tdir/f*|egrep "mirror_count:.*2" | wc -l)
		[[ $after != $before ]] && break
		echo checking...
		sleep 2
	done
	after=$($LFS getstripe $DIR/$tdir/f*|egrep "mirror_count:.*2" | wc -l)
	[[ $after != $before ]] ||
		error "no mirror was removed: $before == $after"
}
run_test 57 "lpurge to handle DoM component"

test_58() {
	local tf=$DIR/$tfile

	init_hot_pools_env

	# start lamigo
	LAMIGO_EXTRA_OPT="--include-dom" start_lamigo_cmd
	check_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_lamigo_cmd

	stack_trap "rm -f $tf"
	$LFS setstripe -E 1024K -L mdt -E EOF $tf
	dd if=/dev/zero of=$tf bs=1M count=1 || error "can't dd"
	cancel_lru_locks mdc

	sleep $((LAMIGO_AGE+10))
	for i in $(seq $MDSCOUNT); do
		local facet=mds$i
		local log_file=$(lamigo_logfile $facet)
		echo "==== logfile for $facet ===="
		do_facet $facet "cat $log_file"

	done
	verify_mirror_count $tf 2
}
run_test 58 "replicaste DoM files"

test_59() {
	local td=$DIR/$tdir
	local tf=$td/$tfile
	local free_MB
	local size_MB
	local freehi=99
	local freelo=96
	local ids
	local cmd
	local pid

	init_hot_pools_env

	# create a regular file in source pool
	mkdir $td || error "mkdir $td failed"
	stack_trap "rm -r $td"
	$LFS setstripe -N -c-1 --flags=prefer -p $LAMIGO_SRC $tf ||
		error "cannot create file"
	$LFS mirror extend -N -c-1 -p $LAMIGO_TGT $tf ||
		error "cannot create mirror"

	$LFS df -h
	free_MB=$(($(lfs_df -p $LAMIGO_SRC $DIR |
			awk '/summary/{print $4}') / 1024))
	size_MB=$((free_MB * (100 - freelo + 1) / 100))

	# fill in data
	yes "${size_MB}M file"|
		dd bs=1M count=$size_MB iflag=fullblock of=$tf ||
			error "failed to write to $tf"

	ids=($($LFS getstripe $tf | awk '/lcme_id/{print $2}' | tr '\n' ' '))
	verify_comp_attr lcme_flags "$tf" "${ids[0]}" init,^stale
	verify_comp_attr lcme_flags "$tf" "${ids[1]}" init,stale

	# open, apply read lease, pause, expect lease to exist, drop lease, close.
	cmd="$MULTIOP $tf oO_RDWR:eR_E+eUc"
	echo $cmd
	$cmd &
	pid=$!

	# start lpurge
	LPURGE_FREELO=$freelo LPURGE_FREEHI=$freehi start_lpurge_service
	check_lpurge_is_started || error "failed to start lpurge"
	stack_trap stop_lpurge_service

	echo "Before purging:"
	$LFS df -h
	$LFS getstripe $tf

	sleep $((LPURGE_INTV * 2))

	echo "After trying to purge:"
	$LFS df -h
	$LFS getstripe $tf

	# since the mirror in source pool is the last non-stale mirror,
	# it cannot be purged because 'lfs mirror split' cannot get WRITE lease.
	ids=($($LFS getstripe $tf | awk '/lcme_id/{print $2}' | tr '\n' ' '))
	verify_comp_attr lcme_flags $tf ${ids[0]} init,^stale
	verify_comp_attr lcme_flags $tf ${ids[1]} init,stale

	# release the lease lock, lpurge is running in background, the lease
	# lock could be broke by it, this also applies to mirror resync
	kill -USR1 $pid && wait $pid

	$LFS mirror resync $tf

	sleep $((LPURGE_INTV * 2))

	# verify the file purged from source pool
	echo "After purging:"
	wait_file_mirror $tf 1 900
	$LFS df -h
	$LFS getstripe $tf
	verify_mirror_count $tf 1
	ids=($($LFS getstripe $tf | awk '/lcme_id/{print $2}' | tr '\n' ' '))
	verify_comp_attr pool $tf ${ids[${#ids[@]}-1]} $LAMIGO_TGT
}
run_test 59 "lpurge: check layout before opening"

test_60() {
	local i
	local after
	local mdt
	local td=$DIR/$tdir

	init_hot_pools_env

	# start lamigo
	LAMIGO_DEBUG=true LAMIGO_EXTRA_OPT="--progress-interval=10" start_lamigo_cmd
	check_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_lamigo_cmd

	# put everything on slow, no replication will be made
	mkdir $td || error "mkdir $td failed"
	stack_trap "rm -r $td"
	$LFS setstripe -p $LAMIGO_TGT $td
	dbench -D $td 6 &
	PID=$!
	sleep 240
	kill $PID
	wait $PID

	# let lamigo process remaining records
	sleep 30

	local facet=${LAMIGO_MDT_FACET[0]}
	local log_file=$(lamigo_logfile $facet)
	do_facet $facet "grep -i gap $log_file"

	echo "verify lamigo stats"
	verify_one_lamigo_param 0 changelog_gaps 0
	verify_one_lamigo_param 0 replicated 0
}
run_test 60 "verify changelog processing under contiguous load"

test_70() {
	init_hot_pools_env
	local src=${LAMIGO_SRC}
	local tgt=${LAMIGO_TGT}
	local src_free=72 # "default" is 70
	local tgt_free=12 # "default" is 10

	LAMIGO_SRC= LAMIGO_TGT= LAMIGO_EXTRA_OPT="--src=${src} --src-dom --src-free=${src_free} --tgt=${tgt} --tgt-free=${tgt_free}" \
		start_one_lamigo_cmd
	check_one_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_one_lamigo_cmd

	verify_one_lamigo_param 0 fast_pool "$src"
	verify_one_lamigo_param 0 fast_pool_max_used $((100 - src_free))
	verify_one_lamigo_param 0 slow_pool "$tgt"
	verify_one_lamigo_param 0 slow_pool_max_used $((100 - tgt_free))
	verify_one_lamigo_param 0 include_dom 1
}
run_test 70 "lamigo: old options still work"

test_71() {
	init_hot_pools_env
	local fast_pool_max_used=28 # default is 30
	local slow_pool_max_used=88 # default is 90

	LAMIGO_EXTRA_OPT="--fast-pool-max-used=${fast_pool_max_used} --slow-pool-max-used=${slow_pool_max_used} --include-dom" \
		start_one_lamigo_cmd
	check_one_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_one_lamigo_cmd

	verify_one_lamigo_param 0 fast_pool_max_used ${fast_pool_max_used}
	verify_one_lamigo_param 0 slow_pool_max_used ${slow_pool_max_used}
	verify_one_lamigo_param 0 include_dom 1
}
run_test 71 "lamigo: new options work"

create_oss_param_list() {
	local ostnodes=$*
	local param=""

	for oss in $ostnodes; do
		param+=" --oss=$oss"
	done

	echo $param
}

check_entry() {
	local mdt_indx=$1
	local fid=$2
	local size=$3
	local j
	local wait_alr_duration=15	# seconds to wait the log message appears

	local facet=${LAMIGO_MDT_FACET[$mdt_indx]}
	local log_file=$(lamigo_logfile $facet)
	# 1      2    3      4        5   6    7    8   9   10   11  12
	# <ts> <mtd>  DEBUG: ALRUPG:  H: 'oss' FID  RW: w   O:   1   IO:  8192  P:   Pool f/s
	local awk_string="awk -v fid=$fid \
		'\\\$3 == \\\"DEBUG:\\\" && \\\$4 == \\\"ALRUPD:\\\" && \\\$7 == fid { print; }'\
		${log_file}"

	for ((j = 0; j < $wait_alr_duration; j++)); do
		local e=$(do_facet $facet $awk_string)

		# echo "+++++++++++Log File starts attempt:$j++++"
		# do_facet $facet "cat $log_file"
		# echo "-----------Log File finish---------------"

		[ -z "$e" ] || break

		sleep 1
	done

	[[ -n $e ]] || error "alr for fid ${fid} not found"

	# echo "Found ALR after $j attempts"

	local entry=($e)

	[[ "${entry[8]}" == "w" ]] ||
		error "alr: '${entry[*]}' has invalid operation '${entry[8]}', expected 'w'"

	((${entry[12]} == size)) ||
		error "alr: '${entry[*]}' has invalid io size '${entry[12]}', expected ${size}"
}

test_72() {
	local file=${DIR}/${tfile}
	local min_age=3600	# to prevent replication
	local size=8192
	local i

	init_hot_pools_env

	do_nodes $(comma_list $(osts_nodes)) \
		"$LCTL set_param obdfilter.${FSNAME}-OST*.access_log_size=4096 >&/dev/null"

	LAMIGO_AGE="${min_age}" \
		LAMIGO_EXTRA_OPT="$(create_oss_param_list $(osts_nodes))" \
		start_lamigo_cmd
	check_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_lamigo_cmd

	rm -f $file		# if previously test failed to clean up leftover
	echo OSTCOUNT=$OSTCOUNT
	for ((i = 0; i < $OSTCOUNT; i++)); do
		$LFS setstripe -c 1 -i $i $file || error "$LFS setstripe $file failed"

		$MULTIOP $file oO_CREAT:O_DIRECT:O_WRONLY:w"${size}"c ||
			error "cannot create '${file}'"

		local fid=$($LFS path2fid $file)
		local mdt_indx=$($LFS getstripe --mdt-index $file)

		echo "File: $file OST=$i Fid:$fid Mdt:$mdt_indx"

		check_entry $mdt_indx $fid $size

		rm -f $file
	done

	verify_one_lamigo_param 0 min_age ${min_age}
	dump_lamigo_stats
}
run_test 72 "lamigo: --oss option and ALR delivery to lamigo"

test_73() {
	local tf=$DIR/$tfile
	init_hot_pools_env

	start_lamigo_cmd
	check_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_lamigo_cmd
	stack_trap "rm -f $tf"

	$LFS setstripe -E 4M -c 2 -S 1M -p $LAMIGO_SRC \
		-E eof -c 4 -S 4M -p $LAMIGO_SRC $tf || error "setstripe failed"
	dd if=/dev/zero of=$tf bs=1M count=6 || error "dd failed"
	cancel_lru_locks osc
	sleep $((LAMIGO_AGE * 2))
	verify_file_mirror $tf 2
	local stripesize=$($LFS getstripe --mirror-id=2 -S $tf)
	(( stripesize == 4*1024*1024 )) || {
		$LFS getstripe $tf
		error "expected 4M stripe size on a new mirror"
	}
}
run_test 73 "check strip size & count after replication"

get_lamigo_keepalive() {
	local facet=${LAMIGO_MDT_FACET[0]}
	local log_file=$(lamigo_logfile $facet)
	# 1679963639.802665 testfs-MDT0000: DEBUG: keepalive option 1
	local awk_string="awk '/DEBUG: keepalive option/ { print \\\$6 }' ${log_file}"

	local keepalive_opt=$(do_facet $facet $awk_string)

	echo $keepalive_opt
}

verify_no_keepalive() {
	local keepalive_opt=$1

	(( keepalive_opt != 0 )) ||
		echo "No OFD keepalive message option detected"

	(( keepalive_opt != 1 )) ||
		error "Not expected OFD keepalive message option"
	return 0
}

verify_keepalive() {
	local keepalive_opt=$1
	local lamigo_facet=${LAMIGO_MDT_FACET[0]}
	local lamigo_log_file=$(lamigo_logfile $lamigo_facet)
	local count
	local grep_string

	(( keepalive_opt != 0 )) ||
		error "No OFD keepalive message option detected"

	(( keepalive_opt != 1 )) ||
		echo "OFD keepalive message option detected"

	# 1680134703.390641 testfs-MDT0000: DEBUG: keepalive msg from host:'ost-centOS8'

	grep_string="grep -c 'DEBUG: keepalive msg from host' $lamigo_log_file"
	count=$(do_facet $lamigo_facet $grep_string)

	(( count >= 2 && count <= 4 )) ||
		error "keepalive msg received $count. Expected 2..4"
}

test_74() {
	local oss
	local keepalive_opt

	# Firstly determine whether ofd_access_log_reader has keepalve message option
	local ofd_keepalive=$(do_facet ost1 ofd_access_log_reader --help |
				grep keepalive)
	init_hot_pools_env

	for oss in $(osts_nodes); do
		break
	done

	do_nodes $(comma_list $(osts_nodes)) \
		"$LCTL set_param obdfilter.${FSNAME}-OST*.access_log_size=4096 >&/dev/null"

	# Secondly determine whether lamigo detects keepalve message option

	LAMIGO_EXTRA_OPT="--oss=$oss --ofd-interval=3" start_lamigo_cmd
	check_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_lamigo_cmd

	sleep 30

	keepalive_opt=$(get_lamigo_keepalive)

	[[ -n $keepalive_opt ]] ||
		error "could not determine lamigo keepalive option: not found"

	(( $keepalive_opt < 0 )) &&
		error "could not determine lamigo keepalive option: ssh error"

	if [[ -z $ofd_keepalive ]]; then
		verify_no_keepalive $keepalive_opt
	else
		verify_keepalive $keepalive_opt
	fi
}
run_test 74 "ofd keepalive message"

test_75a() {
	local client=$HOSTNAME
	# The test is not valid if stats-interval is not supported
	# The test is going to use only client machine
	lfs mirror extend  2>&1 | grep -q stats-interval ||
		skip "Client $client requires 'lfs mirror extend --stats-interval' support"

	local tf=$DIR/$tfile

	init_hot_pools_env
	LAMIGO_AGT_NODES="" \
	LAMIGO_CLIENTS=$client \
	LAMIGO_MIRROR_CMD="lfs mirror extend -N -W1M" \
		start_lamigo_cfg
	check_lamigo_is_started || {
		local facet=${LAMIGO_MDT_FACET[0]}
		local log_file=$(lamigo_logfile $facet)
		echo "!!!! LAMIGO LOG !!!!"
		do_facet $facet "cat $log_file"
		echo "!!!! LAMIGO LOG END !!!!"
		error "failed to start lamigo"
	}
	stack_trap stop_lamigo_cmd

	$LFS setstripe -p $LAMIGO_SRC $tf ||
		error "$LFS setstripe $tf failed"
	stack_trap "rm $tf"
	dd if=/dev/zero of=$tf bs=1M count=32 ||
		error "can't dd"
	cancel_lru_locks osc

	local FID=$($LFS path2fid $tf)
	[[ -z $FID ]] && error "can't get fid for $tf"
	FID=${FID##[}
	FID=${FID%%]}

	local js
	local pct
	for ((i=0; i < (($LAMIGO_AGE*2)); i++)); do
		js=$(dump_lamigo_stats | grep -E "job[0-9]*:.*fid:.*$FID")
		[[ $js == *progress:* ]] && {
			pct=${js##*progress: }
			pct=${pct%%%,*}
			(( pct > 0 && pct < 100 )) &&
				echo "got $pct%" && break
		}
		sleep 1
	done
	(( pct > 0 && pct < 100 )) || {
		local facet=${LAMIGO_MDT_FACET[0]}
		local log_file=$(lamigo_logfile $facet)
		echo "!!!! ======= LAMIGO LOG for $facet ======="
		do_facet $facet "cat $log_file"
		echo "!!!! ======= LAMIGO LOG for $facet ======="
		facet=${LAMIGO_MDT_FACET[1]}
		log_file=$(lamigo_logfile $facet)
		echo "!!!! ======= LAMIGO LOG for $facet ======="
		do_facet $facet "cat $log_file"
		echo "!!!! ======= LAMIGO LOG for $facet ======="
		error "can't get job completion's percent"
	}
}
run_test 75a "lamigo to parse mirroring progress"

test_75b() {
	local client=$HOSTNAME
	# The test is not valid if stats-interval is not supported.
	# The test is going to use only client machine.
	lfs mirror extend  2>&1 | grep -q stats-interval ||
		skip "Client $client requires 'lfs mirror extend --stats-interval' support"

	local tf=$DIR/$tfile

	init_hot_pools_env
	LAMIGO_AGT_NODES="" \
	LAMIGO_CLIENTS=$client \
	LAMIGO_RESYNC_CMD="lfs mirror resync -W1M" start_lamigo_cfg
	check_lamigo_is_started || {
		local facet=${LAMIGO_MDT_FACET[0]}
		local log_file=$(lamigo_logfile $facet)
		echo "!!!! LAMIGO LOG !!!!"
		do_facet $facet "cat $log_file"
		echo "!!!! LAMIGO LOG END !!!!"
		error "failed to start lamigo"
	}
	stack_trap stop_lamigo_cfg

	$LFS setstripe -p $LAMIGO_SRC $tf ||
		error "$LFS setstripe $tf failed"
	stack_trap "rm $tf"
	dd if=/dev/zero of=$tf bs=1M count=32 ||
		error "can't dd"
	$LFS mirror extend -N -p $LAMIGO_TGT $tf ||
		error "can't make replica"
	verify_mirror_count $tf 2

	# invalidate replica
	echo 123 >>$tf
	$LFS getstripe -v $tf | grep flag.*stale || {
		$LFS getstripe -v $tf
		error "not invalidated?"
	}

	local FID=$($LFS path2fid $tf)
	[[ -z $FID ]] && error "can't get fid for $tf"
	FID=${FID##[}
	FID=${FID%%]}

	local js
	local pct
	for ((i=0; i < (($LAMIGO_AGE*2)); i++)); do
		js=$(dump_lamigo_stats | grep -E "job[0-9]*:.*fid:.*$FID")
		[[ $js == *progress:* ]] && {
			pct=${js##*progress: }
			pct=${pct%%%,*}
			(( pct > 0 && pct < 100 )) &&
				echo "got $pct%" && break
		}
		sleep 2
	done
	(( pct > 0 && pct < 100 )) || {
		$LFS getstripe -v $tf
		local facet=${LAMIGO_MDT_FACET[0]}
		local log_file=$(lamigo_logfile $facet)
		echo "!!!! ======= LAMIGO LOG for $facet ======="
		do_facet $facet "cat $log_file"
		echo "!!!! ======= LAMIGO LOG for $facet ======="
		facet=${LAMIGO_MDT_FACET[1]}
		log_file=$(lamigo_logfile $facet)
		echo "!!!! ======= LAMIGO LOG for $facet ======="
		do_facet $facet "cat $log_file"
		echo "!!!! ======= LAMIGO LOG for $facet ======="
		error "can't get job completion's percent"
	}
}
run_test 75b "lamigo to parse mirror resync progress"

test_75c() {
	local client=$HOSTNAME
	# The test not valid if stats-interval is not supported
	# The test is going to use only client machine.
	lfs mirror extend  2>&1 | grep -q stats-interval ||
		skip "Client $client requires 'lfs mirror extend --stats-interval' support"

	local tf=$DIR/$tfile
	local lamigo_age=5

	init_hot_pools_env

	# redirect stats to /dev/null
	# Use only client machine as a replicating agent
	LAMIGO_STATS_MISSING=1 \
	LAMIGO_CLIENTS=$client \
	LAMIGO_AGT_NODES="" \
	LAMIGO_CLIENTS=$client \
	LAMIGO_AGE=$lamigo_age \
	LAMIGO_MIRROR_CMD="lfs mirror extend -N -W1M >/dev/null" \
		start_lamigo_service
	check_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_lamigo_service

	$LFS setstripe -p $LAMIGO_SRC $tf ||
		error "$LFS setstripe $tf failed"
	stack_trap "rm $tf"
	dd if=/dev/zero of=$tf bs=1M count=32 ||
		error "can't dd"
	cancel_lru_locks osc

	local FID=$($LFS path2fid $tf)
	[[ -z $FID ]] && error "can't get fid for $tf"

	local nr
	nr=$(dump_one_lamigo_stats | awk '/job-timedout:/{print $2}')
	(( $nr == 0 )) || error "unexptected job-timedout: $nr"

	for ((i=0; i < (($lamigo_age*6)); i++)); do
		nr=$(dump_one_lamigo_stats | awk '/job-timedout:/{print $2}')
		dump_one_lamigo_stats | grep job-timedout
		(( $nr > 0 )) && break
		sleep 2
	done
	(( $nr > 0 )) || error "no timedout jobs"
}
run_test 75c "lamigo to timeout if no progress reported from mirror extend"

test_76() {
	local td=$DIR/$tdir
	local tf=$td/$tfile
	local ss=$((5*1024*1024))
	local fnr=5

	init_hot_pools_env

	start_lamigo_service
	check_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_lamigo_service

	mkdir $td || echo "can't create $td"
	stack_trap "rm -r $td"
	$LFS setstripe -p $LAMIGO_SRC -S $ss -o 0,1 $td || error "$LFS setstripe $td failed"
	$LFS getstripe $td

	for ((i=0; i<$fnr; i++)); do
		dd if=/dev/zero of=$tf-$i bs=$ss seek=1 count=1 ||
			error $"can't create $tf-$i"
		du -hs $tf-$i
	done
	cancel_lru_locks osc
	$LFS df -h
	$LFS getstripe $tf-* | grep lcm_mirror_count
	sleep $((LAMIGO_AGE * 2))
	verify_one_lamigo_param 0 replicated $fnr

	echo "before starting lpurge"
	$LFS df | grep OST0001
	LPURGE_FREELO=99 LPURGE_FREEHI=100 start_lpurge_service
	check_lpurge_is_started || error "failed to start lpurge"
	stack_trap stop_lpurge_service

	local mcnt
	for ((i=0; i < 20; i++)); do
		mcnt=$($LFS getstripe $tf-* | grep lcm_mirror_count |
			awk '{print $2}'|sort -u )
		[[ $mcnt == "1" ]] && break
		sleep 2
	done
	echo "with lpurge in action"
	$LFS df | grep OST0001
	[[ $mcnt == "1" ]] || {
		$LFS getstripe -v $tf-*
		$LFS df
		error "2nd stripes weren't deleted"
	}
}
run_test 76 "lpurge to use 2nd-stripe objects"

test_77() {
	local file=${DIR}/${tfile}
	local min_age=10
	local tpool

	init_hot_pools_env

	LAMIGO_EXTRA_OPT="--heatfn=none" \
	LAMIGO_AGE="${min_age}" \
		start_lamigo_cmd
	check_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_lamigo_cmd

	verify_one_lamigo_param 0 resync_all_stales 1

	$LFS setstripe -N -E eof --pool $LAMIGO_TGT \
		       -N -E eof --pool $LAMIGO_SRC $file-1 || \
		       error "$LFS setstripe $file-1 failed"
	stack_trap "rm $file*"

	dd if=/dev/zero of=$file-1 bs=64KB count=1 oflag=direct ||
		error "cannot create '$file-1'"

	wait_file_resync $file-1 $((min_age * 2)) || error "failed to resync $file-1"
	verify_one_lamigo_param 0 resync-stale 1

	$LFS setstripe -N3 $file-2 || error "setstripe $file-2 failed"
	dd if=/dev/zero of=$file-2 bs=64KB count=1 oflag=direct ||
		error "cannot create '$file-2'"

	wait_file_resync $file-2 $((min_age * 2)) || error "failed to resync $file-2"
	verify_one_lamigo_param 0 resync-stale 2

	tpool=${TESTSUITE}_${testnum}
	pool_add $tpool || error "failed to create OST pool '$tpool'"
	pool_add_targets $tpool 0 0 ||
		error "failed to add targets to OST pool '$tpool'"

	$LFS setstripe -N -E eof --pool $LAMIGO_TGT \
		       -N -E eof --pool $LAMIGO_SRC \
		       -N -E eof --pool $tpool $file-3 || \
		       error "setstripe for $file-3 failed"

	$LFS setstripe --comp-set --comp-flags=stale --pool=$tpool $file-3 ||
		error "setstripe stale for $file-3 failed"

	wait_file_resync $file-3 $((min_age * 2)) || error "failed to resync $file-3"
	verify_one_lamigo_param 0 resync-stale 3

	$LFS setstripe -N -E eof --pool $LAMIGO_TGT \
		       -N -E eof --pool $tpool $file-4 || \
		       error "setstripe for $file-4 failed"

	$LFS setstripe --comp-set --comp-flags=prefer --pool=$LAMIGO_TGT $file-4 ||
		error "setstripe prefer for $file-4 failed"

	dd if=/dev/zero of=$file-4 bs=64KB count=1 oflag=direct ||
		error "cannot create '$file-4'"

	wait_file_resync $file-4 $((min_age * 2)) || error "failed to resync $file-4"
	verify_one_lamigo_param 0 resync-stale 4
}
run_test 77 "lamigo: verify --resync-all-stales option"

test_80() {
        $LFS mirror extend  2>&1 | grep -q compress ||
                skip "Client $client requires 'lfs mirror extend --compress' support"

	local client=$HOSTNAME
	local min_age=5
	local compression="lz4:1"
	local file=${DIR}/${tfile}
	declare -a compr_arr

	init_hot_pools_env

	stack_trap "rm -fr $file"
	compression_enabled || skip "compression is disabled ($(uname -a))"

	LAMIGO_AGT_NODES="" \
	LAMIGO_CLIENTS=$client \
	LAMIGO_COMPRESSION="$compression" \
	LAMIGO_AGE="${min_age}" \
		start_lamigo_cmd
	check_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_lamigo_cmd

	verify_one_lamigo_param 0 slow_pool_compression "$compression"

	$LFS setstripe -p $LAMIGO_SRC $file || error "$LFS setstripe $file failed"
	dd if=/dev/zero of=$file bs=32KB count=1 oflag=direct ||
		error "cannot create '$file'"
	wait_file_mirror $file 2 $((min_age * 2))

	compr_arr=(${compression//:/ })

	verify_file_compress $file ${compr_arr[0]} ${compr_arr[1]}
}
run_test 80 "test slow pool compression option"

test_81() {
	local min_age=10
	local heat_periods=4
	local heat_duration_period=3
	local heat_wait=$(($heat_duration_period * $heat_periods))
	local tf=$DIR/$tfile
	local ids
	local pool
	local flags
	local extra_opt="$(create_oss_param_list $(osts_nodes)) "
	extra_opt+="--periods=$heat_periods --period-time=$heat_duration_period"

	init_hot_pools_env

	do_nodes $(comma_list $(osts_nodes)) \
		"$LCTL set_param obdfilter.${FSNAME}-OST*.access_log_size=4096 >&/dev/null"

	LAMIGO_EXTRA_OPT=$extra_opt \
	LAMIGO_AGE=$min_age \
	start_lamigo_cmd
	check_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_lamigo_cmd

	$LFS setstripe -p $LAMIGO_SRC --comp-flags=nocompr -E 1M -c 1 -E eof -c -1 $tf ||
		error "failed to create $tf"

	stack_trap "$LFS getstripe $tf; rm -f $tf"

	$MULTIOP $tf oO_CREATE:O_DIRECT:O_WRONLY:w1048576Yc ||
		error "can't multiop $tf"

	sleep $(($min_age * 2))

	verify_mirror_count $tf 2

	ids=($($LFS getstripe $tf | awk '/lcme_id/{print $2}' | tr '\n' ' '))
	verify_comp_attr lcme_flags	$tf ${ids[0]} init,prefer,nocompr

	verify_comp_attr mirror-id	$tf ${ids[0]} 1
	verify_comp_attr pool 		$tf ${ids[0]} $LAMIGO_SRC
	verify_comp_attr pool 		$tf ${ids[1]} $LAMIGO_SRC
	verify_comp_attr lcme_flags	$tf ${ids[2]} init,nocompr,^prefer
	verify_comp_attr mirror-id	$tf ${ids[2]} 2
	verify_comp_attr pool 		$tf ${ids[2]} $LAMIGO_TGT

	$LFS mirror split --mirror-id=1 -d $tf ||
		error "failed to split $tf"

	verify_mirror_count $tf 1

	# Flush heat history
	sleep $(($heat_wait * 2))

	# mirror_id 2 in slow pool is left untouched.
	# Heat it and initiate lamigo replication into fast pool

	$MULTIOP $tf o:O_DIRECT:r1048576c ||
		error "can't multiop $tf"

	sleep $heat_wait

	verify_mirror_count $tf 2
	# New created mirror is expected in fast pool
	# and has flags init,prefer,nocompr

	pool=$(lfs getstripe --mirror-id=3 $tf | awk '/lmm_pool:/ { print $2}')
	[[ $pool == $LAMIGO_SRC ]] ||
		error "mirror 3 pool of $tf is '$pool', expected $LAMIGO_SRC"

	flags=$(lfs getstripe --mirror-id=3 $tf | awk '/lcme_flags:/ { print $2}')
	[[ $flags == "init,prefer,nocompr" ]] ||
		error "mirror 3 flags of $tf are '$flags'"

}
run_test 81 "lamigo sets prefer, nocompr flags when mirrors"

create_scan_files() {
	local tf=$tf

	# pools may have files we do not want to rescan
	rm -fr $DIR/*

	$LFS setstripe -p $LAMIGO_SRC $tf-0 ||
		error "failed to create $tf-0"
	stack_trap "rm -f $tf*"
	$MULTIOP $tf-0 oO_CREATE:O_DIRECT:O_WRONLY:w1048576Yc ||
		error "can't multiop $tf-0"

	$LFS setstripe -p $LAMIGO_SRC -E 1M -c 1 -E eof -c -1 $tf-1 ||
		error "failed to create $tf-1"
	$MULTIOP $tf-1 oO_CREATE:O_DIRECT:O_WRONLY:w1048576Yc ||
		error "can't multiop $tf-1"

	$LFS setstripe -p $LAMIGO_SRC --comp-flags=nocompr -E 1M -c 1 -E eof -c -1 $tf-2 ||
		error "failed to create $tf-2"
	$MULTIOP $tf-2 oO_CREATE:O_DIRECT:O_WRONLY:w1048576Yc ||
		error "can't multiop $tf-2"

	$LFS setstripe -p $LAMIGO_SRC --comp-flags=prefer -E 1M -c 1 -E eof -c -1 $tf-3 ||
		error "failed to create $tf-3"
	$MULTIOP $tf-3 oO_CREATE:O_DIRECT:O_WRONLY:w1048576Yc ||
		error "can't multiop $tf-3"

	$LFS setstripe -p $LAMIGO_SRC --comp-flags=nocompr,prefer -E 1M -c 1 -E eof -c -1 $tf-4 ||
		error "failed to create $tf-4"
	$MULTIOP $tf-4 oO_CREATE:O_DIRECT:O_WRONLY:w1048576Yc ||
		error "can't multiop $tf-4"
}

verify_scan_mirrors() {
	local tf=$1
	local ids

	ids=($($LFS getstripe $tf-0 | awk '/lcme_id/{print $2}' | tr '\n' ' '))
	verify_comp_attr lcme_flags	$tf-0 ${ids[0]} init,prefer
	verify_comp_attr lcme_flags	$tf-0 ${ids[1]} init,^prefer,^nocompr
	verify_comp_attr pool 		$tf-0 ${ids[1]} $LAMIGO_TGT

	ids=($($LFS getstripe $tf-1 | awk '/lcme_id/{print $2}' | tr '\n' ' '))
	verify_comp_attr lcme_flags	$tf-1 ${ids[0]} init,prefer
	verify_comp_attr lcme_flags	$tf-1 ${ids[2]} init,^prefer,^nocompr
	verify_comp_attr pool 		$tf-1 ${ids[2]} $LAMIGO_TGT

	ids=($($LFS getstripe $tf-2 | awk '/lcme_id/{print $2}' | tr '\n' ' '))
	verify_comp_attr lcme_flags	$tf-2 ${ids[0]} init,prefer,nocompr
	verify_comp_attr lcme_flags	$tf-2 ${ids[2]} init,nocompr,^prefer
	verify_comp_attr pool 		$tf-2 ${ids[2]} $LAMIGO_TGT

	ids=($($LFS getstripe $tf-3 | awk '/lcme_id/{print $2}' | tr '\n' ' '))
	verify_comp_attr lcme_flags	$tf-3 ${ids[0]} init,prefer
	verify_comp_attr lcme_flags	$tf-3 ${ids[2]} init,^prefer,^nocompr
	verify_comp_attr pool 		$tf-3 ${ids[2]} $LAMIGO_TGT

	ids=($($LFS getstripe $tf-4 | awk '/lcme_id/{print $2}' | tr '\n' ' '))
	verify_comp_attr lcme_flags	$tf-4 ${ids[0]} init,prefer,nocompr
	verify_comp_attr lcme_flags	$tf-4 ${ids[2]} init,nocompr,^prefer
	verify_comp_attr pool 		$tf-4 ${ids[2]} $LAMIGO_TGT
}

wait_scan_mirrors() {
	local tf=$1

	echo "Wait scan mirrors"
	# Wait rescan and mirror finish
	wait_file_mirror $tf-0 2 15
	wait_file_mirror $tf-1 2 15
	wait_file_mirror $tf-2 2 15
	wait_file_mirror $tf-3 2 15
	wait_file_mirror $tf-4 2 15
}

delete_scan_mirrors() {
	local tf=$1

	$LFS mirror split --pool $LAMIGO_TGT -d $tf-0 ||
		error "error deleting $tf-0 mirror in $LAMIGO_TGT"
	$LFS mirror split --pool $LAMIGO_TGT -d $tf-1 ||
		error "error deleting $tf-1 mirror in $LAMIGO_TGT"
	$LFS mirror split --pool $LAMIGO_TGT -d $tf-2 ||
		error "error deleting $tf-2 mirror in $LAMIGO_TGT"
	$LFS mirror split --pool $LAMIGO_TGT -d $tf-3 ||
		error "error deleting $tf-3 mirror in $LAMIGO_TGT"
	$LFS mirror split --pool $LAMIGO_TGT -d $tf-4 ||
		error "error deleting $tf-4 mirror in $LAMIGO_TGT"
}

test_82a() {
	local tf=$DIR/$tfile

	init_hot_pools_env

	create_scan_files $tf

	changelog_clear 0

	LAMIGO_RESCAN=true \
	LAMIGO_AGE=3000 \
		start_lamigo_cmd
	check_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_lamigo_cmd

	wait_scan_mirrors $tf
	# wait set flag commands
	sleep 10

	echo "Verify rescan mirrors"
	verify_scan_mirrors $tf
}
run_test 82a "lamigo rescans, mirrors and sets prefer,nocompr flags"

test_82b() {
	local tf=$DIR/$tfile
	local interval=50

	init_hot_pools_env

	create_scan_files $tf

	changelog_clear 0

	LAMIGO_BG_SCAN_INTERVAL=$interval \
	LAMIGO_BG_SCAN=true \
	LAMIGO_AGE=3000 \
		start_lamigo_cmd
	check_lamigo_is_started || error "failed to start lamigo"
	stack_trap stop_lamigo_cmd

	sleep $(($interval * 2))

	echo "Verify files mirrored after first scan"
	verify_scan_mirrors $tf

	echo "Delete mirrors after scan"
	delete_scan_mirrors $tf

	sleep $(($interval * 2))

	echo "Verify files mirrored after second scan"
	verify_scan_mirrors $tf
}
run_test 82b "lamigo background scan finds not mirrored files and mirrors them"


complete_test $SECONDS
check_and_cleanup_lustre
exit_status
