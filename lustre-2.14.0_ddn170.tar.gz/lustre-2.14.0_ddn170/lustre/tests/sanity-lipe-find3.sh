#!/bin/bash

ONLY=${ONLY:-"$*"}

LUSTRE=${LUSTRE:-$(dirname $0)/..}
. $LUSTRE/tests/test-framework.sh
init_test_env $@
. ${CONFIG:=$LUSTRE/tests/cfg/$NAME.sh}
init_logging
FAIL_ON_ERROR=false

declare -r ROOT_FID="[0x200000007:0x1:0x0]"

check_versions || skip_env "no need to test lipe_find3 under interop mode"

(( OSTCOUNT >= 2 )) || skip_env "need at least 2 OSTs"

[[ $(facet_fstype mds1) = ldiskfs ]] || skip_env "need ldiskfs on MDS"

! remote_mds_nodsh || skip_env "remote MDS with nodsh"
! remote_ost_nodsh || skip_env "remote OSS with nodsh"

# check if lipe_find3 is installed on MDS(s)
for t in lipe_find3; do
	do_nodes $(comma_list $(all_mdts_nodes)) "which $t" ||
	skip_env "$t is not installed on MDS"
done

which jq || skip_env "jq is not installed"

# bug number for skipped test:
ALWAYS_EXCEPT="$SANITY_LIPE_FIND3_EXCEPT"

build_test_filter
check_and_setup_lustre
run_lfsck 2

if [ -d $MOUNT/.lustre/lost+found ] && [ "$(ls -A $MOUNT/.lustre/lost+found)" ]
then
	echo "Reformat file system"
	REFORMAT="yes" cleanup_and_setup_lustre
fi

# Try to support running from the build directory.
if [[ "$mds_HOST" == "$HOSTNAME" ]]; then
	# Fixup GUILE_LOAD_PATH to support running from the build directory.
	LIPE_SCAN3=$(which lipe_scan3)
	LIPE_SCAN3_DIR=$(dirname "$LIPE_SCAN3")
	if [[ "$LIPE_SCAN3_DIR" != /usr/bin ]]; then
		export GUILE_LOAD_PATH="$GUILE_LOAD_PATH:$LIPE_SCAN3_DIR"
	fi

	LIPE_FIND3=$(which lipe_find3)
	LIPE_FIND3_DIR=$(dirname "$LIPE_FIND3")
	if [[ "$LIPE_FIND3_DIR" != /usr/bin ]]; then
		export GUILE_LOAD_PATH="$GUILE_LOAD_PATH:$LIPE_FIND3_DIR"
	fi
fi

mount_client_on_facet() {
	local facet="$1"
	local nodes=$(facets_nodes "$facet")
	local node

	for node in $nodes; do
		if local_node $node; then
			continue
		fi

		zconf_mount_clients $node $MOUNT ||
			error "cannot mount client on node '$node' for facet '$facet'"

		stack_trap "zconf_umount_clients $node $MOUNT"
	done
}

function init_lipe_find3_env() {
	# Check "$MOUNT" is a Lustre client mount point.
	local fid=$($LFS path2fid "$MOUNT")
	[[ "$fid" == "$ROOT_FID" ]] || error "'$MOUNT' is not a lustre client mount"

	find "$MOUNT" -mindepth 1 -delete || error "cannot clean '$MOUNT'"
	find "$MOUNT" -mindepth 1 | grep . && error "find -delete did not delete all files from '$MOUNT'"

	mount_client_on_facet mds1

	for file in "$@"; do
		touch $file || error "cannot create $file"
		index=$($LFS getstripe --mdt-index $file)
		((index == 0)) || error "file '$file' is not on MDT0000"
	done

	sync
	sync
}

function lipe_find3_on() {
	local facet="$1"
	shift 1

	sync
	do_facet_vp "$facet" sync
	do_facet_vp "$facet" lipe_find3 "$@"
}

function lipe_find3_facet() {
	local facet="$1"
	local device="$(facet_device "$facet")"
	shift 1

	lipe_find3_on "$facet" "$device" "$@"
}

function expect_stdout() {
	"$@" | grep --quiet . || error "command '$*' should write to stdout"
}

function expect_no_stdout() {
	"$@" | grep . && error "command '$*' should not write to stdout"
	true
}

function expect_stderr() {
	"$@" 2>&1 > /dev/null | grep --quiet . || error "command '$*' should write to stderr"
}

function expect_no_stderr() {
	"$@" 2>&1 > /dev/null | grep . && error "command '$*' should not write to stderr"
	true
}

function expect_success() {
	"$@" > /dev/null || error "command '$*' failed"
}

function expect_failure() {
	"$@" 2> /dev/null && error "command '$*' should fail"
	true
}

function expect_print() {
	expect_success "$@"
	expect_stdout "$@"
	expect_no_stderr "$@"
}

function expect_empty() {
	expect_success "$@"
	expect_no_stdout "$@"
	expect_no_stderr "$@"
}

function expect_error() {
	expect_failure "$@"
	expect_no_stdout "$@"
	expect_stderr "$@"
}

function expect1() {
	# Will only DTRT with single line output due to how $(...)  and
	# == work.
	local str="$1"
	local out
	shift
	out=$("$@")
	[[ "$str" == "$out" ]] || error "$*: expected '$str', got '$out'"
}

sync_all_data_and_delay() {
	local start=$SECONDS

	sync_all_data
	# delay to give time for journal transaction to commit
	(( SECONDS - start > 1 )) || sleep 1
}

test_0() {
	expect_success true
	expect_failure false
	expect_no_stdout true
	expect_no_stderr true
	expect_stdout echo something
	expect_stderr grep --barf
	expect_print echo output
	expect_empty true
	expect_error grep --barf
}
run_test 0 "expect functions meet our expectations"

test_10() {
	expect_print lipe_find3_on mds1 -h
	expect_print lipe_find3_on mds1 --help

	expect_print lipe_find3_on mds1 -v
	expect_print lipe_find3_on mds1 --version

	expect_error lipe_find3_on mds1
	expect_error lipe_find3_on mds1 --barf
}
run_test 10 "lipe_find3 option handling"

test_11() {
	expect_error lipe_find3_on mds1 /dev/null
	expect_error lipe_find3_on mds1 /dev/zero
	expect_error lipe_find3_on mds1 /dev/zapper/mds1_flakey
	expect_error lipe_find3_on mds1 /dev/
	expect_error lipe_find3_on mds1 ''
	expect_error lipe_find3_on mds1
}
run_test 11 "lipe_find3 bad device handling"

test_12() {
	expect_error lipe_find3_facet mds1 -quux ZZZ
	expect_error lipe_find3_facet mds1 -quux
	expect_error lipe_find3_facet mds1 -size
	expect_error lipe_find3_facet mds1 -quux -quit
	expect_error lipe_find3_facet mds1 -not -quux -quit
	expect_error lipe_find3_facet mds1 -quit -quux

	expect_error lipe_find3_facet mds1 -name zalf zalf
	expect_error lipe_find3_facet mds1 true
	expect_error lipe_find3_facet mds1 name zalf
	expect_error lipe_find3_facet mds1 -true name zalf
	expect_error lipe_find3_facet mds1 name zalf -true
	expect_error lipe_find3_facet mds1 true
	expect_error lipe_find3_facet mds1 quux
}
run_test 12 "lipe_find3 bad tests"

test_90() {
	init_lipe_find3_env
	mount_client_on_facet ost1

	echo "-- for-test -------------------------------"
	echo "-- lipe_find3_facet mds1 ------------------"
	lipe_find3_facet mds1
	echo "-- lipe_find3_facet mds1 -print-file-fid  --"
	lipe_find3_facet  mds1 -print-file-fid
	for FID in $(lipe_find3_facet mds1 -print-file-fid); do
		echo "-- stat '$FID' ----------------------------"
		stat $MOUNT/.lustre/fid/$FID || true
		echo "-- getfattr -d -m trusted.link '$FID' -----"
		getfattr -d -m trusted.link $MOUNT/.lustre/fid/$FID | od -Ax -tx4 -a
	done
	echo "-------------------------------------------"

	# Create some files to be deleted.
	touch $MOUNT/f0
	mkdir $MOUNT/d0
	mkfifo $MOUNT/p0
	# lfs mkdir -c ... $MOUNT/d1 ....
	ln -s $MOUNT/f0 $MOUNT/l0
	mknod $MOUNT/c0 c 1 3
	# ...

	# XXX Run once to get rid of auto-compilation message.
	lipe_find3_facet mds1
	lipe_find3_facet ost1

	# Now delete those files.
	init_lipe_find3_env
	wait_delete_completed
	expect_empty lipe_find3_facet mds1
	expect_empty lipe_find3_facet ost1
}
run_test 90 "lipe_find3 on an empty FS"

test_100() {
	local facet=mds1
	local device="$(facet_device $facet)"
	local file=$MOUNT/$tfile
	local fid

	init_lipe_find3_env
	$LFS setstripe -i 0 "$file"
	echo XXX > "$file"
	fid=$($LFS path2fid "$file")

	expect1 "$fid" lipe_find3_facet mds1 -print-file-fid
	expect1 "$fid" lipe_find3_facet ost1 -print-file-fid
}
run_test 100 "lipe_find3 finds a file by MDT and OST"

declare -r S_IFREG=0100000
declare -a MODES=(0 1 0111 0222 0444 0555 0666 0777)

test_101() {
	local facet=mds1
	local device="$(facet_device $facet)"
	local file=$MOUNT/$tfile
	local fid

	init_lipe_find3_env "$file"
	fid=$($LFS path2fid "$file")
	chmod 0666 "$file"

	expect1 "$fid" lipe_find3_facet mds1 -perm 0666 -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -perm -0666 -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -perm -0600 -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -perm -0060 -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -perm -0400 -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -perm /0777 -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -perm /0477 -print-file-fid

	expect_empty lipe_find3_facet mds1 -perm 0777
	expect_empty lipe_find3_facet mds1 -perm 0667
	expect_empty lipe_find3_facet mds1 -perm 0700
	expect_empty lipe_find3_facet mds1 -perm /0100
	expect_empty lipe_find3_facet mds1 -perm /0111

	expect1 "$fid" lipe_find3_facet mds1 -perm ugo=rw -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -perm -ugo=rw -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -perm -ug=rw -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -perm -u=rw -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -perm -ugo=r -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -perm -ugo=w -print-file-fid

	expect_empty lipe_find3_facet mds1 -perm ugo=rwx
	expect_empty lipe_find3_facet mds1 -perm ug=wx,o=rwx
	expect_empty lipe_find3_facet mds1 -perm u=rwx
	expect_empty lipe_find3_facet mds1 -perm u=x
	expect_empty lipe_find3_facet mds1 -perm ugo=rwx

	chmod 0001 "$file"
	expect1 "$fid" lipe_find3_facet mds1 -perm 0001 -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -perm o=x -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -perm -o=x -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -perm /a=x -print-file-fid
	expect_empty lipe_find3_facet mds1 -perm 0
	expect_empty lipe_find3_facet mds1 -perm 0000
	expect_empty lipe_find3_facet mds1 -perm u=x
	expect_empty lipe_find3_facet mds1 -perm -u=x
	expect_empty lipe_find3_facet mds1 -perm /u=x
	expect_empty lipe_find3_facet mds1 -perm ugo=

	chmod 0000 "$file"
	expect1 "$fid" lipe_find3_facet mds1 -perm 0000 -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -perm ugo= -print-file-fid
	expect_empty lipe_find3_facet mds1 -perm -o=x
	expect_empty lipe_find3_facet mds1 -perm /a=x

	# ...
	expect_error lipe_find3_facet mds1 -perm 0q
	expect_error lipe_find3_facet mds1 -perm 9
	expect_error lipe_find3_facet mds1 -perm k=rxw
	expect_error lipe_find3_facet mds1 -perm u@rwx
	expect_error lipe_find3_facet mds1 -perm u=rwq
	expect_error lipe_find3_facet mds1 -perm u=q
	expect_error lipe_find3_facet mds1 -perm ugk=r
	expect_error lipe_find3_facet mds1 -perm =
	expect_error lipe_find3_facet mds1 -perm =r
	expect_error lipe_find3_facet mds1 -perm ''
	expect_error lipe_find3_facet mds1 -perm
}
run_test 101 "lipe_find3 perm does the right thing"

declare -a IDS=(
	0
	42
	500
	65534
	65535
	65536
	2147483646 # (INT_MAX - 1)
	2147483647 # (INT_MAX)
	2147483648 # (INT_MAX + 1)
	2177452800
	4294967293 # (UINT_MAX - 2)
)

test_102() {
	local file=$MOUNT/$tfile
	local fid
	local id
	local user

	init_lipe_find3_env
	$LFS setstripe -i 0 -c 1 "$file"
	fid=$($LFS path2fid "$file")
	echo XXX > "$file"
	sync

	id=$(stat --format=%u $file) # uid
	expect1 "$fid" lipe_find3_facet mds1 -user "$id" -print-file-fid
	expect1 "$fid" lipe_find3_facet ost1 -user "$id" -print-file-fid

	for id in "${IDS[@]}"; do
		chown $id $file || error "cannot set UID to '$id'"
		wait_delete_completed

		expect1 "$fid" lipe_find3_facet mds1 -user "$id" -print-file-fid
		expect1 "$fid" lipe_find3_facet ost1 -user "$id" -print-file-fid

		expect1 "$fid" lipe_find3_facet mds1 -uid "$id" -print-file-fid
		expect1 "$fid" lipe_find3_facet ost1 -uid "$id" -print-file-fid
	done

	user=sanityusr
	chown $user $file || error "cannot set user to '$user'"
	wait_delete_completed

	expect1 "$fid" lipe_find3_facet mds1 -user "$user" -print-file-fid
	expect1 "$fid" lipe_find3_facet ost1 -user "$user" -print-file-fid

	id=$(id -u "$user")
	expect1 "$fid" lipe_find3_facet mds1 -uid "$id" -print-file-fid
	expect1 "$fid" lipe_find3_facet ost1 -uid "$id" -print-file-fid

	expect_error lipe_find3_facet mds1 -user
	expect_error lipe_find3_facet mds1 -user ''
	expect_error lipe_find3_facet mds1 -user -QQQ
	expect_error lipe_find3_facet mds1 -user QQQ
	expect_error lipe_find3_facet mds1 -user 42QQQ
}
run_test 102 "lipe_find3 -user does the right thing"

test_103() {
	local file=$MOUNT/$tfile
	local fid
	local id
	local group

	init_lipe_find3_env
	$LFS setstripe -i 0 -c 1 "$file"
	fid=$($LFS path2fid "$file")
	echo XXX > "$file"
	sync

	id=$(stat --format=%g $file) # gid
	expect1 "$fid" lipe_find3_facet mds1 -group "$id" -print-file-fid
	expect1 "$fid" lipe_find3_facet ost1 -group "$id" -print-file-fid

	for id in "${IDS[@]}"; do
		chown :$id $file || error "cannot set GID to '$id'"
		wait_delete_completed

		expect1 "$fid" lipe_find3_facet mds1 -group "$id" -print-file-fid
		expect1 "$fid" lipe_find3_facet ost1 -group "$id" -print-file-fid

		expect1 "$fid" lipe_find3_facet mds1 -gid "$id" -print-file-fid
		expect1 "$fid" lipe_find3_facet ost1 -gid "$id" -print-file-fid
	done

	group=sanityusr
	chown :$group $file || error "cannot set group to '$group'"
	wait_delete_completed

	expect1 "$fid" lipe_find3_facet mds1 -group "$group" -print-file-fid
	expect1 "$fid" lipe_find3_facet ost1 -group "$group" -print-file-fid

	id=$(id -u "$group")
	expect1 "$fid" lipe_find3_facet mds1 -gid "$id" -print-file-fid
	expect1 "$fid" lipe_find3_facet ost1 -gid "$id" -print-file-fid

	expect_error lipe_find3_facet mds1 -group
	expect_error lipe_find3_facet mds1 -group ''
	expect_error lipe_find3_facet mds1 -group -QQQ
	expect_error lipe_find3_facet mds1 -group QQQ
	expect_error lipe_find3_facet mds1 -group 42QQQ
}
run_test 103 "lipe_find3 -group does the right thing"

declare -a SIZES=(
	         0
	        42
	2147483646 # (INT_MAX - 1)
	2147483647 # (INT_MAX)
	2147483648 # (INT_MAX + 1)
	2177452800
	4294967294 # (UINT_MAX - 1)
	4294967295 # (UINT_MAX)
	4294967296 # (UINT_MAX + 1)
	4815162342
	8589934591 # 0x1ffffffff
	48151623420
	481516234200
)

test_104() {
	local facet=mds1
	local device="$(facet_device $facet)"
	local file=$MOUNT/$tfile
	local fid
	local size

	init_lipe_find3_env "$file"
	fid=$($LFS path2fid "$file")

	# XXX find uses 512 byte default unity for size

	expect1 "$fid" lipe_find3_facet mds1 -size 0 -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -size 0b -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -size 0c -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -size 0k -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -size 0M -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -size 0G -print-file-fid

	expect_empty lipe_find3_facet mds1 -size +0
	expect_empty lipe_find3_facet mds1 -size +0b
	expect_empty lipe_find3_facet mds1 -size +0c
	expect_empty lipe_find3_facet mds1 -size +0k
	expect_empty lipe_find3_facet mds1 -size +0M
	expect_empty lipe_find3_facet mds1 -size +0G

	expect_empty lipe_find3_facet mds1 -size -0
	expect_empty lipe_find3_facet mds1 -size -0b
	expect_empty lipe_find3_facet mds1 -size -0c
	expect_empty lipe_find3_facet mds1 -size -0k
	expect_empty lipe_find3_facet mds1 -size -0M
	expect_empty lipe_find3_facet mds1 -size -0G

	expect1 "$fid" lipe_find3_facet mds1 -size -1b -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -size -1k -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -size -1M -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -size -1G -print-file-fid

	truncate "$file" 512
	expect1 "$fid" lipe_find3_facet mds1 -size 1b -print-file-fid

	# Match finds quirky +/- rounding blah blah.
	truncate "$file" 1023
	expect_empty lipe_find3_facet mds1 -size -1k
	expect1 "$fid" lipe_find3_facet mds1 -size 1k -print-file-fid
	expect_empty lipe_find3_facet mds1 -size +1k

	truncate "$file" 1024
	expect_empty lipe_find3_facet mds1 -size -1k
	expect1 "$fid" lipe_find3_facet mds1 -size 1k -print-file-fid
	expect_empty lipe_find3_facet mds1 -size +1k

	truncate "$file" 1025
	expect_empty lipe_find3_facet mds1 -size 1k
	expect1 "$fid" lipe_find3_facet mds1 -size +1k -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -size 2k -print-file-fid
	expect_empty lipe_find3_facet mds1 -size -2k
	expect_empty lipe_find3_facet mds1 -size +2k

	truncate "$file" 1048576
	expect1 "$fid" lipe_find3_facet mds1 -size 1M -print-file-fid

	truncate "$file" 1073741824
	expect1 "$fid" lipe_find3_facet mds1 -size 1G -print-file-fid

	for size in "${SIZES[@]}"; do
		$TRUNCATE $file $size
		expect1 "$fid" lipe_find3_facet mds1 -size ${size}c -print-file-fid
	done

	expect_error lipe_find3_facet mds1 -size
	expect_error lipe_find3_facet mds1 -size QQQ
	expect_error lipe_find3_facet mds1 -size ''
	expect_error lipe_find3_facet mds1 -size 1Q
	expect_error lipe_find3_facet mds1 -size -1Q
	expect_error lipe_find3_facet mds1 -size +1Q

	# expect_attr "$device" blocks 0
}
run_test 104 "lipe_find3 -size does the right thing"

test_105() {
	local facet=mds1
	local device="$(facet_device $facet)"
	local file=$MOUNT/$tfile
	local fid

	init_lipe_find3_env "$file"
	fid=$($LFS path2fid "$file")

	expect_empty lipe_find3_facet mds1 -links 0
	expect1 "$fid" lipe_find3_facet mds1 -links +0 -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -links 1 -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -links -2 -print-file-fid

	ln $file $file-2
	expect_empty lipe_find3_facet mds1 -links 1
	expect1 "$fid" lipe_find3_facet mds1 -links 2 -print-file-fid

	ln $file $file-3
	expect_empty lipe_find3_facet mds1 -links 2
	expect1 "$fid" lipe_find3_facet mds1 -links 3 -print-file-fid

	expect_error lipe_find3_facet mds1 -links
	expect_error lipe_find3_facet mds1 -links ''
	expect_error lipe_find3_facet mds1 -links QQQ
	expect_error lipe_find3_facet mds1 -links 42QQQ

	# If we hold $file open and remove all three links then
	# lipe_find3 will still return a link count of 1 because of
	# the PENDING/$fid link.
}
run_test 105 "lipe_find3 -links does the right thing"

test_106() {
	local file=$MOUNT/$tfile
	local fid

	init_lipe_find3_env "$file"
	fid=$($LFS path2fid "$file")

	id=$($LFS project "$file" | awk '{ print $1 }')
	expect1 "$fid" lipe_find3_facet mds1 -projid "$id" -print-file-fid

	for id in "${IDS[@]}"; do
		[[ $id =~ ^[0-9]+$ ]] || continue # exclude sanityusr

		$LFS project -p "$id" "$file" || error "cannot set projid to '$id'"
		expect1 "$fid" lipe_find3_facet mds1 -projid "$id" -print-file-fid
	done

	expect_error lipe_find3_facet mds1 -projid
	expect_error lipe_find3_facet mds1 -projid ''
	expect_error lipe_find3_facet mds1 -projid QQQ
}
run_test 106 "lipe_find3 -projid does the right thing"

test_107() {
	local file=$MOUNT/$tfile
	local fid

	init_lipe_find3_env "$file"
	fid=$($LFS path2fid "$file")

	expect1 "$fid" lipe_find3_facet mds1 -type f -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -type f,b -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -type f,b,d -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -type b,c,d,p,f,l,s -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -not -type d -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -not -type b,c,d,p,l,s -print-file-fid

	expect_empty lipe_find3_facet mds1 -type d
	expect_empty lipe_find3_facet mds1 -type b,c,d,p,l,s
	expect_empty lipe_find3_facet mds1 -not -type b,c,d,p,f,l,s

	expect_error lipe_find3_facet mds1 -type
	# expect_error lipe_find3_facet mds1 -type '' FIXME
	expect_error lipe_find3_facet mds1 -type q
	expect_error lipe_find3_facet mds1 -type b,c,d,p,l,s,q

}
run_test 107 "lipe_find3 -type does the right thing"

test_108() {
	local file=$MOUNT/$tfile
	local fid

	init_lipe_find3_env "$file"
	fid=$($LFS path2fid "$file")

	# -name '' fails with "lipe_find3: FATAL: at argument 2:
	# missing argument to '-name'". find is OK with -name ''.
	expect1 "$fid" lipe_find3_facet mds1 -name "$tfile" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -name "$tfile*" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -name "*$tfile" -print-file-fid
	expect_empty lipe_find3_facet mds1 -name "dagobert.txt"

	mv "$file" "$MOUNT/zalf.x"
	expect1 "$fid" lipe_find3_facet mds1 -name "zalf.x" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -name "*.x" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -name "zalf.?" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -name "[yz]alf.x" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -name "[yz]*.x" -print-file-fid
	expect_empty lipe_find3_facet mds1 -name "dagobert.txt"

	expect1 "$fid" lipe_find3_facet mds1 -iname "zalf.x" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "*.x" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "zalf.?" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "[yz]alf.x" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "[yz]*.x" -print-file-fid
	expect_empty lipe_find3_facet mds1 -iname "dagobert.txt"

	expect1 "$fid" lipe_find3_facet mds1 -iname "ZALF.X" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "Zalf.x" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "*.x" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "ZALF.?" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "[yz]ALF.x" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "[YZ]*.X" -print-file-fid
	expect_empty lipe_find3_facet mds1 -iname "dagobert.txt"
	expect_empty lipe_find3_facet mds1 -iname "DAGOBERT.TXT"

	ln "$MOUNT/zalf.x" "$MOUNT/schmerp.out"
	expect1 "$fid" lipe_find3_facet mds1 -name "*.x" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -name "zalf.?" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -name "[yz]alf.x" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -name "[yz]*.x" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -name "schmerp.out" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "SCHMERP.out" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "SCHMERP.OUT" -print-file-fid

	expect_error lipe_find3_facet mds1 -name
}
run_test 108 "lipe_find3 -name and -iname do the right thing"

test_109() {
	local dir="${MOUNT}/${tdir}-z12z"
	local fid

	init_lipe_find3_env

	lfs mkdir -i 0 $dir
	sync_all_data_and_delay

	fid=$($LFS path2fid "$dir")

	expect1 "$fid" lipe_find3_facet mds1 -path "${tdir}-z12z" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -path "${tdir}-z12z*" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -path "*${tdir}-z12z" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -path "*${tdir}-z12z*" -print-file-fid

	expect1 "$fid" lipe_find3_facet mds1 -path "${tdir}-z1*" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -path "${tdir}-*2z" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -path "${tdir}-*2*" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -path "${tdir}-z*z" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -path "${tdir}-z1?z" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -path "${tdir}-z12?" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -path "${tdir}-?12z" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -path "${tdir}-*1?z" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -path "${tdir}-*12?" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -path "${tdir}-*2?" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -path "${tdir}-?1*" -print-file-fid

	expect_empty lipe_find3_facet mds1 -path "${tdir}-Z12?"
	expect_empty lipe_find3_facet mds1 -path "${tdir}-Z1*"
	expect_empty lipe_find3_facet mds1 -path "${tdir}-xxx"
	expect_empty lipe_find3_facet mds1 -path "${tdir}-x*"
	expect_empty lipe_find3_facet mds1 -ipath "${tdir}-xxx"
	expect_empty lipe_find3_facet mds1 -ipath "${tdir}-XxX"
	expect_empty lipe_find3_facet mds1 -ipath "${tdir}-X*"
	expect_empty lipe_find3_facet mds1 -ipath "${tdir}-x*"
	expect_empty lipe_find3_facet mds1 -ipath "${tdir}-*X*"
	expect_empty lipe_find3_facet mds1 -ipath "${tdir}-*x*"

	expect1 "$fid" lipe_find3_facet mds1 -ipath "${tdir}-z12z" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -ipath "${tdir}-Z12Z*" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -ipath "${tdir}-*Z12Z" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -ipath "${tdir}-*Z12Z*" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -ipath "${tdir}-Z*Z" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -ipath "${tdir}-Z1*" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -ipath "${tdir}-*2Z" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -ipath "${tdir}-Z?2*" -print-file-fid

	init_lipe_find3_env
}
run_test 109 "lipe_find3 -path and -ipath do the right thing"

test_110() {
	local file=$MOUNT/$tfile
	local fid
	local pool=$TESTNAME

	pool_add "$pool" || error "cannot add pool '$pool'"
	pool_add_targets "$pool" 0 || error "cannot add OST 0 to '$pool'"

	init_lipe_find3_env
	$LFS setstripe -c1 -p "$pool" "$file"
	echo XXX > "$file"
	fid=$($LFS path2fid "$file")

	expect1 "$fid" lipe_find3_facet mds1 -pool "$pool" -print-file-fid
	expect_empty lipe_find3_facet mds1 -pool ""
	expect_empty lipe_find3_facet mds1 -pool quux

	rm "$file"
	echo XXX > "$file"
	fid=$($LFS path2fid "$file")

	expect1 "$fid" lipe_find3_facet mds1 \! -pool "$pool" -print-file-fid
	expect_empty lipe_find3_facet mds1 -pool ""

	# We do not validate user supplied pool names in lipe_find3 or
	# lipe_scan3. This is because it is possible for LOV xattrs to
	# contain pool that no longer exist.
	expect_error lipe_find3_facet mds1 -pool
}
run_test 110 "lipe_find3 -pool does the right thing"

test_111() {
	local file=$MOUNT/$tfile
	local name="user.$TESTNAME"
	local fid

	init_lipe_find3_env "$file"
	fid=$($LFS path2fid "$file")

	setfattr -n "$name" "$file"
	expect1 "$fid" lipe_find3_facet mds1 -xattr "$name" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -xattr-match "$name" '' -print-file-fid
	expect_empty lipe_find3_facet mds1 -xattr-match "$name" XXX -print-file-fid

	expect1 "$fid" lipe_find3_facet mds1 -xattr trusted.lma -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -xattr trusted.lov -print-file-fid

	setfattr -n "$name" -v XXX "$file"
	expect1 "$fid" lipe_find3_facet mds1 -xattr "$name" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -xattr-match "$name" XXX -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -xattr-match '*' XXX -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -xattr-match "$name" '*' -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -xattr-match "$name" 'X*' -print-file-fid
	expect_empty lipe_find3_facet mds1 -xattr-match "$name" '' -print-file-fid

	expect_empty lipe_find3_facet mds1 -xattr "${name}-1" -print-file-fid
	expect_empty lipe_find3_facet mds1 -xattr-match "${name}-1" '*' -print-file-fid

	expect_error lipe_find3_facet mds1 -xattr
}
run_test 111 "lipe_find3 -xattr does the right thing"

test_112() {
	local file=$MOUNT/$tfile
	local x
	declare -a fid

	init_lipe_find3_env

	for x in 1 2 3; do
		$LFS setstripe -i 0 -c ${x} "$file-"${x}
		fid[${x}]=$($LFS path2fid "$file-"${x})
		echo XXX > "$file-"${x}
	done
	sync

	for x in 1 2 3; do
		expect1 "${fid[${x}]}" lipe_find3_facet mds1 \
			-stripe-count "${x}" -print-file-fid
	done

	expect_empty lipe_find3_facet mds1 -stripe-count 4 -print-file-fid

	init_lipe_find3_env
}
run_test 112 "lipe_find3 -stripe-count does the right thing"

test_113() {
	local file=$MOUNT/$tfile
	declare -a fid
	local x

	init_lipe_find3_env

	for x in 1 2 3; do
		$LFS mirror create --mirror-count=${x} "$file-"${x}
		fid[${x}]=$($LFS path2fid "$file-"${x})
	done
	sync

	for x in 1 2 3; do
		expect1 "${fid[${x}]}" lipe_find3_facet mds1 \
			-mirror-count "${x}" -print-file-fid
	done

	expect_empty lipe_find3_facet mds1 -mirror-count 4 -print-file-fid

	init_lipe_find3_env
}
run_test 113 "lipe_find3 -mirror-count does the right thing"

test_114() {
	local utf8="種多語言神經機"		# Chinese glyphs are case insensitive
	local test_file="${tfile}-${utf8}.txt"
	local file=$MOUNT/$test_file
	local fid

	init_lipe_find3_env "$file"
	fid=$($LFS path2fid "$file")

	expect1 "$fid" lipe_find3_facet mds1 -name "$test_file"   -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -name "$test_file*"  -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -name "*$test_file"  -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -name "*.txt"        -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -name "*種多語言神經?.txt" -print-file-fid

	# Note Chinese glyphs do not have lower case
	expect1 "$fid" lipe_find3_facet mds1 -iname "$test_file"   -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "$test_file*"  -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "*$test_file"  -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "*.txt"        -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "*多語言神經?.txt"  -print-file-fid

	utf8="가나다"			# Korean glyphs are case insensitive
	test_file="${tfile}-${utf8}.txt"
	mv "$file" "$MOUNT/$test_file"
	file="$MOUNT/$test_file"

	expect1 "$fid" lipe_find3_facet mds1 -name "$test_file"  -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -name "$test_file*" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -name "*$test_file" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -name "*.txt"       -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -name "*나?.txt"     -print-file-fid

	# Note Korean glyphs do not have lower case
	expect1 "$fid" lipe_find3_facet mds1 -iname "$test_file"  -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "$test_file*" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "*$test_file" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "*.txt"       -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "*나?.txt"     -print-file-fid

	utf8="ÖŞn"					# Turkish
	test_file="${tfile}-${utf8}.txt"
	mv "$file" "$MOUNT/$test_file"
	file="$MOUNT/$test_file"

	expect1 "$fid" lipe_find3_facet mds1 -name "$test_file"  -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -name "$test_file*" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -name "*$test_file" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -name "*.txt"       -print-file-fid

	expect1 "$fid" lipe_find3_facet mds1 -iname "$test_file"  -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "$test_file*" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "*$test_file" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "*.txt"       -print-file-fid

	utf8="öşn"				# Turkish small letters
	test_file="${tfile}-${utf8}.txt"

	expect1 "$fid" lipe_find3_facet mds1 -iname "*ş*.txt"    -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "*Ş*"        -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "$test_file" -print-file-fid

	utf8="ßäü"				# German small letter
	test_file="${tfile}-${utf8}.txt"
	mv "$file" "$MOUNT/$test_file"
	file="$MOUNT/$test_file"

	expect1 "$fid" lipe_find3_facet mds1 -name "$test_file" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -name "$test_file*" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -name "*$test_file" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -name "*ü.txt" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -name "*ß?ü.txt" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -name "*.txt" -print-file-fid

	expect1 "$fid" lipe_find3_facet mds1 -iname "$test_file" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "$test_file*" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "*$test_file" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "*.txt" -print-file-fid

	utf8="ẞäÜ"				# German upper and small letters
	test_file="${tfile}-${utf8}.txt"
	expect1 "$fid" lipe_find3_facet mds1 -iname "*Ü.txt" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -iname "$test_file" -print-file-fid

	init_lipe_find3_env
}
run_test 114 "lipe_find3 -name and -iname with UTF-8"

test_115() {
	local td="${tdir}-多言神經-가나다-ßäü"
	local dir="${MOUNT}/${td}"
	local fid

	init_lipe_find3_env

	lfs mkdir -i 0 $dir
	sync_all_data_and_delay

	fid=$($LFS path2fid "$dir")

	expect1 "$fid" lipe_find3_facet mds1 -path "${td}"   -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -path "${td}*"  -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -path "*${td}"  -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -path "*${td}*" -print-file-fid

	expect1 "$fid" lipe_find3_facet mds1 -path "${tdir}-多言神經-가나다-ßä*" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -path "${tdir}-*言神經-가나다-ßäü" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -path "*言神經-가나다-ßä*"         -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -path "${tdir}-多*ü"          -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -path "${tdir}-多言神經-가나다-ß?ü" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -path "${tdir}-多言神經-가나다-ßä?" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -path "${tdir}-?言神經-가나다-ßäü" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -path "${tdir}-?言神經-가나다-ß*ü" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -path "*言神經-가나다-ßä?"         -print-file-fid

	expect_empty lipe_find3_facet mds1 -path "${tdir}-多言神經-가나다-ßäÜ"
	expect_empty lipe_find3_facet mds1 -path "${tdir}-*Ü"

	expect1 "$fid" lipe_find3_facet mds1 -ipath "${td}" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -ipath "${tdir}-多言神經-가나다-ẞ?Ü*" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -ipath "*ẞä*" -print-file-fid
	expect1 "$fid" lipe_find3_facet mds1 -ipath "*Ü"   -print-file-fid

	init_lipe_find3_env
}
run_test 115 "lipe_find3 -path and -ipath with UTF-8"

test_116() {
	local file=$MOUNT/$tfile
	declare -a fid
	local mb=1
	local first_pool=tst_pool
	declare -A fid_s
	local combined="($first_pool"
	local x

	init_lipe_find3_env

	for x in 1 2 3; do
		$LFS mirror create --mirror-count=$x "$file-$x" ||
			error "cannot create mirror for $file-$x"
		fid[${x}]=$($LFS path2fid "$file-"${x})
	done
	sync

	for x in 1 2 3; do
		expect1 "$x ${fid[${x}]}" lipe_find3_facet mds1 \
			-mirror-count $x -printf  '%{mirror-count} %{fid}'
		expect1 "$x ${fid[${x}]}" lipe_find3_facet mds1 \
			-mirror-count $x -printf  '%LN %{fid}'
	done

	expect_empty lipe_find3_facet mds1 -mirror-count 4 \
		-printf  '%{mirror-count}'

	rm $file*

	for x in 1 2 3; do
		$LFS setstripe -i 0 -c $x "$file-1-$x" ||
			error "cannot setstripe $x for file $file-1-$x"
		fid[${x}]=$($LFS path2fid "$file-1-$x")
		echo XXX > "$file-1-$x"
	done
	sync

	for x in 1 2 3; do
		expect1 "$x ${fid[${x}]}" lipe_find3_facet mds1 \
			-stripe-count $x -printf '%{stripe-count} %{fid}'
		expect1 "$x ${fid[${x}]}" lipe_find3_facet mds1 \
			-stripe-count $x -printf '%Lc %{fid}'
	done

	expect_empty lipe_find3_facet mds1 -stripe-count 4 -printf '%{fid}'

	rm $file*

	for x in 1001 1002 1003; do
		touch "$file-2-$x"
		$LFS project -p $x $file-2-$x ||
			error "cannot set project $x for file $file-2-$x"
		fid[${x}]=$($LFS path2fid "$file-2-$x")
	done
	sync

	for x in 1001 1002 1003; do
		expect1 "$x ${fid[${x}]}" lipe_find3_facet mds1 \
			-projid $x -printf '%{projid} %{fid}'
	done

	expect_empty lipe_find3_facet mds1 -projid 1 -printf '%{projid} %{fid}'

	rm $file*

	for x in 1 2 3; do
		touch "$file-3-$x"
		setfattr -n user.$x -v $x "$file-3-$x"
		fid[${x}]=$($LFS path2fid "$file-3-$x")
	done
	sync

	for x in 1 2 3; do
		local format='%{xattr:user.'"$x"'} %{fid}'
		expect1 "$x ${fid[${x}]}" lipe_find3_facet mds1 \
			-xattr user.$x -printf "${format}"
	done

	rm $file*

	for x in 65536 131072 196608; do
		$LFS setstripe -i 0 -c 1 --stripe-size $x "$file-4-$x" ||
			error "cannot setstripe size $x for file $file-4-$x"
		fid[${x}]=$($LFS path2fid "$file-4-$x")
		echo XXX > "$file-4-$x"
	done
	sync

	for x in 65536 131072 196608; do
		expect1 "$x ${fid[${x}]}" lipe_find3_facet mds1 \
			-name $tfile-4-$x -printf '%{stripe-size} %{fid}'
		expect1 "$x ${fid[${x}]}" lipe_find3_facet mds1 \
			-name $tfile-4-$x -printf '%LS %{fid}'
	done

	# Test pool and pools options
	$LFS setstripe -E "$mb"M -c 1 --pool "$first_pool" "$file-pfl-all" ||
		error "cannot first setstripe pool $x for file $file-pfl-all"

	for x in testpool newpool oldpool; do
		$LFS setstripe -c 1 --pool "$x" "$file-5-$x" ||
			error "cannot setstripe pool "$x" for file $file-5-$x"

		fid_s[${x}]=$($LFS path2fid "$file-5-$x")
		echo XXX > "$file-5-$x"

		mb=$((mb + 10))
		$LFS setstripe --comp-add -E "$mb"M -c 1 \
						--pool $x "$file-pfl-all" ||
			error "cannot setstripe pool $x for file $file-pfl-all"

		echo XXX >> "$file-pfl-all"
	done
	pfid=$($LFS path2fid "$file-pfl-all")
	sync

	for x in testpool newpool oldpool; do
		combined+=" $x"
		expect1 "$x ${fid_s[${x}]}" lipe_find3_facet mds1 \
			-name $tfile-5-$x -printf '%{pool} %{fid}'
		expect1 "$x ${fid_s[${x}]}" lipe_find3_facet mds1 \
			-name $tfile-5-$x -printf '%Lp %{fid}'
	done
	combined+=")"

	expect1 "$combined $pfid" lipe_find3_facet mds1 \
		-name $tfile-pfl-all -printf '%{pools} %{fid}'

	expect1 "newpool $pfid" lipe_find3_facet mds1 \
		-name $tfile-pfl-all -printf '%Lp %{fid}'

	init_lipe_find3_env
}
run_test 116 "lipe_find3 verify printf formats"

test_130() {
	local file=$MOUNT/$tfile
	local xtime
	local xmin
	local now
	local fid

	init_lipe_find3_env "$file"
	fid=$($LFS path2fid "$file")

	# -atime n means last accessed n * 24 hours ago.  When find
        # figures out how many 24-hour periods ago the fil e was last
        # accessed, any fractional part is ignored, so to match -atime
        # +1, a file has to have been accessed at least two days ago.

	for x in a m c; do
		xtime="-${x}time"
		xmin="-${x}min"

		expect_empty lipe_find3_facet mds1 $xtime -0
		expect1 "$fid" lipe_find3_facet mds1 $xtime 0 -print-file-fid
		expect_empty lipe_find3_facet mds1 $xtime +0
		expect1 "$fid" lipe_find3_facet mds1 $xtime -1 -print-file-fid
		expect_empty lipe_find3_facet mds1 $xtime 1

		expect_empty lipe_find3_facet mds1 $xmin -0
		expect1 "$fid" lipe_find3_facet mds1 $xmin -10 -print-file-fid
		expect_empty lipe_find3_facet mds1 $xmin 10
		expect_empty lipe_find3_facet mds1 $xmin +10

		if [[ $x == c ]]; then
			continue
		fi

		now=$(date +%s)
		touch -$x --date=@$((now - 25 * 3600)) $file
		expect_empty lipe_find3_facet mds1 $xtime 0
		expect1 "$fid" lipe_find3_facet mds1 $xtime +0 -print-file-fid
		expect_empty lipe_find3_facet mds1 $xtime -1
		expect1 "$fid" lipe_find3_facet mds1 $xtime 1 -print-file-fid
		expect_empty lipe_find3_facet mds1 $xtime +1
		expect1 "$fid" lipe_find3_facet mds1 $xtime -2 -print-file-fid

		expect_empty lipe_find3_facet mds1 $xtime -86400s
		expect_empty lipe_find3_facet mds1 $xtime 86400s
		expect1 "$fid" lipe_find3_facet mds1 $xtime +86400s -print-file-fid

		expect_empty lipe_find3_facet mds1 $xtime -1440m
		expect_empty lipe_find3_facet mds1 $xtime 1440m
		expect1 "$fid" lipe_find3_facet mds1 $xtime +1440m -print-file-fid

		expect_empty lipe_find3_facet mds1 $xmin -1440
		expect_empty lipe_find3_facet mds1 $xmin 1440
		expect1 "$fid" lipe_find3_facet mds1 $xmin +1440 -print-file-fid

		expect_empty lipe_find3_facet mds1 $xtime -24h
		expect_empty lipe_find3_facet mds1 $xtime 24h
		expect1 "$fid" lipe_find3_facet mds1 $xtime +24h -print-file-fid

		expect_empty lipe_find3_facet mds1 $xtime -25h
		expect1 "$fid" lipe_find3_facet mds1 $xtime 25h -print-file-fid
		expect_empty lipe_find3_facet mds1 $xtime +25h

		expect_empty lipe_find3_facet mds1 $xtime -1d
		expect1 "$fid" lipe_find3_facet mds1 $xtime 1d -print-file-fid
		expect_empty lipe_find3_facet mds1 $xtime +1d

		expect1 "$fid" lipe_find3_facet mds1 $xtime -93600s -print-file-fid
		expect1 "$fid" lipe_find3_facet mds1 $xtime -1560m -print-file-fid
		expect1 "$fid" lipe_find3_facet mds1 $xtime -26h -print-file-fid
		expect1 "$fid" lipe_find3_facet mds1 $xtime -2d -print-file-fid

		now=$(date +%s)
		touch -$x --date=@$((now - 30 * 86400 - 3600)) $file
		expect_empty lipe_find3_facet mds1 $xtime 0
		expect_empty lipe_find3_facet mds1 $xtime -30
		expect1 "$fid" lipe_find3_facet mds1 $xtime 30 -print-file-fid
		expect_empty lipe_find3_facet mds1 $xtime +30
	done

	expect_error lipe_find3_facet mds1 -atime
	expect_error lipe_find3_facet mds1 -atime ''
	expect_error lipe_find3_facet mds1 -atime QQQ
	expect_error lipe_find3_facet mds1 -atime 42Q
	expect_error lipe_find3_facet mds1 -atime +42Q
	expect_error lipe_find3_facet mds1 -atime +
	expect_error lipe_find3_facet mds1 -atime -
}
run_test 130 "lipe_find3 {a,m,c}{time,min} do the right thing"

# 200 printing
# print-file-fid
# print-self-fid
# print-json
# print-absolute-path
# print-relative-path

# fprint
# fprint0
# printf
# fprintf

# 300 actions
# No implicit print when there is an explicit action

# exec ... {} \;
# exec ... {} +
test_300() {
	local file=$MOUNT/$tfile
	local fid

	init_lipe_find3_env

	# Need quotes around ; to protect from do_facet.
	# Does this work with ssh?

	expect_empty lipe_find3_facet mds1 -exec echo {} \;
	expect_empty lipe_find3_facet mds1 -exec echo x{}x \;
	expect_empty lipe_find3_facet mds1 -exec $LFS path2fid {} \;
	expect_empty lipe_find3_facet mds1 -exec cat {} \;

	echo 4815162342 > "$file"
	fid=$($LFS path2fid "$file")

	expect_empty lipe_find3_facet mds1 -exec true \;
	expect_empty lipe_find3_facet mds1 -exec true {} \;
	expect1 "$file" lipe_find3_facet mds1 -exec echo {} \;
	expect1 "$file $file" lipe_find3_facet mds1 -exec echo {} {} \;
	expect1 "$file $file" lipe_find3_facet mds1 -exec echo "{} {}" \;
	expect1 "${file}x" lipe_find3_facet mds1 -exec echo "{}x" \;
	expect1 "x${file}x" lipe_find3_facet mds1 -exec echo "x{}x" \;
	expect1 "$fid" lipe_find3_facet mds1 -exec $LFS path2fid {} \;
	expect1 4815162342 lipe_find3_facet mds1 -exec cat {} \;

	# $ find /mnt/lustre -exec zalp {} \;
	# find: "zalp": No such file or directory
	# $ echo $?
	# 0

	expect_error lipe_find3_facet mds1 -exec cat
	expect_error lipe_find3_facet mds1 -exec cat {}
	expect_error lipe_find3_facet mds1 -exec cat { \;
	expect_error lipe_find3_facet mds1 -exec cat xx{xxx \;
}
run_test 300 "lipe_find3 -exec does the right thing"

test_301() {
	local file=$MOUNT/$tfile
	local fid
	local count

	init_lipe_find3_env

	expect_empty lipe_find3_facet mds1 -exec echo {} +
	expect_empty lipe_find3_facet mds1 -exec $LFS path2fid {} +
	expect_empty lipe_find3_facet mds1 -exec cat {} +

	echo 4815162342 > "$file"
	echo 4815162342 > "$file"-2

	expect_empty lipe_find3_facet mds1 -exec true {} +
	count=$(lipe_find3_facet mds1 -exec cat {} + | grep --count 4815162342)
	((count == 2)) || error "expected count 2, got $count"

	# {} must be present in -exec ... +
	# {} must be the last argument in -exec ... +
	# {} must occur by it self
	# only one instance of {} is supported with -exec ... +
	expect_error lipe_find3_facet mds1 -exec cat +
	expect_error lipe_find3_facet mds1 -exec cat {} zzz +
	expect_error lipe_find3_facet mds1 -exec cat {} {} +
	expect_error lipe_find3_facet mds1 -exec cat x{}x +
}
run_test 301 "lipe_find3 -exec + does the right thing"

test_350() {
	local file=$MOUNT/$tfile
	local dir=$MOUNT/$tdir

	init_lipe_find3_env

	echo "-- for-test -------------------------------"
	echo "-- lipe_find3_facet mds1 ------------------"
	lipe_find3_facet mds1
	echo "-- lipe_find3_facet mds1 -print-file-fid --"
	lipe_find3_facet mds1 -print-file-fid
	for FID in $(lipe_find3_facet mds1 -print-file-fid); do
		echo "-- stat '$FID' ----------------------------"
		stat $MOUNT/.lustre/fid/$FID || true
		echo "-- getfattr -d -m trusted.link '$FID' -----"
		getfattr -d -m trusted.link $MOUNT/.lustre/fid/$FID | od -Ax -tx4 -a
	done
	echo "-------------------------------------------"

	expect_empty lipe_find3_facet mds1 -delete

	echo 4815162342 > "$file"
	echo 4815162342 > "$file"-2

	expect_empty lipe_find3_facet mds1 -delete
	if [[ -f "$file" ]] || [[ -f "$file"-2 ]]; then
		error "$file and $file-2 were not deleted"
	fi

	lfs mkdir -i0 -c1 $dir
	expect_empty lipe_find3_facet mds1 -delete
	if [[ -d "$dir" ]]; then
		error "$dir was not deleted"
	fi

	# ....
	# expect_error lipe_find3_facet mds1 -delete
}
run_test 350 "lipe_find3 -delete does the right thing"

create_directories_and_files() {
	local current_dir=$1

	for i in {1..10}; do
		mkdir_on_mdt0 "$current_dir/dir$i"
		current_dir="$current_dir/dir$i"
		fallocate -l "${i}M" "$current_dir/file$i.bin"
		lfs somsync "$current_dir/file$i"
	done
	sync
}

test_351() {
	local facet=mds1
	local main_dir=$DIR/$tdir
	local report_path="$MOUNT/$tfile.out"
	local file=$MOUNT/$tfile
	local result
	local depth=11			# depth == 11 (10 dirs + main_dir)
	local obtained_depth
	local obtained_res
	local expected_res=440
	init_lipe_find3_env "$file"

	mkdir_on_mdt0 $main_dir
	stack_trap "rm -rf $main_dir"
	create_directories_and_files $main_dir

	out=$(lipe_find3_facet "$facet" -depth "$depth" -collect-fsize-stats "$report_path")
	[[ $? -ne 0 ]] && error "lipe_find3 collect-fsize-stats failed"

	cat "$report_path"
	result=$(awk '/Top 100 largest directories:/ {start=1}
		 start && /^_Alloc_Size_/ {f=1; next}
		 f && !/^_/ {sum += int($1 + 0.5); count++}
		 f && /^_Alloc_Size_/ {f=0}
		 END {print sum, count} ' "$report_path")

	obtained_res=$(echo "$result" | awk '{print $1}')
	(( obtained_res == expected_res )) ||
		error "expected size value '$expected_res', got '$obtained_res'"

	obtained_depth=$(echo "$result" | awk '{print $2}')
	(( obtained_depth == depth )) ||
		error "expected count dirs value '$depth', got '$obtained_depth'"
}
run_test 351 "lipe_find3 --collect-fsize-stats | check TOP-X rating for dirs"

check_reports() {
	local report_path="$1"		# Path to report.json
	local exp_count="$2"
	local count			# GeneralInfo.Count
	local exp_tot_val="$3"
	local total_value		# GeneralInfo.TotalValue
	local exp_min="$4"
	local min			# GeneralInfo.Min
	local exp_max="$5"
	local max			# GeneralInfo.Max
	local exp_avg="$6"
	local avg			# GeneralInfo.Avg
	local table_id="$7"		# GeneralInfo.TableId
	local ranges_cnt		# Ranges[] array lenght
	local total_in_ranges		# Ranges[all].TotalInRange
	local count_in_ranges		# Ranges[all].CountInRange
	local table_title		# GeneralInfo.Title
	local table_exists

	# Add check here for table ID
	table_exists=$(cat "$report_path" | jq -e --argjson id "$table_id" \
		       '.Reports[] | select(.GeneralInfo.TableId == $id)')

	[[ -n "$table_exists" ]] || return 1

	table_title=$(cat "$report_path" | jq -r --argjson id "$table_id" \
		      '.Reports[] | select(.GeneralInfo.TableId == $id) |
		      .GeneralInfo.Title')

	echo "start check "$table_title""

	# Check objects count
	count=$(cat "$report_path" |
		jq -r --argjson id "$table_id" \
		'.Reports[] | select(.GeneralInfo.TableId == $id) |
		.GeneralInfo.Count')

	(( exp_count == count )) ||
		error "expected count obj '$exp_count', got '$count'"

	# If we are checking the "Filename length" or №9 table, the expected
	# values will be different. The minimum length will be 9, as the
	# file name is "fileX.bin" where X can be up to 20, which makes
	# the maximum file name length 10 characters. The total number
	# of characters is not counted and is therefore 0.
	if [[ "$table_id" == 9 ]]; then
		exp_min=9
		exp_max=10
		exp_tot_val=0
		exp_avg=0
	fi

	# Check total value
	total_value=$(cat "$report_path" |
		      jq -r --argjson id "$table_id" \
		      '.Reports[] | select(.GeneralInfo.TableId == $id) |
		      .GeneralInfo.TotalValue | floor')

	(( exp_tot_val == total_value )) ||
		error "expected total value '$exp_tot_val', got '$total_value'"

	# Since the tables with IDs 10, 11, 12, and 13 (atime, mtime,
	# ctime, crtime) display time, the minimum and maximum age
	# in days will be equal to 0.
	if [[ "$table_id" =~ ^(10|11|12|13)$ ]]; then
		exp_min=0
		exp_max=0
	fi

	# Check min value
	min=$(cat "$report_path" | jq -r --argjson id "$table_id" \
	      '.Reports[] | select(.GeneralInfo.TableId == $id) |
	      .GeneralInfo.Min | floor')

	(( min == exp_min )) ||
		error "expected min value '$exp_min', got '$min'"

	# Check max value
	max=$(cat "$report_path" | jq -r --argjson id "$table_id" \
	      '.Reports[] | select(.GeneralInfo.TableId == $id) |
	      .GeneralInfo.Max | floor')

	(( max == exp_max )) ||
		error "expected max value '$exp_max', got '$max'"

	# Check avg value
	avg=$(cat "$report_path" | jq -r --argjson id "$table_id" \
	      '.Reports[] | select(.GeneralInfo.TableId == $id) |
	      .GeneralInfo.Avg | floor')

	get_avg=$(($total_value / $count))
	(( avg == exp_avg && avg == get_avg )) ||
		error "expected avg value '$exp_avg', got '$avg' and '$get_avg'"

	# Check ranges
	ranges_cnt=$(cat "$report_path" |
		     jq -r --argjson id "$table_id" \
		     '.Reports[] | select(.GeneralInfo.TableId == $id) |
		     .Ranges | length')

	(( ranges_cnt != 0 )) ||
		error "expected ranges should be greater than 0"

	# for by ranges and calculate value
	total_in_ranges=$(cat "$report_path" | jq -r --argjson id "$table_id" \
			  '.Reports[] | select(.GeneralInfo.TableId == $id) |
			  .Ranges[] | .TotalInRange |
			  floor' | awk '{s+=$1} END {print s}')

	(( exp_tot_val == total_in_ranges )) ||
		error "expected total value '$exp_tot_val', got '$total_in_ranges'"


	count_in_ranges=$(cat "$report_path" | jq -r --argjson id "$table_id" \
			  '.Reports[] | select(.GeneralInfo.TableId == $id) |
			  .Ranges[] | .CountInRange |
			  floor' | awk '{s+=$1} END {print s}')

	(( exp_count == count_in_ranges )) ||
		error "expected count obj '$exp_count', got '$count_in_ranges'"

	echo "PASSED '$table_title'"
	echo ""
}

check_user_time_reports() {
	local report_path="$1"	# Path to report.json
	local user_uid=0	# root has a UID of 0
	local exp_count="$2"
	local count		# Tables[X].Ranges[all].CountFilesInRange
	local exp_min="$3"
	local min		# Tables[X].Ranges[all].MinSizeKB
	local exp_max="$4"
	local max		# Tables[X].Ranges[all].MaxSizeKB
	local exp_tot_val="$5"
	local total_in_ranges	# Tables[X].Ranges[all].TotalSizeInRangeKB
	local table_cnt		# Tables[X]
	local table_title	# Tables[X].Title
	local table_exists	# bool type

	table_exists=$(cat "$report_path" | jq -e --argjson uid "$user_uid" \
		       '.UserTimeReports[] | select(.UserUID == $uid)')

	[[ -n "$table_exists" ]] ||
		error "For the root user, there are no time-related tables"

	table_cnt=$(cat "$report_path" | jq -e --argjson uid "$user_uid" \
		     '.UserTimeReports[] | select(.UserUID == $uid) |
		      .Tables | length')

	# (0 - 3) 4 (atime, mtime, ctime, crtime)
	(( table_cnt != 3 )) ||
		error "expected count tables about time value '3', got '$table_cnt'"


	for i in {0..3}; do
		local range_day_s	# Tables[X].Ranges[all].RangeDayStart
		local range_day_e	# Tables[X].Ranges[all].RangeDayEnd

		table_title=$(cat "$report_path" |
			      jq -r --argjson uid "$user_uid" --argjson id "$i" \
			      '.UserTimeReports[] | select(.UserUID == $uid) |
			       .Tables[] | select(.UsersReportsTableId == $id) |
			       .Title')

		echo "start check "$table_title""


		# Since the directories and files were created in this test,
		# they should have a range from 0 to 2 days.
		# In all tables, only one range is expected;
		# otherwise, an error will occur, leading to the
		# termination of the test.

		range_day_s=$(cat "$report_path" |
			      jq -r --argjson uid "$user_uid" \
			      --argjson id "$i" \
			      '.UserTimeReports[] | select(.UserUID == $uid) |
			       .Tables[] | select(.UsersReportsTableId == $id) |
			       .Ranges[] | .RangeDayStart | floor' |
			      awk '{s+=$1} END {print s}')

		(( range_day_s == 0 )) ||
			error "'$table_title' expected range day start 0, got '$range_day_s'"


		range_day_e=$(cat "$report_path" |
			      jq -r --argjson uid "$user_uid" \
			      --argjson id "$i" \
			      '.UserTimeReports[] | select(.UserUID == $uid) |
			       .Tables[] | select(.UsersReportsTableId == $id) |
			       .Ranges[] | .RangeDayEnd | floor' |
			      awk '{s+=$1} END {print s}')

		(( range_day_e == 2 )) ||
			error "'$table_title' expected range day end 0, got '$range_day_e'"


		count=$(cat "$report_path" |
			jq -r --argjson uid "$user_uid" --argjson id "$i" \
			'.UserTimeReports[] | select(.UserUID == $uid) |
			 .Tables[] | select(.UsersReportsTableId == $id) |
			 .Ranges[] | .CountFilesInRange |
			 floor' | awk '{s+=$1} END {print s}')

		(( exp_count == count )) ||
			error "'$table_title' expected count files '$exp_count', got '$count'"

		total_in_ranges=$(cat "$report_path" |
				  jq -r --argjson uid "$user_uid" \
				  --argjson id "$i" \
				  '.UserTimeReports[] | select(.UserUID == $uid) |
				   .Tables[] |
				   select(.UsersReportsTableId == $id) |
				   .Ranges[] | .TotalSizeInRangeKB |
				   floor' | awk '{s+=$1} END {print s}')

		(( total_in_ranges == exp_tot_val )) ||
			error "'$table_title' expected total value '$exp_tot_val', got '$total_in_ranges'"

		min=$(cat "$report_path" |
		      jq -r --argjson uid "$user_uid" --argjson id "$i" \
		      '.UserTimeReports[] | select(.UserUID == $uid) |
		       .Tables[] | select(.UsersReportsTableId == $id) |
		       .Ranges[] | .MinSizeKB |
		       floor' | awk '{s+=$1} END {print s}')

		(( min == exp_min )) ||
			error "'$table_title' expected min value '$exp_min', got '$min'"


		max=$(cat "$report_path" |
		      jq -r --argjson uid "$user_uid" --argjson id "$i" \
		      '.UserTimeReports[] | select(.UserUID == $uid) |
		       .Tables[] | select(.UsersReportsTableId == $id) |
		       .Ranges[] | .MaxSizeKB |
		       floor' | awk '{s+=$1} END {print s}')

		(( max == exp_max )) ||
			error "'$table_title' expected min value '$exp_max', got '$max'"

		echo "PASSED '$table_title'"
		echo ""
	done
}

check_directories() {
	local json_data="$1"
	local expected_dir="$2"
	local expected_files_count="$3"
	local expected_dirs_count="$4"
	local expected_depth="$5"

	directories=$(echo "$json_data" | jq -r '.[] | .DirectoryName')

	[[ "$directories" == "$expected_dir" ]] ||
		error "Directory $expected_dir is missing!"

	current_files_count=$(echo "$json_data" | jq --arg dir "$expected_dir" \
			      '.[] | select(.DirectoryName == $dir) |
			       .FilesCount')

	(( current_files_count == expected_files_count )) ||
			error "expected files count '$expected_files_count', got '$current_files_count'"

	current_dirs_count=$(echo "$json_data" | jq --arg dir "$expected_dir" \
			     '.[] | select(.DirectoryName == $dir) |
			     .DirsCount')

	(( current_dirs_count == expected_dirs_count )) ||
			error "expected dirs count '$expected_dirs_count', got '$current_dirs_count'"

	current_depth=$(echo "$json_data" | jq --arg dir "$expected_dir" \
			'.[] | select(.DirectoryName == $dir) | .Depth')

	(( current_depth == expected_depth )) ||
			error "expected depth '$expected_depth', got '$current_depth'"

	next_json=$(echo "$json_data" | jq --arg dir "$expected_dir" \
		    '.[] | select(.DirectoryName == $dir) | .ChildDirectories')

	if [ "$(echo "$next_json" | jq 'length')" -gt 0 ]; then
		next_dir_num=$(( ${expected_dir##dir} + 1 ))
		next_expected_dir="dir$next_dir_num"

		# Expected values ​​for the next level
		next_expected_files_count=$(( expected_files_count - 1 ))
		next_expected_dirs_count=$(( expected_dirs_count - 1 ))
		next_expected_depth=$(( expected_depth + 1 ))

		check_directories "$next_json" "$next_expected_dir" \
				  "$next_expected_files_count" \
				  "$next_expected_dirs_count" \
				  "$next_expected_depth"
	fi
}

check_rating() {
	local json_data=$(cat "$1")
	local expected_files_count=10
	local expected_dirs_count=10
	local expected_depth=0
	local expected_rating_position=0

	echo "start check DirectoriesStats.Rating"

	rating=$(echo "$json_data" | jq -c '.DirectoriesStats.Rating[]')
	array_size=$(echo "$json_data" | jq '.DirectoriesStats.Rating | length')
	(( array_size == expected_dirs_count )) ||
		error "expected rating table size 10, got '$array_size'"

	for (( i=0; i<$array_size; i++ )); do
		current_item=$(echo "$json_data" |
			       jq -c ".DirectoriesStats.Rating[$i]")

		current_dir_name=$(echo "$current_item" |
				   jq -r '.DirectoryName')
		expected_dir_name="dir$((i + 1))"
		[[ "$current_dir_name" == "$expected_dir_name" ]] ||
			error "expected dir name '$expected_dir_name', got '$current_dir_name'"


		current_files_count=$(echo "$current_item" | jq '.FilesCount')
		(( current_files_count == expected_files_count )) ||
			error "expected files count '$expected_files_count', got '$current_files_count'"

		current_dirs_count=$(echo "$current_item" | jq '.DirsCount')
		(( current_dirs_count == expected_dirs_count )) ||
			error "expected dirs count '$expected_dirs_count', got '$current_dirs_count'"

		current_depth=$(echo "$current_item" | jq '.Depth')
		(( current_depth == expected_depth )) ||
			error "expected depth '$expected_depth', got '$current_depth'"

		current_rating_position=$(echo "$current_item" |
					  jq '.RatingPosition')
		(( current_rating_position == expected_rating_position )) ||
			error "expected rating position '$expected_rating_position', got '$current_rating_position'"

		# UPD values
		expected_files_count=$(( expected_files_count - 1 ))
		expected_dirs_count=$(( expected_dirs_count - 1 ))
		expected_depth=$(( expected_depth + 1 ))
		expected_rating_position=$(( expected_rating_position + 1 ))
	done

	echo "PASSED DirectoriesStats.Rating"
	echo ""
}

test_360() {
	local facet=mds1
	local report_path="$MOUNT/$tfile.json"
	local file=$MOUNT/$tfile
	local files_count=10
	local depth=10
	local tot_size=56320		# 55 MiB
	local min=1024			# 1 MiB
	local max=10240			# 10 MiB
	local avg=5632			# GeneralInfo.Avg
	local dirs_tree			# cutted from JSON

	init_lipe_find3_env "$file"
	create_directories_and_files $MOUNT
	stack_trap "rm -rf $MOUNT/*"

	out=$(lipe_find3_facet "$facet" -depth "$depth" \
	      -collect-fsize-stats "$report_path")
	[[ $? -ne 0 ]] && error "lipe_find3 collect-fsize-stats failed"

	cat $report_path	# for debug

	# Check reports (We can have up to 19 tables)
	for i in {0..19}; do
		if [[ $i -ne 7 ]]; then		# Skip "DirDirectory size" table
			check_reports "$report_path" "$files_count" \
				      "$tot_size" "$min" "$max" "$avg" $i
		fi
	done

	# Checking user time stats reports
	check_user_time_reports "$report_path" "$files_count" "$min" "$max" \
				"$tot_size"

	# check dir structures
	echo "start check DirectoriesStats.MainTree"
	dirs_tree=$(jq -r '.DirectoriesStats.MainTree.ChildDirectories' \
		    "$report_path")

	# Through recursion
	check_directories "$dirs_tree" "dir1" $files_count $depth 0
	echo "PASSED DirectoriesStats.MainTree"
	echo ""

	# check rating dirs
	check_rating "$report_path"

	# check rating files
	# waiting EX-9568
}
run_test 360 "lipe_find3 --collect-fsize-stats | check .JSON stats report"

test_400() {
	local file=$MOUNT/$tfile
	local fid

	init_lipe_find3_env "$file"
	fid=$($LFS path2fid "$file")

	expect1 "$tfile" lipe_find3_facet mds1 -true
	expect_empty lipe_find3_facet mds1 -false

	expect1 "$tfile" lipe_find3_facet mds1 -not -false
	expect_empty lipe_find3_facet mds1 -not -true

	expect1 "$tfile" lipe_find3_facet mds1 \! -false
	expect_empty lipe_find3_facet mds1 \! -true

	expect1 "$tfile" lipe_find3_facet mds1 -not -not -true
	expect_empty lipe_find3_facet mds1 -not -not -false

	# -and is implicit
	expect1 "$tfile" lipe_find3_facet mds1 -true -true
	expect1 "$tfile" lipe_find3_facet mds1 -true -and -true
	expect1 "$tfile" lipe_find3_facet mds1 -true -or -true
	expect1 "$tfile" lipe_find3_facet mds1 -true -or -false
	expect1 "$tfile" lipe_find3_facet mds1 -false -or -true

	expect1 "$tfile" lipe_find3_facet mds1 -true -a -true
	expect1 "$tfile" lipe_find3_facet mds1 -true -o -true
	expect1 "$tfile" lipe_find3_facet mds1 -true -o -false
	expect1 "$tfile" lipe_find3_facet mds1 -false -o -true

	# -and is implicit
	expect_empty lipe_find3_facet mds1 -true -false
	expect_empty lipe_find3_facet mds1 -false -false
	expect_empty lipe_find3_facet mds1 -false -true

	expect_empty lipe_find3_facet mds1 -true -and -false
	expect_empty lipe_find3_facet mds1 -false -and -false
	expect_empty lipe_find3_facet mds1 -false -and -true
	expect_empty lipe_find3_facet mds1 -false -or -false

	expect_empty lipe_find3_facet mds1 -true -a -false
	expect_empty lipe_find3_facet mds1 -false -a -false
	expect_empty lipe_find3_facet mds1 -false -a -true
	expect_empty lipe_find3_facet mds1 -false -o -false

	# -and has higher precedence than -or
	# "X && Y || Z" means "(X && Y) || Z"
	#
	# The differences between "(X && Y) || Z" and "X && (Y || Z)"
	# arises when the inputs are FTT or FFT.
	# F && T || T => T
	# F && F || T => T

	expect1 "$tfile" lipe_find3_facet mds1 -false -and -true -or -true
	expect1 "$tfile" lipe_find3_facet mds1 -false -and -false -or -true
	expect1 "$tfile" lipe_find3_facet mds1 -true -or -false -and -true
	expect1 "$tfile" lipe_find3_facet mds1 -true -or -false -and -false

	expect_error lipe_find3_facet mds1 -and
	expect_error lipe_find3_facet mds1 -true -and
	expect_error lipe_find3_facet mds1 -and -true
	expect_error lipe_find3_facet mds1 -true -and -and -true

	expect_error lipe_find3_facet mds1 -or
	expect_error lipe_find3_facet mds1 -true -or
	expect_error lipe_find3_facet mds1 -or -true
	expect_error lipe_find3_facet mds1 -true -or -or -true

	expect_error lipe_find3_facet mds1 -true -and -or -true
	expect_error lipe_find3_facet mds1 -true -or -and -true
}
run_test 400 "lipe_find3 -true, -false, -and, -or do the right thing"

test_401() {
	local file=$MOUNT/$tfile
	local fid

	init_lipe_find3_env "$file"
	fid=$($LFS path2fid "$file")

	expect1 "$fid" lipe_find3_facet mds1 \( -true \) -print-file-fid
	expect_empty lipe_find3_facet mds1 \( -false \)

	expect_empty lipe_find3_facet mds1 -false -and \( -true -or -true \)
	expect_empty lipe_find3_facet mds1 -false -and \( -false -or -true \)

	expect1 "$fid" lipe_find3_facet mds1 \( -true -true \) -print-file-fid
	expect_empty lipe_find3_facet mds1 \( -false -true \)

	expect1 "$fid" lipe_find3_facet mds1 \! \( -false \) -print-file-fid
	expect_empty lipe_find3_facet mds1 \! \( -true \)

	expect1 "$fid" lipe_find3_facet mds1 \( \! -false \) -print-file-fid
	expect_empty lipe_find3_facet mds1 \( \! -true \)

	expect1 "$fid" lipe_find3_facet mds1 -false , -true -print-file-fid
	expect_empty lipe_find3_facet mds1 -true , -false

	expect_error lipe_find3_facet mds1 \(
	expect_error lipe_find3_facet mds1 \( -true
	expect_error lipe_find3_facet mds1 -true \)

	expect_error lipe_find3_facet mds1 -true ,
	expect_error lipe_find3_facet mds1 , -true
	expect_error lipe_find3_facet mds1 ,
	expect_error lipe_find3_facet mds1 -true , , -true
}
run_test 401 "lipe_find3 parens and commas do the right thing"

complete_test $SECONDS
check_and_cleanup_lustre
exit_status
