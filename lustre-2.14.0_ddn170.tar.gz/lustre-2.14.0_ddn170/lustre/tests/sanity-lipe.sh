#!/bin/bash
#
# Tests for lipe_find and lipe_scan.
#
# lipe_find - search for files on Lustre devices or directories
# lipe_scan - fast scan tool based on LiPE (Lustre integrated Policy Engine)
set -e

ONLY=${ONLY:-"$*"}

LUSTRE=${LUSTRE:-$(dirname $0)/..}
. $LUSTRE/tests/test-framework.sh
init_test_env $@
. ${CONFIG:=$LUSTRE/tests/cfg/$NAME.sh}
init_logging

if ! check_versions; then
	skip "It is NOT necessary to test lipe under interoperation mode"
	exit 0
fi

# bug number for skipped test:
ALWAYS_EXCEPT="$SANITY_LIPE_EXCEPT"
# UPDATE THE COMMENT ABOVE WITH BUG NUMBERS WHEN CHANGING ALWAYS_EXCEPT!

(( OSTCOUNT >= 2 )) || skip_env "need at least 2 OSTs"

[[ $(facet_fstype mds1) = ldiskfs ]] || skip_env "need ldiskfs on MDS"

! remote_mds_nodsh || skip_env "remote MDS with nodsh"
! remote_ost_nodsh || skip_env "remote OSS with nodsh"

# check if lipe_find and lipe_scan are installed on MDS(s)
for t in lipe_find lipe_scan lipe_scan2; do
	do_nodes $(comma_list $(all_mdts_nodes)) "which $t" &>/dev/null ||
		skip_env "$t is not installed on MDS"
done

which jq || skip_env "jq is not installed"

# lipe_find configuration
LIPE_FIND=${LIPE_FIND:-"lipe_find"}
LIPE_FIND_LOG_DIR=${LIPE_FIND_LOG_DIR:-"/var/log/lipe_find"}
LIPE_FIND_VERBOSE=${LIPE_FIND_VERBOSE:-false}
LIPE_FIND_USE_MOUNT=${LIPE_FIND_USE_MOUNT:-false}

[[ $LIPE_FIND = *lipe_find ]] && PRINT_FID_OPT="-print-fid" ||
	PRINT_FID_OPT="--print-fid"

LIPE_POOL1=${LIPE_POOL1:-"fast"}
LIPE_POOL2=${LIPE_POOL2:-"slow"}

build_test_filter
check_and_setup_lustre

# mount Lustre clients on MDS node(s)
mount_client_on_mds() {
	local mds_nodes

	mds_nodes=$(exclude_items_from_list $(comma_list $(all_mdts_nodes)) \
		    $HOSTNAME)
	if [[ -n $mds_nodes ]]; then
		zconf_mount_clients $mds_nodes $MOUNT ||
			error "failed to mount client on MDS node $mds_nodes"
		stack_trap "zconf_umount_clients $mds_nodes $MOUNT"
	fi
}

# choose a random MDS and return its facet
lipe_get_random_mds() {
	(( MDSCOUNT != 1 )) || { echo -n mds1; return; }
	echo -n $(get_random_entry $(get_facets MDS))
}

# if the test suite was run on an MDS, then return the MDS facet
lipe_get_local_mds() {
	local facet
	local facets

	facets=$(get_facets MDS)
	for facet in ${facets//,/ }; do
		if local_node $(facet_active_host $facet); then
			echo -n $facet
			return
		fi
	done
}

# create OST pools
create_ost_pools() {
	pool_add $LIPE_POOL1 || error "failed to create OST pool '$LIPE_POOL1'"
	pool_add_targets $LIPE_POOL1 0 $((OSTCOUNT / 2 - 1)) ||
		error "failed to add targets to OST pool '$LIPE_POOL1'"
	pool_add $LIPE_POOL2 || error "failed to create OST pool '$LIPE_POOL2'"
	pool_add_targets $LIPE_POOL2 $((OSTCOUNT / 2)) $((OSTCOUNT - 1)) ||
		error "failed to add targets to OST pool '$LIPE_POOL2'"
}

# Convert file type string to type option or constant used in lipe_find
convert_file_type() {
	local arg="$1"
	local str="$2"
	local option
	local type

	! [[ $arg != option && $arg != constant ]] || return 0
	[[ $arg = option ]] && option=true || option=false

	case "$str" in
		  regular*) $option && type="f" || type="S_IFREG" ;;
		    block*) $option && type="b" || type="S_IFBLK" ;;
		character*) $option && type="c" || type="S_IFCHR" ;;
		 directory) $option && type="d" || type="S_IFDIR" ;;
		 symbolic*) $option && type="l" || type="S_IFLNK" ;;
		      fifo) $option && type="p" || type="S_IFIFO" ;;
		    socket) $option && type="s" || type="S_IFSOCK" ;;
		*) return ;;
	esac

	echo -n "$type"
}

declare -A type_to_mode=(
	[p]=0010666
	[c]=0020666
	[d]=0040666
	[b]=0060666
	[f]=0100666
	[l]=0120666
	[s]=0140666
)

create_special_files() {
	local file_name="$1"
	local file
	local device
	local loop_dev="/dev/loop0"
	local cmd
	local t

	[[ -n "$file_name" ]] || error "file_name was not specified"

	for t in ${!type_to_mode[@]}; do
		file="$file_name.$t"

		case $t in
			c) device=$(stat --format=%D /dev/null) ;;
			b) [[ -e $loop_dev ]] || {
				mknod -m660 $loop_dev b 7 0
				chown root.disk $loop_dev
			   }
			   device=$(stat --format=%D $loop_dev)
			   ;;
			*) device=0 ;;
		esac

		cmd="mcreate --mode=${type_to_mode[$t]} --device=$device $file"
		echo $cmd
		$cmd || error "mcreate '$file' failed"
	done
}

create_regular_files() {
	local i
	local pool
	if [[ "$1" = "--with-pool" ]]; then
		shift
		pool=yes
	fi

	local file="$1"
	[[ -n "$file" ]] || error "file was not specified"

	# create a regular file
	cmd="$LFS setstripe -c -1 -i -1 -S 4M ${pool:+-p $LIPE_POOL1 }$file.1"
	echo $cmd
	$cmd || error "$LFS setstripe '$file.1' failed"

	# create a PFL file
	cmd="$LFS setstripe -E 1M -c 1 ${pool:+-p $LIPE_POOL1 }"
	cmd+="--comp-flags=prefer -E eof -c -1 ${pool:+-p $LIPE_POOL2 }$file.2"
	echo $cmd
	$cmd || error "$LFS setstripe '$file.2' failed"

	# create a FLR file
	cmd="$LFS mirror create -N -E 1M -c -1 ${pool:+-p $LIPE_POOL1 }"
	cmd+="-E eof -S 4M ${pool:+-p $LIPE_POOL2 }"
	cmd+="-N ${pool:+-p $LIPE_POOL1 }$file.3"
	echo $cmd
	$cmd || error "$LFS mirror create '$file.3' failed"

	# create a DoM file
	cmd="$LFS setstripe -E 1M -L mdt -E eof $file.4"
	echo $cmd
	$cmd || error "$LFS setstripe '$file.4' failed"

	# create hard links to file
	for i in {1..3}; do
		cmd="ln $file.1 $file.1.link$i"
		echo $cmd
		$cmd || error "ln $file.1 $file.1.link$i failed"
	done

	# write some data into the files
	for i in {1..4}; do
		dd bs=${i}M count=1 iflag=fullblock oflag=sync \
			if=/dev/urandom of=$file.$i ||
				error "failed to write to $file.$i"
	done
	sync; sync_all_data; sync
}

create_lipe_find_files() {
	local pool
	if [[ "$1" = "--with-pool" ]]; then
		shift
		pool=yes
	fi

	local file_name="$1"
	[[ -n "$file_name" ]] || error "file_name was not specified"

	create_regular_files ${pool:+--with-pool }$file_name
	create_special_files $file_name
}

do_lipe_find_facet() {
	local facet="$1"
	local action="$2"
	local device="$(facet_device $facet)"
	local device_opt
	local quiet

	$LIPE_FIND_VERBOSE || quiet=yes
	! $LIPE_FIND_USE_MOUNT || device=$MOUNT

	[[ $LIPE_FIND = *lipe_find ]] && device_opt="$device" ||
		device_opt="-- $device"

	# lipe_find fails if run twice in the same wall clock second.
	VERBOSE=false do_facet $facet "sync; [[ ! -e $LIPE_FIND_LOG_DIR ]] ||" \
		"find $LIPE_FIND_LOG_DIR -mindepth 1 -delete"
	do_facet $facet "$LIPE_FIND $action $device_opt ${@:3}" \
			"${quiet:+2>/dev/null}"
}

expect_fid() {
	local fid="$1"
	local which="${2:-true}"
	local fid_str="$(tr -d '[]' <<<$fid)"

	if $which; then
		grep --fixed-strings "$fid_str" || error "expected FID '$fid'"
	else
		! grep --fixed-strings "$fid_str" || error "unexpected FID '$fid'"
	fi
}

expect_file() {
	local file="$1"
	local which="${2:-true}"
	local fid

	fid=$($LFS path2fid "$file")
	[[ -n "$fid" ]] || error "cannot get FID of '$file'"

	expect_fid "$fid" "$which"
}

lipe_find_expect_file() {
	local facet="$1"
	local file="$2"
	local which="$3"

	do_lipe_find_facet $facet $PRINT_FID_OPT "${@:4}" |
		expect_file "$file" "$which"
}

lipe_find_expect_fid() {
	local facet="$1"
	local fid="$2"
	local which="$3"

	do_lipe_find_facet $facet $PRINT_FID_OPT "${@:4}" |
		expect_fid "$fid" "$which"
}

lipe_find_max_stripe_size() {
	local file="$1"
	local stripe_size
	local max_stripe_size=$($LFS getstripe -S $file)
	local ids=($($LFS getstripe $file | awk '/lcme_id/{print $2}' |
		   tr '\n' ' '))
	local id

	if (( ${#ids[@]} == 0 )); then
		echo -n $max_stripe_size
		return
	fi

	for id in ${ids[@]}; do
		stripe_size=$($LFS getstripe -I$id -S $file)
		(( stripe_size <= max_stripe_size)) ||
			max_stripe_size=$stripe_size
	done

	echo -n $max_stripe_size
}

LIPE_MDS_FACET=""
(( MDSCOUNT == 1 )) && LIPE_MDS_FACET=mds1 ||
	LIPE_MDS_FACET=$(lipe_get_local_mds)
[[ -n $LIPE_MDS_FACET ]] ||
	echo "No local MDS. Each test will be run on a random MDS."

# lipe_find test cases
test_1() {
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}

	do_lipe_find_facet $facet $PRINT_FID_OPT ||
		error "cannot run lipe_find on $facet"
}
run_test 1 "lipe_find works"

test_2() {
	local td=$DIR/$tdir
	local tf=$td/$tfile
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local index=$(($(facet_number $facet) - 1))

	mkdir_on_mdt -i $index $td || error "$LFS mkdir '$td' failed"
	touch $tf || error "touch '$tf' failed"

	lipe_find_expect_file $facet $td
	lipe_find_expect_file $facet $tf
}
run_test 2 "lipe_find finds dir and file"

test_3_sub() {
	local facet="$1"
	local path="$2"
	local fid

	fid=$($LFS path2fid "$path" | tr -d '[]')
	[[ -n "$fid" ]] || error "cannot get FID of '$path'"

	lipe_find_expect_fid $facet $fid true "-fid $fid"
	lipe_find_expect_fid $facet $fid true "-expr 'fid_match(\\\"$fid\\\")'"
	lipe_find_expect_fid $facet $fid true "-fid '*'"
	lipe_find_expect_fid $facet $fid true "-fid '*${fid:3}'"
	lipe_find_expect_fid $facet $fid true "-fid '${fid%:*}*'"
	lipe_find_expect_fid $facet $fid true "-fid '*${fid:3:12}*'"
	lipe_find_expect_fid $facet $fid false "-fid X$fid"
	lipe_find_expect_fid $facet $fid false "-fid ${fid}X"
}

test_3() {
	local td=$DIR/$tdir
	local tf=$td/$tfile
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local index=$(($(facet_number $facet) - 1))
	local file

	mkdir_on_mdt -i $index $td || error "$LFS mkdir '$td' failed"
	create_lipe_find_files $tf

	echo -e "\nTest $td"
	test_3_sub $facet $td

	for file in $(ls $td); do
		echo -e "\nTest $td/$file"
		test_3_sub $facet $td/$file
	done
}
run_test 3 "lipe_find -fid works"

test_4_sub() {
	local facet="$1"
	local file="$2"
	local name=$(basename $file)

	# -name is the same with -iname except the match is case sensitive
	lipe_find_expect_file $facet $file true "-name $name"
	lipe_find_expect_file $facet $file true \
		"-expr 'fname_match(\\\"$name\\\")'"
	lipe_find_expect_file $facet $file false "-name ${name^^}"
	lipe_find_expect_file $facet $file false "-name ${name^}"
	lipe_find_expect_file $facet $file true "-name '*'"
	lipe_find_expect_file $facet $file false "! -name $name"
	lipe_find_expect_file $facet $file true "! -name ${name^^}"
	lipe_find_expect_file $facet $file true "! -name ${name^}"
	lipe_find_expect_file $facet $file false "! -name '*'"

	# -iname is the same with -name except the match is case insensitive
	lipe_find_expect_file $facet $file true "-iname $name"
	lipe_find_expect_file $facet $file true \
		"-expr 'fname_imatch(\\\"$name\\\")'"
	lipe_find_expect_file $facet $file true "-iname ${name^^}"
	lipe_find_expect_file $facet $file true \
		"-expr 'fname_imatch(\\\"${name^^}\\\")'"
	lipe_find_expect_file $facet $file true "-iname ${name^}"
	lipe_find_expect_file $facet $file true "-iname '*'"
	lipe_find_expect_file $facet $file false "! -iname $name"
	lipe_find_expect_file $facet $file false "! -iname ${name^^}"
	lipe_find_expect_file $facet $file false "! -iname ${name^}"
	lipe_find_expect_file $facet $file false "! -iname '*'"
}

test_4() {
	local td=$DIR/$tdir
	local tf=$td/${tfile//-/_}
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local index=$(($(facet_number $facet) - 1))
	local file

	mkdir_on_mdt -i $index $td || error "$LFS mkdir '$td' failed"
	create_lipe_find_files $tf

	for file in $(ls $td); do
		echo -e "\nTest $td/$file"
		test_4_sub $facet $td/$file
	done
}
run_test 4 "lipe_find -name and -iname works"

test_5_sub() {
	local facet="$1"
	local file="$2"
	local inum

	inum=$(stat -c %i $file)
	[[ -n "$inum" ]] || error "cannot get inode number of '$file'"

	lipe_find_expect_file $facet $file true "-inum $inum"
	lipe_find_expect_file $facet $file true "-expr 'inum == $inum'"
	lipe_find_expect_file $facet $file true "-expr '== inum $inum'"
	lipe_find_expect_file $facet $file false "! -inum $inum"
}

test_5() {
	local td=$DIR/$tdir
	local tf=$td/$tfile
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local index=$(($(facet_number $facet) - 1))
	local file

	local saved_LIPE_FIND_USE_MOUNT=$LIPE_FIND_USE_MOUNT
	LIPE_FIND_USE_MOUNT=true
	stack_trap "LIPE_FIND_USE_MOUNT=$saved_LIPE_FIND_USE_MOUNT"
	mount_client_on_mds

	mkdir_on_mdt -i $index $td || error "$LFS mkdir '$td' failed"
	create_lipe_find_files $tf

	echo -e "\nTest $td"
	test_5_sub $facet $td

	for file in $(ls $td); do
		echo -e "\nTest $td/$file"
		test_5_sub $facet $td/$file
	done
}
run_test 5 "lipe_find -inum works"

test_6_sub() {
	local facet="$1"
	local path="$2"
	local fid
	local t_option
	local t_constant
	local name=$(basename $path)

	fid=$($LFS path2fid "$path" | tr -d '[]')
	[[ -n "$fid" ]] || error "cannot get FID of '$path'"

	t_option=$(convert_file_type option "$(stat -c %F $path)")
	[[ -n "$t_option" ]] || error "cannot get type option of '$path'"

	t_constant=$(convert_file_type constant "$(stat -c %F $path)")
	[[ -n "$t_constant" ]] || error "cannot get type constant of '$path'"

	lipe_find_expect_fid $facet $fid true "-type $t_option"
	lipe_find_expect_fid $facet $fid false "! -type $t_option"
	lipe_find_expect_fid $facet $fid true "-expr '== type $t_constant'"
	lipe_find_expect_fid $facet $fid true "-expr 'type == $t_constant'"
	lipe_find_expect_fid $facet $fid true \
		"-expr '(type == $t_constant) && fid_match(\\\"$fid\\\")'"
	lipe_find_expect_fid $facet $fid true \
		"-expr '(type==$t_constant) && fid_match(\\\"$fid\\\")'"
	lipe_find_expect_fid $facet $fid true \
		"-expr '(type != $t_constant) || fid_match(\\\"$fid\\\")'"

	lipe_find_expect_fid $facet $fid true "-name $name -type $t_option"
	lipe_find_expect_fid $facet $fid true "-name '*' -type $t_option"
}

test_6() {
	local td=$DIR/$tdir
	local tf=$td/$tfile
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local index=$(($(facet_number $facet) - 1))
	local file

	mkdir_on_mdt -i $index $td || error "$LFS mkdir '$td' failed"
	create_lipe_find_files $tf

	echo -e "\nTest $td"
	test_6_sub $facet $td

	for file in $(ls $td); do
		echo -e "\nTest $td/$file"
		test_6_sub $facet $td/$file
	done
}
run_test 6 "lipe_find -type works"

test_7_sub() {
	local facet="$1"
	local path="$2"
	local fid
	local pool

	fid=$($LFS path2fid "$path" | tr -d '[]')
	[[ -n "$fid" ]] || error "cannot get FID of '$path'"

	pool=$($LFS getstripe -p "$path" | head -1)

	if [[ -z "$pool" ]]; then
		lipe_find_expect_fid $facet $fid false "-pool '*'"
		lipe_find_expect_fid $facet $fid false "-pool-regex '.*'"
		return
	fi

	lipe_find_expect_fid $facet $fid true "-pool '*'"
	lipe_find_expect_fid $facet $fid true "-pool-regex '.*'"
	lipe_find_expect_fid $facet $fid true "-pool $pool"
	lipe_find_expect_fid $facet $fid true "-pool-regex $pool"
	lipe_find_expect_fid $facet $fid false "-pool ${pool}x"
	lipe_find_expect_fid $facet $fid false "-pool-regex ${pool}x"
	lipe_find_expect_fid $facet $fid false "-pool x$pool"
	lipe_find_expect_fid $facet $fid false "-pool-regex x$pool"
	lipe_find_expect_fid $facet $fid true "-expr 'pool_reg(\\\"$pool\\\")'"
	lipe_find_expect_fid $facet $fid true \
		"-expr 'pool_match(\\\"$pool\\\")'"
}

test_7() {
	local td=$DIR/$tdir
	local tf=$td/$tfile
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local index=$(($(facet_number $facet) - 1))
	local file

	# create OST pools
	create_ost_pools

	mkdir_on_mdt -i $index $td || error "$LFS mkdir '$td' failed"
	create_regular_files --with-pool $tf

	echo -e "\nTest $td"
	test_7_sub $facet $td

	for file in $(ls $td); do
		echo -e "\nTest $td/$file"
		test_7_sub $facet $td/$file
	done
}
run_test 7 "lipe_find -pool works"

test_8_sub() {
	local facet="$1"
	local file="$2"
	local type
	local count
	local size
	local max_stripe_size

	type=$(convert_file_type constant "$(stat -c %F $file)")
	[[ -n "$type" ]] || error "cannot get type of '$file'"

	if [[ $type != S_IFREG && $type != S_IFDIR ]] ||
	   [[ "$($LFS getstripe -c $file)" =~ "no stripe info" ]]; then
		lipe_find_expect_file $facet $file false "-stripe-count 1"
		lipe_find_expect_file $facet $file false "! -stripe-count 1"
		lipe_find_expect_file $facet $file false "-stripe-count +1"

		lipe_find_expect_file $facet $file false "-stripe-size +1"
		lipe_find_expect_file $facet $file false "-stripe-size 1048576"
		lipe_find_expect_file $facet $file false \
			"! -stripe-size 1048576"
		return
	fi

	count=$($LFS getstripe -c $file)
	[[ -n "$count" ]] || error "cannot get stripe count of '$file'"

	size=$($LFS getstripe -S $file)
	[[ -n "$size" ]] || error "cannot get stripe size of '$file'"

	max_stripe_size=$(lipe_find_max_stripe_size $file)

	lipe_find_expect_file $facet $file true "-stripe-count $count"
	lipe_find_expect_file $facet $file false "! -stripe-count $count"
	lipe_find_expect_file $facet $file false "-stripe-count +2000"
	lipe_find_expect_file $facet $file true "-expr 'stripe_count == $count'"
	lipe_find_expect_file $facet $file false \
		"-expr 'stripe_count != $count'"
	lipe_find_expect_file $facet $file true "-expr 'stripe_count >= $count'"
	lipe_find_expect_file $facet $file true "-expr 'stripe_count <= $count'"

	lipe_find_expect_file $facet $file false "-stripe-size $((size - 1))"
	lipe_find_expect_file $facet $file false "-stripe-size $((size + 1))"
	lipe_find_expect_file $facet $file false \
		"-stripe-size +$max_stripe_size"

	if [[ $type != S_IFDIR ]]; then
		lipe_find_expect_file $facet $file true \
			"-expr 'stripe_size == $size'"
		lipe_find_expect_file $facet $file false \
			"-expr 'stripe_size != $size'"
		lipe_find_expect_file $facet $file true \
			"-expr 'stripe_size >= $size'"
		lipe_find_expect_file $facet $file true \
			"-expr 'stripe_size <= $size'"
	fi
}

test_8() {
	local td=$DIR/$tdir
	local tf=$td/$tfile
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local index=$(($(facet_number $facet) - 1))
	local file

	mkdir_on_mdt -i $index $td || error "$LFS mkdir '$td' failed"
	$LFS setstripe -c 1 $td ||
		error "$LFS setstripe -c 1 $td failed"
	create_lipe_find_files $tf

	echo -e "\nTest $td"
	test_8_sub $facet $td

	for file in $(ls $td); do
		echo -e "\nTest $td/$file"
		test_8_sub $facet $td/$file
	done
}
run_test 8 "lipe_find -stripe-count and -stripe-size work"

test_9_sub() {
	local facet="$1"
	local file="$2"
	local type
	local idx

	type=$(convert_file_type constant "$(stat -c %F $file)")
	[[ -n "$type" ]] || error "cannot get type of '$file'"

	if [[ $type != S_IFREG && $type != S_IFDIR ]] ||
	   [[ "$($LFS getstripe -i $file)" =~ "no stripe info" ]]; then
		lipe_find_expect_file $facet $file false "-ost 0"
		lipe_find_expect_file $facet $file false "! -ost 0"

		lipe_find_expect_file $facet $file false "-stripe-index 0"
		lipe_find_expect_file $facet $file false "! -stripe-index 0"
		return
	fi

	idx=$($LFS getstripe -i $file)
	[[ -n "$idx" ]] || error "cannot get stripe index of '$file'"

	if [[ $type = S_IFDIR || "$($LFS getstripe -L $file)" == "mdt" ]]; then
		lipe_find_expect_file $facet $file false "-ost $idx"
		lipe_find_expect_file $facet $file true "! -ost $idx"
		lipe_find_expect_file $facet $file false "-ost $((idx + 1))"
		lipe_find_expect_file $facet $file true "! -ost $((idx + 1))"

		lipe_find_expect_file $facet $file false "-stripe-index $idx"
		lipe_find_expect_file $facet $file true "! -stripe-index $idx"
		lipe_find_expect_file $facet $file false \
			"-stripe-index $((idx + 1))"
		lipe_find_expect_file $facet $file true \
			"! -stripe-index $((idx + 1))"
	elif [[ $type = S_IFREG ]]; then
		lipe_find_expect_file $facet $file true "-ost $idx"
		lipe_find_expect_file $facet $file true "-expr 'ost($idx)'"
		lipe_find_expect_file $facet $file false "! -ost $idx"
		lipe_find_expect_file $facet $file false \
			"-ost $((idx + OSTCOUNT))"
		lipe_find_expect_file $facet $file true \
			"! -ost $((idx + OSTCOUNT))"

		lipe_find_expect_file $facet $file true "-stripe-index $idx"
		lipe_find_expect_file $facet $file false "! -stripe-index $idx"
		lipe_find_expect_file $facet $file false \
			"-stripe-index $((idx + OSTCOUNT))"
		lipe_find_expect_file $facet $file true \
			"! -stripe-index $((idx + OSTCOUNT))"
	fi
}

test_9() {
	local td=$DIR/$tdir
	local tf=$td/$tfile
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local index=$(($(facet_number $facet) - 1))
	local file

	mkdir_on_mdt -i $index $td || error "$LFS mkdir '$td' failed"
	$LFS setstripe -i 0 $td ||
		error "$LFS setstripe -i 0 $td failed"
	create_lipe_find_files $tf

	echo -e "\nTest $td"
	test_9_sub $facet $td

	for file in $(ls $td); do
		echo -e "\nTest $td/$file"
		test_9_sub $facet $td/$file
	done
}
run_test 9 "lipe_find -ost and -stripe-index work"

test_10_sub() {
	local facet="$1"
	local file="$2"
	local type
	local count

	type=$(convert_file_type constant "$(stat -c %F $file)")
	[[ -n "$type" ]] || error "cannot get type of '$file'"

	if [[ $type != S_IFREG && $type != S_IFDIR ]] ||
	   [[ "$($LFS getstripe --comp-count $file)" =~ "no stripe info" ]]
	then
		lipe_find_expect_file $facet $file false "-comp-count 0"
		lipe_find_expect_file $facet $file false "! -comp-count 0"
		lipe_find_expect_file $facet $file false "-comp-count +1"
		lipe_find_expect_file $facet $file false "-comp-count -1"

		lipe_find_expect_file $facet $file false "-component-count 0"
		lipe_find_expect_file $facet $file false "! -component-count 0"
		lipe_find_expect_file $facet $file false "-component-count +1"
		lipe_find_expect_file $facet $file false "-component-count -1"
		return
	fi

	count=$($LFS getstripe --comp-count $file)
	[[ -n "$count" ]] || error "cannot get component count of '$file'"
	(( count != 0 )) || return 0

	lipe_find_expect_file $facet $file true "-comp-count $count"
	lipe_find_expect_file $facet $file false "! -comp-count $count"
	lipe_find_expect_file $facet $file false "-comp-count +$count"
	lipe_find_expect_file $facet $file false "-comp-count -$count"
	lipe_find_expect_file $facet $file true "-comp-count -$((count + 1))"

	lipe_find_expect_file $facet $file true "-expr 'comp_count == $count'"
	lipe_find_expect_file $facet $file false "-expr 'comp_count != $count'"
	lipe_find_expect_file $facet $file true "-expr 'comp_count >= $count'"
	lipe_find_expect_file $facet $file true "-expr 'comp_count <= $count'"

	lipe_find_expect_file $facet $file true "-component-count $count"
	lipe_find_expect_file $facet $file false "! -component-count $count"
	lipe_find_expect_file $facet $file false \
		"-component-count $((count + 1))"
	lipe_find_expect_file $facet $file true \
		"! -component-count $((count + 1))"
	lipe_find_expect_file $facet $file true \
		"-component-count +$((count - 1))"
}

test_10() {
	local td=$DIR/$tdir
	local tf=$td/$tfile
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local index=$(($(facet_number $facet) - 1))
	local file

	mkdir_on_mdt -i $index $td || error "$LFS mkdir '$td' failed"
	create_lipe_find_files $tf

	for file in $(ls $td); do
		echo -e "\nTest $td/$file"
		test_10_sub $facet $td/$file
	done
}
run_test 10 "lipe_find -comp-count and -component-count work"

test_11_sub() {
	local facet="$1"
	local file="$2"
	local type
	local layout

	type=$(convert_file_type constant "$(stat -c %F $file)")
	[[ -n "$type" ]] || error "cannot get type of '$file'"

	if [[ $type != S_IFREG ||
	   "$($LFS getstripe -L $file)" =~ "no stripe info" ]]; then
		lipe_find_expect_file $facet $file false "-layout raid0"
		lipe_find_expect_file $facet $file false "-layout mdt"
		lipe_find_expect_file $facet $file false "-layout released"

		lipe_find_expect_file $facet $file false "! -layout raid0"
		lipe_find_expect_file $facet $file false "! -layout mdt"
		lipe_find_expect_file $facet $file false "! -layout released"
		return
	fi

	layout=$($LFS getstripe -L $file)
	[[ -n "$layout" ]] || error "cannot get file layout of '$file'"

	lipe_find_expect_file $facet $file false "-layout released"
	lipe_find_expect_file $facet $file true "! -layout released"
	lipe_find_expect_file $facet $file true "-layout $layout"
	lipe_find_expect_file $facet $file false "! -layout $layout"
	lipe_find_expect_file $facet $file true "-layout $layout,$layout"
	lipe_find_expect_file $facet $file false "-layout $layout,released"
	lipe_find_expect_file $facet $file false "-layout raid0,mdt,released"
	lipe_find_expect_file $facet $file true \
		"-expr 'layout(\\\"$layout\\\")'"
	lipe_find_expect_file $facet $file false \
		"-expr 'layout(\\\"mdt,raid0,released\\\")'"
}

test_11() {
	local td=$DIR/$tdir
	local tf=$td/$tfile
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local index=$(($(facet_number $facet) - 1))
	local file

	mkdir_on_mdt -i $index $td || error "$LFS mkdir '$td' failed"
	create_lipe_find_files $tf

	for file in $(ls $td); do
		echo -e "\nTest $td/$file"
		test_11_sub $facet $td/$file
	done
}
run_test 11 "lipe_find -layout works"

test_12_sub() {
	local facet="$1"
	local file="$2"
	local uid
	local user

	uid=$(stat -c %u $file)
	[[ -n "$uid" ]] || error "cannot get user ID of owner for '$file'"

	user=$(stat -c %U $file)
	[[ -n "$user" ]] || error "cannot get user name of owner for '$file'"

	lipe_find_expect_file $facet $file true "-uid $uid"
	lipe_find_expect_file $facet $file true "! ! -uid $uid"
	lipe_find_expect_file $facet $file false "! -uid $uid"
	lipe_find_expect_file $facet $file false \
		"! -uid $((uid + 1)) ! -uid $uid"
	lipe_find_expect_file $facet $file true "-expr 'uid == $uid'"
	lipe_find_expect_file $facet $file false "-expr 'uid != $uid'"
	lipe_find_expect_file $facet $file true \
		"-expr 'uid == user2id(\\\"$user\\\")'"

	lipe_find_expect_file $facet $file true "-user $uid"
	lipe_find_expect_file $facet $file true "! ! -user $uid"
	lipe_find_expect_file $facet $file false "! -user $uid"
	lipe_find_expect_file $facet $file false \
		"! -user $((uid + 1)) ! -user $uid"
	lipe_find_expect_file $facet $file true "-expr 'user(\\\"$uid\\\")'"

	lipe_find_expect_file $facet $file true "-user $user"
	lipe_find_expect_file $facet $file true "! ! -user $user"
	lipe_find_expect_file $facet $file false "! -user $user"
	lipe_find_expect_file $facet $file false "! -user bin ! -user $user"
	lipe_find_expect_file $facet $file false "-nouser"
	lipe_find_expect_file $facet $file false "-expr nouser"
	lipe_find_expect_file $facet $file true "-expr 'user(\\\"$user\\\")'"

	[[ $uid != $RUNAS_ID ]] || return 0

	chown $RUNAS_ID $file || return 0

	lipe_find_expect_file $facet $file false "-uid $uid"
	lipe_find_expect_file $facet $file true "! -uid $uid"
	lipe_find_expect_file $facet $file true "-uid $RUNAS_ID"
	lipe_find_expect_file $facet $file false "! -uid $RUNAS_ID"
}

test_12() {
	local td=$DIR/$tdir
	local tf=$td/$tfile
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local index=$(($(facet_number $facet) - 1))
	local file

	mkdir_on_mdt -i $index $td || error "$LFS mkdir '$td' failed"
	create_lipe_find_files $tf

	echo -e "\nTest $td"
	test_12_sub $facet $td

	for file in $(ls $td); do
		echo -e "\nTest $td/$file"
		test_12_sub $facet $td/$file
	done
}
run_test 12 "lipe_find -uid, -user and -nouser work"

test_13_sub() {
	local facet="$1"
	local file="$2"
	local gid
	local group

	gid=$(stat -c %g $file)
	[[ -n "$gid" ]] || error "cannot get group ID of owner for '$file'"

	group=$(stat -c %G $file)
	[[ -n "$group" ]] || error "cannot get group name of owner for '$file'"

	lipe_find_expect_file $facet $file true "-gid $gid"
	lipe_find_expect_file $facet $file true "! ! -gid $gid"
	lipe_find_expect_file $facet $file false "! -gid $gid"
	lipe_find_expect_file $facet $file false \
		"! -gid $((gid + 1)) ! -gid $gid"
	lipe_find_expect_file $facet $file true "-expr 'gid == $gid'"
	lipe_find_expect_file $facet $file false "-expr 'gid != $gid'"
	lipe_find_expect_file $facet $file true \
		"-expr 'gid == group2id(\\\"$group\\\")'"

	lipe_find_expect_file $facet $file true "-group $gid"
	lipe_find_expect_file $facet $file true "! ! -group $gid"
	lipe_find_expect_file $facet $file false "! -group $gid"
	lipe_find_expect_file $facet $file false \
		"! -group $((gid + 1)) ! -group $gid"
	lipe_find_expect_file $facet $file true "-expr 'group(\\\"$gid\\\")'"

	lipe_find_expect_file $facet $file true "-group $group"
	lipe_find_expect_file $facet $file true "! ! -group $group"
	lipe_find_expect_file $facet $file false "! -group $group"
	lipe_find_expect_file $facet $file false "! -group bin ! -group $group"
	lipe_find_expect_file $facet $file false "-nogroup"
	lipe_find_expect_file $facet $file false "-expr nogroup"
	lipe_find_expect_file $facet $file true "-expr 'group(\\\"$group\\\")'"

	[[ $gid != $RUNAS_GID ]] || return 0

	chown :$RUNAS_GID $file || return 0

	lipe_find_expect_file $facet $file false "-gid $gid"
	lipe_find_expect_file $facet $file true "! -gid $gid"
	lipe_find_expect_file $facet $file true "-gid $RUNAS_GID"
	lipe_find_expect_file $facet $file false "! -gid $RUNAS_GID"
}

test_13() {
	local td=$DIR/$tdir
	local tf=$td/$tfile
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local index=$(($(facet_number $facet) - 1))
	local file

	mkdir_on_mdt -i $index $td || error "$LFS mkdir '$td' failed"
	create_lipe_find_files $tf

	echo -e "\nTest $td"
	test_13_sub $facet $td

	for file in $(ls $td); do
		echo -e "\nTest $td/$file"
		test_13_sub $facet $td/$file
	done
}
run_test 13 "lipe_find -gid, -group and -nogroup work"

test_14_sub() {
	local facet="$1"
	local file="$2"
	local uid
	local gid
	local xtime
	local expr_cmd

	uid=$(stat -c %u $file)
	[[ -n "$uid" ]] || error "cannot get user ID of owner for '$file'"

	gid=$(stat -c %g $file)
	[[ -n "$gid" ]] || error "cannot get group ID of owner for '$file'"

	for xtime in atime ctime mtime; do
		lipe_find_expect_file $facet $file true "-$xtime 0"
		lipe_find_expect_file $facet $file false "! -$xtime 0"
		lipe_find_expect_file $facet $file false "-$xtime +0"
		lipe_find_expect_file $facet $file true "! -$xtime +0"
		lipe_find_expect_file $facet $file false "-$xtime -0"
		lipe_find_expect_file $facet $file true "! -$xtime -0"
		lipe_find_expect_file $facet $file true "-$xtime -1"
		lipe_find_expect_file $facet $file false "! -$xtime -1"
		lipe_find_expect_file $facet $file true "-expr '$xtime > 0'"
		lipe_find_expect_file $facet $file false "-expr '$xtime < 0'"

		expr_cmd="-expr '($xtime > (sys_time - 1 * days) ||"
		expr_cmd+=" uid == $((uid + 100))) && gid == $gid'"
		lipe_find_expect_file $facet $file true "$expr_cmd"
	done
}

test_14() {
	local td=$DIR/$tdir
	local tf=$td/$tfile
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local index=$(($(facet_number $facet) - 1))
	local file

	mkdir_on_mdt -i $index $td || error "$LFS mkdir '$td' failed"
	create_lipe_find_files $tf

	echo -e "\nTest $td"
	test_14_sub $facet $td

	for file in $(ls $td); do
		echo -e "\nTest $td/$file"
		test_14_sub $facet $td/$file
	done
}
run_test 14 "lipe_find -atime, -ctime and -mtime work"

test_15_sub() {
	local facet="$1"
	local file="$2"
	local xmin

	for xmin in amin cmin mmin; do
		lipe_find_expect_file $facet $file false "-$xmin +600"
		lipe_find_expect_file $facet $file true "! -$xmin +600"
		lipe_find_expect_file $facet $file false "-$xmin -0"
		lipe_find_expect_file $facet $file true "! -$xmin -0"
		lipe_find_expect_file $facet $file true "-$xmin -600"
		lipe_find_expect_file $facet $file false "! -$xmin -600"
	done
}

test_15() {
	local td=$DIR/$tdir
	local tf=$td/$tfile
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local index=$(($(facet_number $facet) - 1))
	local file

	mkdir_on_mdt -i $index $td || error "$LFS mkdir '$td' failed"
	create_lipe_find_files $tf

	echo -e "\nTest $td"
	test_15_sub $facet $td

	for file in $(ls $td); do
		echo -e "\nTest $td/$file"
		test_15_sub $facet $td/$file
	done
}
run_test 15 "lipe_find -amin, -cmin and -mmin work"

test_16_sub() {
	local facet="$1"
	local file="$2"

	lipe_find_expect_file $facet $file false "-used +0"
	lipe_find_expect_file $facet $file false "-used 1"
	lipe_find_expect_file $facet $file true "-used -1"
	lipe_find_expect_file $facet $file false "-used +1"
}

test_16() {
	local td=$DIR/$tdir
	local tf=$td/$tfile
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local index=$(($(facet_number $facet) - 1))
	local file

	mkdir_on_mdt -i $index $td || error "$LFS mkdir '$td' failed"
	create_lipe_find_files $tf

	echo -e "\nTest $td"
	test_16_sub $facet $td

	for file in $(ls $td); do
		echo -e "\nTest $td/$file"
		test_16_sub $facet $td/$file
	done
}
run_test 16 "lipe_find -used works"

test_17_sub() {
	local facet="$1"
	local file="$2"
	local type

	type=$(convert_file_type constant "$(stat -c %F $file)")
	[[ -n "$type" ]] || error "cannot get type of '$file'"

	if [[ $type != S_IFREG && $type != S_IFDIR ]]; then
		lipe_find_expect_file $facet $file false "-empty"
		lipe_find_expect_file $facet $file true "! -empty"
		return
	fi

	if [[ $type = S_IFDIR ]]; then
		if [[ -z "$(ls $file)" ]]; then
			lipe_find_expect_file $facet $file true "-empty"
			lipe_find_expect_file $facet $file false "! -empty"
		else
			lipe_find_expect_file $facet $file false "-empty"
			lipe_find_expect_file $facet $file true "! -empty"
		fi
		return
	fi

	# S_IFREG
	if (( $(stat -c %s $file) == 0 )); then
		lipe_find_expect_file $facet $file true "-empty"
		lipe_find_expect_file $facet $file false "! -empty"
		echo foo > $file || error "echo foo > $file failed"
		sync; sleep 5; sync
	fi

	lipe_find_expect_file $facet $file false "-empty"
	lipe_find_expect_file $facet $file true "! -empty"
	lipe_find_expect_file $facet $file false "-expr empty"
}

test_17() {
	local td=$DIR/$tdir
	local tf=$td/$tfile
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local index=$(($(facet_number $facet) - 1))
	local file

	local saved_LIPE_FIND_USE_MOUNT=$LIPE_FIND_USE_MOUNT
	LIPE_FIND_USE_MOUNT=true
	stack_trap "LIPE_FIND_USE_MOUNT=$saved_LIPE_FIND_USE_MOUNT"
	mount_client_on_mds

	mkdir_on_mdt -i $index $td || error "$LFS mkdir '$td' failed"
	mkdir_on_mdt -i $index $td-1 || error "$LFS mkdir '$td-1' failed"

	create_lipe_find_files $tf

	echo -e "\nTest $td"
	test_17_sub $facet $td

	echo -e "\nTest $td-1"
	test_17_sub $facet $td-1

	for file in $(ls $td); do
		echo -e "\nTest $td/$file"
		test_17_sub $facet $td/$file
	done
}
run_test 17 "lipe_find -empty works"

test_18_sub() {
	local facet="$1"
	local file="$2"
	local type

	type=$(convert_file_type constant "$(stat -c %F $file)")
	[[ -n "$type" ]] || error "cannot get type of '$file'"

	if [[ $type != S_IFDIR ]]; then
		lipe_find_expect_file $facet $file true "-entries 0"
		lipe_find_expect_file $facet $file false "! -entries 0"
		lipe_find_expect_file $facet $file true "-expr 'entries == 0'"
		lipe_find_expect_file $facet $file false "-expr 'entries != 0'"
		return
	fi

	if [[ -z "$(ls $file)" ]]; then
		lipe_find_expect_file $facet $file true "-entries 0"
		lipe_find_expect_file $facet $file false "! -entries 0"
		lipe_find_expect_file $facet $file false "-entries +0"
		lipe_find_expect_file $facet $file true "! -entries +0"
		lipe_find_expect_file $facet $file false "-entries -0"
		lipe_find_expect_file $facet $file true "! -entries -0"
	else
		lipe_find_expect_file $facet $file false "-entries 0"
		lipe_find_expect_file $facet $file true "! -entries 0"
		lipe_find_expect_file $facet $file true "-entries +0"
		lipe_find_expect_file $facet $file false "! -entries +0"
		lipe_find_expect_file $facet $file false "-entries -0"
		lipe_find_expect_file $facet $file true "! -entries -0"
	fi
}

test_18() {
	local td=$DIR/$tdir
	local tf=$td/$tfile
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local index=$(($(facet_number $facet) - 1))
	local file

	mkdir_on_mdt -i $index $td || error "$LFS mkdir '$td' failed"
	mkdir_on_mdt -i $index $td-1 || error "$LFS mkdir '$td-1' failed"

	create_lipe_find_files $tf

	echo -e "\nTest $td"
	test_18_sub $facet $td

	echo -e "\nTest $td-1"
	test_18_sub $facet $td-1

	for file in $(ls $td); do
		echo -e "\nTest $td/$file"
		test_18_sub $facet $td/$file
	done
}
run_test 18 "lipe_find -entries works"

test_19_sub() {
	local facet="$1"
	local file="$2"
	local nlink

	nlink=$(stat -c %h $file)
	[[ -n "$nlink" ]] || error "cannot get number of hard links for '$file'"

	lipe_find_expect_file $facet $file true "-links $nlink"
	lipe_find_expect_file $facet $file false "! -links $nlink"
	lipe_find_expect_file $facet $file false "-links $((nlink + 1))"
	lipe_find_expect_file $facet $file false "-links $((nlink - 1))"
	lipe_find_expect_file $facet $file true "-expr 'nlink == $nlink'"
	lipe_find_expect_file $facet $file false "-expr 'nlink != $nlink'"
	lipe_find_expect_file $facet $file true "-expr 'nlink >= $nlink'"
	lipe_find_expect_file $facet $file true "-expr 'nlink <= $nlink'"
}

test_19() {
	local td=$DIR/$tdir
	local tf=$td/$tfile
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local index=$(($(facet_number $facet) - 1))
	local file

	mkdir_on_mdt -i $index $td || error "$LFS mkdir '$td' failed"
	create_lipe_find_files $tf

	echo -e "\nTest $td"
	test_19_sub $facet $td

	for file in $(ls $td); do
		echo -e "\nTest $td/$file"
		test_19_sub $facet $td/$file
	done
}
run_test 19 "lipe_find -links works"

test_20_sub() {
	local facet="$1"
	local file="$2"
	local type
	local cmd

	type=$(convert_file_type constant "$(stat -c %F $file)")
	[[ -n "$type" ]] || error "cannot get type of '$file'"

	[[ $type = S_IFREG || $type = S_IFDIR ]] || return 0

	cmd="setfattr -h -n user.xattr_name -v xattr_value $file"
	echo $cmd
	$cmd || error "setfattr $file failed"

	lipe_find_expect_file $facet $file true "-xattr 'user.xattr_name=*'"
	lipe_find_expect_file $facet $file true "-xattr '*=xattr_value'"
	lipe_find_expect_file $facet $file true \
		"-xattr 'user.xattr_name=xattr_value'"
	lipe_find_expect_file $facet $file true \
		"-xattr 'user.xattr_name*=xattr_value'"
	lipe_find_expect_file $facet $file true "-xattr 'user.*=xattr_value'"
	lipe_find_expect_file $facet $file true "-xattr 'user.*=*_value'"
	lipe_find_expect_file $facet $file true "-xattr '*=*'"
	lipe_find_expect_file $facet $file true "-xattr 'trusted.lma=*'"
	lipe_find_expect_file $facet $file false "-xattr 'invalid_name=*'"
	lipe_find_expect_file $facet $file false "-xattr '*=invalid_value'"
	lipe_find_expect_file $facet $file true "-expr \
		'xattr_match(\\\"user.xattr_name\\\", \\\"xattr_value\\\")'"
}

test_20() {
	which setfattr &>/dev/null || skip_env "setfattr is not installed"

	local td=$DIR/$tdir
	local tf=$td/$tfile
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local index=$(($(facet_number $facet) - 1))
	local file

	mkdir_on_mdt -i $index $td || error "$LFS mkdir '$td' failed"
	create_lipe_find_files $tf

	echo -e "\nTest $td"
	test_20_sub $facet $td

	for file in $(ls $td); do
		echo -e "\nTest $td/$file"
		test_20_sub $facet $td/$file
	done
}
run_test 20 "lipe_find -xattr works"

test_21_sub() {
	local facet="$1"
	local file="$2"
	local perm

	perm=$(stat -c %a $file)
	[[ -n "$perm" ]] || error "cannot get access rights for '$file'"

	lipe_find_expect_file $facet $file true "-perm -0"
	lipe_find_expect_file $facet $file true "-perm /0"

	lipe_find_expect_file $facet $file true "-perm $perm"
	lipe_find_expect_file $facet $file true "-perm -$perm"
	lipe_find_expect_file $facet $file true "-perm /$perm"

	chmod 666 $file || return 0

	lipe_find_expect_file $facet $file false "-perm 777"
	lipe_find_expect_file $facet $file false "-perm -777"
	lipe_find_expect_file $facet $file true "-perm /777"

	lipe_find_expect_file $facet $file false "-expr 'perm_equal(444)'"
	lipe_find_expect_file $facet $file true "-expr 'perm_at_least(444)'"
	lipe_find_expect_file $facet $file true "-expr 'perm_any(444)'"
}

test_21() {
	local td=$DIR/$tdir
	local tf=$td/$tfile
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local index=$(($(facet_number $facet) - 1))
	local file

	mkdir_on_mdt -i $index $td || error "$LFS mkdir '$td' failed"
	create_lipe_find_files $tf

	echo -e "\nTest $td"
	test_21_sub $facet $td

	for file in $(ls $td); do
		echo -e "\nTest $td/$file"
		test_21_sub $facet $td/$file
	done
}
run_test 21 "lipe_find -perm works"

test_22_sub() {
	local facet="$1"
	local file="$2"

	lipe_find_expect_file $facet $file true "-projid 0"
	lipe_find_expect_file $facet $file false "! -projid 0"
	lipe_find_expect_file $facet $file true "-expr 'projid == 0'"
	lipe_find_expect_file $facet $file true "-expr '== projid 0'"
	lipe_find_expect_file $facet $file false "-projid +0"
	lipe_find_expect_file $facet $file true "-projid -1"
}

test_22() {
	local td=$DIR/$tdir
	local tf=$td/$tfile
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local index=$(($(facet_number $facet) - 1))
	local file

	local saved_LIPE_FIND_USE_MOUNT=$LIPE_FIND_USE_MOUNT
	LIPE_FIND_USE_MOUNT=true
	stack_trap "LIPE_FIND_USE_MOUNT=$saved_LIPE_FIND_USE_MOUNT"
	mount_client_on_mds

	mkdir_on_mdt -i $index $td || error "$LFS mkdir '$td' failed"
	create_lipe_find_files $tf

	echo -e "\nTest $td"
	test_22_sub $facet $td

	for file in $(ls $td); do
		echo -e "\nTest $td/$file"
		test_22_sub $facet $td/$file
	done
}
run_test 22 "lipe_find -projid works"

test_23_sub() {
	local facet="$1"
	local file="$2"
	local size
	local f_size
	local b_num
	local b_size
	local b_usize
	local opt

	f_size=$(stat -c %s $file)
	[[ -n "$f_size" ]] || error "cannot get total size for '$file'"

	b_num=$(stat -c %b $file)
	[[ -n "$b_num" ]] || error "cannot get number of blocks for '$file'"

	b_usize=$(stat -c %B $file)
	[[ -n "$b_usize" ]] || error "cannot get block unit size for '$file'"

	b_size=$((b_num * b_usize))

	for opt in size blocks; do
		[[ $opt = size ]] && size=$f_size || size=$b_size

		lipe_find_expect_file $facet $file true "-$opt ${size}c"
		lipe_find_expect_file $facet $file false "! -$opt ${size}c"
		lipe_find_expect_file $facet $file false "-$opt +${size}c"
		lipe_find_expect_file $facet $file false "-$opt -${size}c"

		lipe_find_expect_file $facet $file false "-$opt $((size + 1))c"
		lipe_find_expect_file $facet $file true "! -$opt $((size + 1))c"
		lipe_find_expect_file $facet $file false "-$opt +$((size + 1))c"
		lipe_find_expect_file $facet $file true "-$opt -$((size + 1))c"

		(( size != 0 )) || continue

		lipe_find_expect_file $facet $file true "-$opt $((size / 512))b"
		lipe_find_expect_file $facet $file true "-$opt $((size / 1024))"
		lipe_find_expect_file $facet $file true \
			"-$opt $((size / 1048576))M"

		lipe_find_expect_file $facet $file true "-expr '$opt == $size'"
		lipe_find_expect_file $facet $file true "-expr '$opt >= $size'"
		lipe_find_expect_file $facet $file true "-expr '$opt <= $size'"
		lipe_find_expect_file $facet $file false "-expr '$opt != $size'"

		lipe_find_expect_file $facet $file false "-$opt $((size - 1))c"
		lipe_find_expect_file $facet $file true "! -$opt $((size - 1))c"
		lipe_find_expect_file $facet $file true "-$opt +$((size - 1))c"
		lipe_find_expect_file $facet $file false "-$opt -$((size - 1))c"
	done
}

test_23() {
	local td=$DIR/$tdir
	local tf=$td/$tfile
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local index=$(($(facet_number $facet) - 1))
	local file

	local saved_LIPE_FIND_USE_MOUNT=$LIPE_FIND_USE_MOUNT
	LIPE_FIND_USE_MOUNT=true
	stack_trap "LIPE_FIND_USE_MOUNT=$saved_LIPE_FIND_USE_MOUNT"
	mount_client_on_mds

	mkdir_on_mdt -i $index $td || error "$LFS mkdir '$td' failed"
	create_lipe_find_files $tf

	echo -e "\nTest $td"
	test_23_sub $facet $td

	for file in $(ls $td); do
		echo -e "\nTest $td/$file"
		test_23_sub $facet $td/$file
	done
}
run_test 23 "lipe_find -size and -blocks work"

test_100() {
	local file=$DIR/$tdir/$tfile
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local index=$(($(facet_number $facet) - 1))
	local link_count=200
	local i

	(( MDS1_VERSION >= $(version_code 2.14.0.39) )) ||
		skip "need at least lipe from 2.14.0-ddn38-59-ga4c8c816a67a"
	$LFS mkdir -i $index $DIR/$tdir || error "$LFS mkdir '$td' failed"
	touch $file

	for ((i = 1; i < link_count; i++)); do
		ln $file $file.$i
	done

	lipe_find_expect_file $facet $file true
	lipe_find_expect_file $facet $file true -name $tfile
	lipe_find_expect_file $facet $file true -name $tfile.1
}
run_test 100 "lipe_find works with big link xattrs"

do_lipe_scan2_facet() {
	local facet="$1"
	local device="$(facet_device $facet)"
	shift

	do_facet "$facet" lipe_scan2 "$device" "$@"
}

test_200() {
	local td=$DIR/$tdir
	local file=$td/$tfile
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local index=$(($(facet_number $facet) - 1))
	local fid
	local attrs
	local size1
	local size2
	local blocks1
	local blocks2
	local flags1
	local flags2

	mkdir_on_mdt -i $index $td || error "$LFS mkdir '$td' failed"
	echo XXX > $file
	fid=$($LFS path2fid $file)

	sync
	sync_all_data
	sync
	cancel_lru_locks mdc

	$LFS getsom $file
	flags1=$($LFS getsom -f $file)
	size1=$($LFS getsom -s $file)
	blocks1=$($LFS getsom -b $file)

	attrs=$(do_lipe_scan2_facet $facet --print-json=fid,som |
		jq --arg FID "$fid" 'select(.fid == $FID)')
	echo "attrs = '$attrs'" >&2

	flags2=$(jq --null-input "$attrs.som._flags")
	size2=$(jq --null-input "$attrs.som.size")
	blocks2=$(jq --null-input "$attrs.som.blocks")

	((flags1 == flags2)) || error "flags1 ($flags1) != flags2 ($flags2)"
	((size1 == size2)) || error "size1 ($size1) != size2 ($size2)"
	((blocks1 == blocks2)) ||
		error "blocks1 ($blocks1) != blocks2 ($blocks2)"
}
run_test 200 "lipe_scan2 SoM support"

test_201() {
	local td0=$DIR/$tdir
	local td1=$DIR/$tdir.1
	local file0=$td0/$tfile
	local file1=$td1/$tfile.1
	local fid
	local -a path
	local path_count
	local facet=${LIPE_MDS_FACET:-$(lipe_get_random_mds)}
	local index=$(($(facet_number $facet) - 1))

	mkdir_on_mdt -i $index $td0 || error "$LFS mkdir '$td0' failed"
	mkdir_on_mdt -i $index $td1 || error "$LFS mkdir '$td1' failed"

	echo XXX > $file0
	fid=$($LFS path2fid $file0)
	ln $file0 $file1

	sync
	sync_all_data
	sync
	cancel_lru_locks mdc

	mount_client_on_mds

	attrs=$(do_lipe_scan2_facet $facet --client-mount="$MOUNT" \
		--print-json=fid,paths |
		jq --arg FID "$fid" 'select(.fid == $FID)')
	echo "attrs = '$attrs'" >&2

	path_count=$(jq --null-input "$attrs.paths | length")
	((path_count == 2)) || error "path_count ($path_count) != 2"

	path=( $(jq --null-input --raw-output "$attrs.paths[]") )
	[[ "${path[0]}" == "$tdir/$tfile" ]] ||
		error "path0 '${path[0]}' != '$tdir/$tfile'"
	[[ "${path[1]}" == "$tdir.1/$tfile.1" ]] ||
		error "path1 '${path[1]}' != '$tdir.1/$tfile.1'"
}
run_test 201 "lipe_scan2 paths support"

complete_test $SECONDS
check_and_cleanup_lustre
exit_status
